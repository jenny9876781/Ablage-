<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Datenhaltung: Artikel, Vorgänge (eine Reservierungsanfrage) und Positionen
 * (ein Artikel darin). Die Verfügbarkeit wird immer aus den Positionen
 * gerechnet, nie als Zähler geführt – ein Zähler läuft bei gleichzeitigen
 * Zugriffen auseinander.
 */
class Kikripp_DB {

    const SCHEMA_VERSION = 9;   // 9: zahlart, rg_korrektur (1.15.0)
    const SCHEMA_ALT = 8;   // 6: Position mit preis_original und festpreis (1.8.0) · 7: Warte auf Rückinfo (1.9.0) · 8: kommissioniert (1.10.0)

    /** 1.6.0: So viele Tage trägt ein Artikel nach dem Import, mit dem er sichtbar wurde, das Schild NEU. */
    const NEU_TAGE = 14;

    public static function t_artikel()  { global $wpdb; return $wpdb->prefix . 'kikripp_artikel'; }
    public static function t_vorgang()  { global $wpdb; return $wpdb->prefix . 'kikripp_vorgang'; }
    public static function t_position() { global $wpdb; return $wpdb->prefix . 'kikripp_position'; }

    public static function tabellen_anlegen() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $coll = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE " . self::t_artikel() . " (
            artnr VARCHAR(32) NOT NULL,
            sortierung INT NOT NULL DEFAULT 0,
            menge INT NOT NULL DEFAULT 0,
            preis_netto DECIMAL(10,2) NOT NULL DEFAULT 0,
            aktiv TINYINT(1) NOT NULL DEFAULT 1,
            im_katalog TINYINT(1) NOT NULL DEFAULT 1,
            daten LONGTEXT NOT NULL,
            aktualisiert DATETIME NOT NULL,
            PRIMARY KEY (artnr),
            KEY im_katalog (im_katalog, aktiv)
        ) ENGINE=InnoDB $coll;");

        dbDelta("CREATE TABLE " . self::t_vorgang() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL DEFAULT '',
            email VARCHAR(190) NOT NULL DEFAULT '',
            telefon VARCHAR(80) NOT NULL DEFAULT '',
            nachricht TEXT NULL,
            firma VARCHAR(190) NOT NULL DEFAULT '',
            strasse VARCHAR(190) NOT NULL DEFAULT '',
            plz VARCHAR(10) NOT NULL DEFAULT '',
            ort VARCHAR(120) NOT NULL DEFAULT '',
            besichtigung VARCHAR(40) NOT NULL DEFAULT '',
            abholwunsch VARCHAR(20) NOT NULL DEFAULT '',
            demontage TINYINT(1) NOT NULL DEFAULT 0,
            abholtermin VARCHAR(80) NOT NULL DEFAULT '',
            abholung VARCHAR(16) NOT NULL DEFAULT '',
            rechnungsnr VARCHAR(40) NOT NULL DEFAULT '',
            rechnung_am VARCHAR(10) NOT NULL DEFAULT '',
            notiz TEXT NULL,
            abgeholt_am VARCHAR(10) NOT NULL DEFAULT '',
            du TINYINT(1) NOT NULL DEFAULT 0,
            erstellt DATETIME NOT NULL,
            ablauf DATETIME NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'offen',
            mail_versandt TINYINT(1) NOT NULL DEFAULT 0,
            kontakt_weg TINYINT(1) NOT NULL DEFAULT 0,
            testdaten TINYINT(1) NOT NULL DEFAULT 0,
            warte_seit VARCHAR(19) NOT NULL DEFAULT '',
            warte_notiz VARCHAR(255) NOT NULL DEFAULT '',
            warte_bis VARCHAR(10) NOT NULL DEFAULT '',
            zahlart VARCHAR(20) NOT NULL DEFAULT '',
            rg_korrektur TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY status (status, ablauf)
        ) ENGINE=InnoDB $coll;");

        dbDelta("CREATE TABLE " . self::t_position() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            vorgang_id BIGINT(20) UNSIGNED NOT NULL,
            artnr VARCHAR(32) NOT NULL,
            menge INT NOT NULL DEFAULT 1,
            preis_netto DECIMAL(10,2) NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'reserviert',
            bezahlt_am DATETIME NULL,
            preis_original DECIMAL(10,2) NULL,
            festpreis DECIMAL(10,2) NULL,
            kommissioniert VARCHAR(19) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            KEY vorgang_id (vorgang_id),
            KEY artnr (artnr, status)
        ) ENGINE=InnoDB $coll;");

        update_option('kikripp_schema_version', self::SCHEMA_VERSION);
    }

    public static function pruefe_version() {
        if ((int) get_option('kikripp_schema_version', 0) < self::SCHEMA_VERSION) {
            self::tabellen_anlegen();
        }
    }

    /** Belegung je Artikel: bezahlte Mengen und noch gültige Reservierungen. */
    public static function belegung($artnr = null) {
        global $wpdb;
        $p = self::t_position();
        $v = self::t_vorgang();
        $jetzt = current_time('mysql');
        $wo = '';
        $args = [$jetzt];
        if ($artnr !== null) {
            $wo = ' AND p.artnr = %s';
            $args[] = $artnr;
        }
        $sql = "SELECT p.artnr,
                       SUM(CASE WHEN p.status = 'bezahlt' THEN p.menge ELSE 0 END) AS bezahlt,
                       SUM(CASE WHEN p.status = 'reserviert'
                                     AND ((v.status = 'offen' AND (v.ablauf > %s OR v.warte_seit <> ''))
                                          OR v.status = 'bestellt')
                                THEN p.menge ELSE 0 END) AS reserviert,
                       SUM(CASE WHEN p.status = 'reserviert' AND v.status = 'bestellt'
                                THEN p.menge ELSE 0 END) AS bestellt
                FROM $p p INNER JOIN $v v ON v.id = p.vorgang_id
                WHERE 1=1 $wo
                GROUP BY p.artnr";
        $zeilen = $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);
        $out = [];
        foreach ((array) $zeilen as $z) {
            $out[$z['artnr']] = [
                'bezahlt'    => (int) $z['bezahlt'],
                'reserviert' => (int) $z['reserviert'],      // enthält die bestellten Stücke
                'bestellt'   => (int) $z['bestellt'],
            ];
        }
        return $out;
    }

    /**
     * Artikel für den Katalog, angereichert um die Verfügbarkeit.
     * Vollständig bezahlte Artikel fallen heraus – sie sind verkauft.
     * 1.11.0: Bestellte Stücke zählen dafür wie verkauft – die Zusage ist da, nur Rechnung und
     * Zahlung fehlen noch. Wird die Bestellung storniert, sind sie sofort wieder im Katalog.
     */
    public static function katalog_artikel() {
        global $wpdb;
        $zeilen = $wpdb->get_results(
            "SELECT * FROM " . self::t_artikel() . "
             WHERE aktiv = 1 AND im_katalog = 1
             ORDER BY sortierung ASC, artnr ASC", ARRAY_A);
        $belegung = self::belegung();
        $out = [];
        foreach ((array) $zeilen as $z) {
            $daten = json_decode($z['daten'], true);
            if (!is_array($daten)) { $daten = []; }
            $b = $belegung[$z['artnr']] ?? ['bezahlt' => 0, 'reserviert' => 0, 'bestellt' => 0];
            $menge = (int) $z['menge'];
            $rest  = max(0, $menge - $b['bezahlt'] - $b['bestellt']);   // weder verkauft noch bestellt
            if ($rest <= 0) { continue; }                      // bezahlt oder bestellt = aus dem Katalog
            $offen = max(0, $b['reserviert'] - $b['bestellt']);
            $frei = max(0, $rest - $offen);
            $daten['nr']         = $z['artnr'];
            $daten['menge']      = $rest;
            $daten['frei']       = $frei;
            $daten['reserviert'] = min($offen, $rest);
            $daten['preis']      = (float) $z['preis_netto'];
            $daten['status']     = $frei > 0 ? 'verfügbar' : 'reserviert';
            $seit = (string) ($daten['neu_seit'] ?? '');
            $daten['neu']        = $seit !== '' && strtotime($seit) >= strtotime(current_time('mysql')) - self::NEU_TAGE * DAY_IN_SECONDS;
            // 1.15.1: Tag des Imports (nur das Datum), damit die jüngsten Neuheiten oben stehen
            if ($daten['neu']) { $daten['neu_tag'] = substr($seit, 0, 10); }
            unset($daten['neu_seit']);
            $out[] = $daten;
        }
        return $out;
    }

    /** Wie viele Stück sind von einem Artikel gerade frei? */
    public static function frei($artnr) {
        global $wpdb;
        $menge = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT menge FROM " . self::t_artikel() . "
             WHERE artnr = %s AND aktiv = 1 AND im_katalog = 1", $artnr));
        if ($menge <= 0) { return 0; }
        $b = self::belegung($artnr)[$artnr] ?? ['bezahlt' => 0, 'reserviert' => 0];
        return max(0, $menge - $b['bezahlt'] - $b['reserviert']);
    }

    /**
     * Reservierung anlegen. Läuft in einer Transaktion mit Zeilensperre,
     * damit zwei gleichzeitige Anfragen nicht dasselbe letzte Stück bekommen.
     * Gibt die Vorgangs-ID zurück oder ein WP_Error.
     */
    public static function reservieren($kontakt, $wunsch) {
        global $wpdb;
        if (empty($wunsch)) {
            return new WP_Error('leer', 'Es wurden keine Artikel ausgewählt.');
        }
        $jetzt = current_time('mysql');
        $ablauf = self::ablauf_nach_werktagen($jetzt, self::frist_werktage());

        $wpdb->query('START TRANSACTION');
        try {
            $positionen = [];
            foreach ($wunsch as $artnr => $menge) {
                $artnr = sanitize_text_field((string) $artnr);
                $menge = (int) $menge;
                if ($menge <= 0) { continue; }

                // Zeilensperre auf den Artikel – blockiert eine parallele Reservierung
                $artikel = $wpdb->get_row($wpdb->prepare(
                    "SELECT artnr, menge, preis_netto FROM " . self::t_artikel() . "
                     WHERE artnr = %s AND aktiv = 1 AND im_katalog = 1 FOR UPDATE", $artnr), ARRAY_A);
                if (!$artikel) {
                    $wpdb->query('ROLLBACK');
                    return new WP_Error('unbekannt', sprintf('Artikel %s ist nicht mehr im Katalog.', $artnr));
                }
                $b = self::belegung($artnr)[$artnr] ?? ['bezahlt' => 0, 'reserviert' => 0];
                $frei = (int) $artikel['menge'] - $b['bezahlt'] - $b['reserviert'];
                if ($menge > $frei) {
                    $wpdb->query('ROLLBACK');
                    return new WP_Error('zu_wenig', sprintf(
                        'Von %s sind nur noch %d Stück verfügbar. Bitte passen Sie die Menge an.',
                        $artnr, max(0, $frei)));
                }
                $positionen[] = [
                    'artnr' => $artnr,
                    'menge' => $menge,
                    'preis' => (float) $artikel['preis_netto'],   // Preis wird eingefroren
                ];
            }
            if (empty($positionen)) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('leer', 'Es wurden keine Artikel ausgewählt.');
            }

            $ok = $wpdb->insert(self::t_vorgang(), [
                'name'         => $kontakt['name'],
                'email'        => $kontakt['email'],
                'telefon'      => $kontakt['telefon'],
                'nachricht'    => $kontakt['nachricht'],
                'firma'        => (string) ($kontakt['firma'] ?? ''),
                'strasse'      => (string) ($kontakt['strasse'] ?? ''),
                'plz'          => (string) ($kontakt['plz'] ?? ''),
                'ort'          => (string) ($kontakt['ort'] ?? ''),
                'besichtigung' => (string) ($kontakt['besichtigung'] ?? ''),
                'abholwunsch'  => (string) ($kontakt['abholwunsch'] ?? ''),
                'demontage'    => !empty($kontakt['demontage']) ? 1 : 0,
                'zahlart'      => in_array($kontakt['zahlart'] ?? '', ['ueberweisung', 'bar'], true) ? $kontakt['zahlart'] : '',
                'erstellt'     => $jetzt,
                'ablauf'       => $ablauf,
                'status'       => 'offen',
                'testdaten'    => (int) get_option('kikripp_vorschau', 1),
            ]);
            // Die IP-Adresse wird bewusst nicht gespeichert: der Katalog liegt auf
            // fremdem Speicherplatz und soll dort keine personenbezogenen Daten ablegen.
            if ($ok === false) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('db', 'Die Reservierung konnte nicht gespeichert werden.');
            }
            $vorgang_id = (int) $wpdb->insert_id;
            foreach ($positionen as $pos) {
                $wpdb->insert(self::t_position(), [
                    'vorgang_id'  => $vorgang_id,
                    'artnr'       => $pos['artnr'],
                    'menge'       => $pos['menge'],
                    'preis_netto' => $pos['preis'],
                    'status'      => 'reserviert',
                ]);
            }
            $wpdb->query('COMMIT');
            return $vorgang_id;
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('fehler', $e->getMessage());
        }
    }

    public static function vorgang($id) {
        global $wpdb;
        $v = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::t_vorgang() . " WHERE id = %d", $id), ARRAY_A);
        if (!$v) { return null; }
        $v['positionen'] = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, a.daten FROM " . self::t_position() . " p
             LEFT JOIN " . self::t_artikel() . " a ON a.artnr = p.artnr
             WHERE p.vorgang_id = %d ORDER BY p.id", $id), ARRAY_A);
        return $v;
    }

    public static function vorgaenge($status = null) {
        global $wpdb;
        $sql = "SELECT * FROM " . self::t_vorgang();
        if ($status) {
            $sql = $wpdb->prepare($sql . " WHERE status = %s", $status);
        }
        $sql .= " ORDER BY erstellt DESC";
        $liste = $wpdb->get_results($sql, ARRAY_A);
        foreach ($liste as &$v) {
            $v['positionen'] = $wpdb->get_results($wpdb->prepare(
                "SELECT p.*, a.daten FROM " . self::t_position() . " p
                 LEFT JOIN " . self::t_artikel() . " a ON a.artnr = p.artnr
                 WHERE p.vorgang_id = %d ORDER BY p.id", $v['id']), ARRAY_A);
        }
        return $liste;
    }

    /**
     * Nimmt alle Artikel aus dem Katalog, die in der Importdatei nicht mehr vorkommen.
     * Gelöscht wird nichts – an den Zeilen können Reservierungen und Verkäufe hängen.
     * Gibt die Artikelnummern zurück, die dabei stillgelegt wurden.
     */
    public static function fehlende_stilllegen(array $gesehen) {
        global $wpdb;
        if (!$gesehen) { return []; }
        $platzhalter = implode(',', array_fill(0, count($gesehen), '%s'));
        $betroffen = $wpdb->get_col($wpdb->prepare(
            'SELECT artnr FROM ' . self::t_artikel() . "
              WHERE artnr NOT IN ($platzhalter) AND (im_katalog = 1 OR aktiv = 1)", $gesehen));
        if (!$betroffen) { return []; }
        $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::t_artikel() . " SET im_katalog = 0, aktiv = 0
              WHERE artnr NOT IN ($platzhalter) AND (im_katalog = 1 OR aktiv = 1)", $gesehen));
        return $betroffen;
    }

    /**
     * Löscht Name, E-Mail, Telefon und Nachricht eines Vorgangs.
     * Positionen, Mengen, Preise und Daten bleiben — die braucht die Buchhaltung.
     * Wird direkt nach erfolgreichem Mailversand aufgerufen: die Kontaktdaten
     * liegen dann nur für den Moment des Versands in der Datenbank.
     */
    public static function kontakt_loeschen($id) {
        global $wpdb;
        return (bool) $wpdb->update(self::t_vorgang(), [
            'name' => '', 'email' => '', 'telefon' => '', 'nachricht' => '',
            'firma' => '', 'strasse' => '', 'plz' => '', 'ort' => '',
            'kontakt_weg' => 1,
        ], ['id' => (int) $id]);
    }

    /** Vorgänge, an denen noch Kontaktdaten hängen (Mailversand war gescheitert). */
    public static function kontakte_offen() {
        global $wpdb;
        return $wpdb->get_col('SELECT id FROM ' . self::t_vorgang() . '
                                WHERE kontakt_weg = 0 AND name <> \'\'');
    }

    /**
     * Vorgang auf bestellt/bezahlt/storniert setzen.
     *
     * „bestellt“ heißt: der Käufer hat nach dem Anruf zugesagt, die Bestellung ist
     * unterwegs. Ab dann läuft die Reservierung nicht mehr ab – zwischen Anruf,
     * Unterschrift, Rechnung und Zahlungseingang vergehen oft mehr als drei Werktage.
     * Einzeln stornierte Positionen bleiben storniert, was auch immer mit dem Vorgang
     * danach geschieht.
     */
    public static function vorgang_status($id, $status) {
        global $wpdb;
        if (!in_array($status, ['offen', 'bestellt', 'bezahlt', 'storniert'], true)) { return false; }
        $wpdb->update(self::t_vorgang(), ['status' => $status], ['id' => (int) $id]);
        $pos_status = $status === 'bezahlt' ? 'bezahlt' : ($status === 'storniert' ? 'storniert' : 'reserviert');
        $felder = ['status' => $pos_status];
        // Das Zahldatum wird beim ersten Mal gesetzt und danach nicht mehr angefasst;
        // wird der Vorgang zurückgenommen, fällt es wieder weg.
        if ($status === 'bezahlt') {
            $felder['bezahlt_am'] = current_time('mysql');
        } else {
            $felder['bezahlt_am'] = null;
        }
        // Ohne NULL über prepare(): das würde zu '' und ist in MySQL kein gültiges Datum.
        if ($felder['bezahlt_am'] === null) {
            $wpdb->query($wpdb->prepare(
                'UPDATE ' . self::t_position() . " SET status = %s, bezahlt_am = NULL
                  WHERE vorgang_id = %d AND status <> 'storniert'", $felder['status'], (int) $id));
        } else {
            $wpdb->query($wpdb->prepare(
                'UPDATE ' . self::t_position() . " SET status = %s, bezahlt_am = %s
                  WHERE vorgang_id = %d AND status <> 'storniert'",
                $felder['status'], $felder['bezahlt_am'], (int) $id));
        }
        return true;
    }

    /**
     * Eine einzelne Position stornieren – für Teilabholungen. Wer von zehn reservierten
     * Stühlen nur sechs nimmt, bekommt die übrigen vier zurück in den Katalog.
     * Sind danach alle Positionen storniert, wird der ganze Vorgang storniert.
     */
    public static function position_stornieren($vorgang_id, $position_id) {
        global $wpdb;
        $wpdb->update(self::t_position(), ['status' => 'storniert', 'bezahlt_am' => null],
            ['id' => (int) $position_id, 'vorgang_id' => (int) $vorgang_id]);
        $rest = (int) $wpdb->get_var($wpdb->prepare(
            'SELECT COUNT(*) FROM ' . self::t_position() . " WHERE vorgang_id = %d AND status <> 'storniert'",
            (int) $vorgang_id));
        if ($rest === 0) {
            $wpdb->update(self::t_vorgang(), ['status' => 'storniert'], ['id' => (int) $vorgang_id]);
        }
        return $rest;
    }

    /**
     * Bearbeitungsfelder eines Vorgangs (1.3.0): fester Abholtermin „Y-m-d H:i“, Rechnungsnummer
     * und -datum aus DATEV, interne Notiz, Anrede Du/Sie für die Mailvorlage.
     * Ungültige Datumsangaben werden verworfen statt halb gespeichert.
     */
    public static function vorgang_bearbeiten($id, array $f) {
        global $wpdb;
        $neu = [];
        if (array_key_exists('abholung', $f)) {
            $a = trim((string) $f['abholung']);
            $neu['abholung'] = preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $a) ? $a : '';
        }
        if (array_key_exists('rechnungsnr', $f)) {
            $neu['rechnungsnr'] = substr(trim((string) $f['rechnungsnr']), 0, 40);
            // 1.15.0: neue Rechnungsnummer nach nachträglich hinzugefügten Artikeln = Rechnung ist korrigiert
            $alt = self::vorgang($id);
            if ($alt && (string) $alt['rechnungsnr'] !== $neu['rechnungsnr']) { $neu['rg_korrektur'] = 0; }
        }
        if (array_key_exists('zahlart', $f) && in_array($f['zahlart'], ['', 'ueberweisung', 'bar'], true)) { $neu['zahlart'] = $f['zahlart']; }
        if (array_key_exists('rechnung_am', $f)) {
            $r = trim((string) $f['rechnung_am']);
            $neu['rechnung_am'] = preg_match('/^\d{4}-\d{2}-\d{2}$/', $r) ? $r : '';
        }
        if (array_key_exists('notiz', $f)) { $neu['notiz'] = (string) $f['notiz']; }
        if (array_key_exists('du', $f)) { $neu['du'] = $f['du'] ? 1 : 0; }
        if (!$neu) { return false; }
        return $wpdb->update(self::t_vorgang(), $neu, ['id' => (int) $id]) !== false;
    }

    // ------------------------------------------------------------ 1.8.0: Preis je Position

    /** Betrag einer Position: der Festpreis, wenn einer vereinbart ist, sonst Stückpreis × Menge. */
    public static function pos_betrag($p) {
        if (isset($p['festpreis']) && $p['festpreis'] !== null && $p['festpreis'] !== '') { return round((float) $p['festpreis'], 2); }
        return round((float) $p['preis_netto'] * (int) $p['menge'], 2);
    }

    /** Stückpreis einer Position – beim Festpreis der rechnerische (kann mehr als zwei Nachkommastellen haben). */
    public static function pos_stueck($p) {
        $m = (int) $p['menge'];
        return $m > 0 ? self::pos_betrag($p) / $m : (float) $p['preis_netto'];
    }

    /**
     * Preis einer Position ändern: $art 'stueck' (neuer Stückpreis) oder 'gesamt' (Festpreis für die ganze
     * Position, wird genau so gespeichert). Nur solange der Vorgang offen oder bestellt ist – danach steht
     * die Rechnung. Der ursprüngliche Katalogpreis bleibt in preis_original, die Änderung in der Notiz.
     */
    public static function preis_setzen($vorgang_id, $position_id, $wert, $art = 'stueck', $notiz = true) {
        global $wpdb;
        $v = self::vorgang($vorgang_id);
        if (!$v) { return new WP_Error('fehlt', 'Vorgang nicht gefunden.'); }
        if (!in_array($v['status'], ['offen', 'bestellt'], true)) {
            return new WP_Error('gesperrt', 'Der Preis lässt sich nur ändern, solange der Vorgang offen oder bestellt ist.');
        }
        $p = null;
        foreach ($v['positionen'] as $x) { if ((int) $x['id'] === (int) $position_id) { $p = $x; } }
        if (!$p || $p['status'] === 'storniert') { return new WP_Error('position', 'Position nicht gefunden.'); }
        $wert = round((float) $wert, 2);
        if ($wert < 0) { return new WP_Error('wert', 'Der Preis darf nicht negativ sein.'); }
        $vorher = self::pos_betrag($p);
        $original = ($p['preis_original'] ?? null) !== null && $p['preis_original'] !== '' ? (float) $p['preis_original'] : (float) $p['preis_netto'];
        $menge = max(1, (int) $p['menge']);
        $felder = $art === 'gesamt'
            ? ['festpreis' => $wert, 'preis_netto' => round($wert / $menge, 2)]
            : ['festpreis' => null, 'preis_netto' => $wert];
        $felder['preis_original'] = $original;
        // NULL für festpreis: über prepare() würde daraus '' – deshalb eigene Abfrage
        if ($felder['festpreis'] === null) {
            $wpdb->query($wpdb->prepare('UPDATE ' . self::t_position() . ' SET festpreis = NULL, preis_netto = %f, preis_original = %f WHERE id = %d',
                $felder['preis_netto'], $original, (int) $position_id));
        } else {
            $wpdb->update(self::t_position(), $felder, ['id' => (int) $position_id]);
        }
        if ($notiz) {
            $eur = function ($w) { return number_format($w, 2, ',', '.') . ' €'; };
            $neu = $art === 'gesamt' ? $wert : $wert * (int) $p['menge'];
            $text = gmdate('d.m.', current_time('timestamp')) . ': ' . $p['artnr'] . ' ' . $eur($vorher) . ' → ' . $eur($neu)
                . ($art === 'gesamt' ? ' (Festpreis)' : ' (' . $eur($wert) . ' je Stück)');
            $alt = trim((string) ($v['notiz'] ?? ''));
            $wpdb->update(self::t_vorgang(), ['notiz' => ltrim($alt . ' · ' . $text, ' ·')], ['id' => (int) $vorgang_id]);
        }
        return true;
    }

    /**
     * 1.11.1: Artikel einer Position tauschen – der Käufer hat ein anderes Stück mitgenommen als reserviert.
     * Geht in jedem Status außer storniert, auch nach Bezahlung und Abholung. Preis und Menge bleiben,
     * nur die Artikelnummer wechselt; der alte Artikel ist damit wieder frei, der neue belegt.
     * Die Notiz am Vorgang hält den Tausch fest („21.10.: BU04-14 → BA07-03 getauscht“).
     */
    public static function position_tauschen($vorgang_id, $position_id, $neu_artnr) {
        global $wpdb;
        $v = self::vorgang($vorgang_id);
        if (!$v) { return new WP_Error('fehlt', 'Vorgang nicht gefunden.'); }
        if ($v['status'] === 'storniert') { return new WP_Error('gesperrt', 'Der Vorgang ist storniert.'); }
        $p = null;
        foreach ($v['positionen'] as $x) { if ((int) $x['id'] === (int) $position_id) { $p = $x; } }
        if (!$p || $p['status'] === 'storniert') { return new WP_Error('position', 'Position nicht gefunden.'); }
        $neu = strtoupper(trim((string) $neu_artnr));
        if ($neu === '' || $neu === strtoupper($p['artnr'])) { return new WP_Error('nr', 'Bitte eine andere Artikelnummer eintragen.'); }
        $da = $wpdb->get_var($wpdb->prepare('SELECT artnr FROM ' . self::t_artikel() . ' WHERE artnr = %s AND aktiv = 1', $neu));
        if (!$da) { return new WP_Error('nr', 'Artikel ' . $neu . ' gibt es nicht oder er ist stillgelegt.'); }
        $frei = self::frei($da);
        if ($frei < (int) $p['menge']) {
            return new WP_Error('frei', sprintf('Von %s sind nur %d Stück frei, die Position hat %d.', $da, $frei, (int) $p['menge']));
        }
        $wpdb->update(self::t_position(), ['artnr' => $da], ['id' => (int) $position_id]);
        $text = gmdate('d.m.', current_time('timestamp')) . ': ' . $p['artnr'] . ' → ' . $da . ' getauscht';
        $alt = trim((string) ($v['notiz'] ?? ''));
        $wpdb->update(self::t_vorgang(), ['notiz' => ltrim($alt . ' · ' . $text, ' ·')], ['id' => (int) $vorgang_id]);
        return true;
    }

    /**
     * Rabatt-Angabe der Zusatzbestellung lesen: „10 %“ / „10%“ -> ['prozent', 10], „= 40“ / „=40 €“ -> ['gesamt', 40],
     * leer -> null, Unlesbares -> WP_Error.
     */
    public static function rabatt_aus_text($text) {
        $t = trim(str_replace(['€', ' '], '', (string) $text));
        if ($t === '') { return null; }
        if (preg_match('/^(\d+(?:[.,]\d+)?)%$/', $t, $m)) {
            $w = (float) str_replace(',', '.', $m[1]);
            return ($w > 0 && $w <= 100) ? ['prozent', $w] : new WP_Error('rabatt', 'Rabatt bitte zwischen 0 und 100 % angeben.');
        }
        if (preg_match('/^=(\d+(?:[.,]\d{1,2})?)$/', $t, $m)) { return ['gesamt', (float) str_replace(',', '.', $m[1])]; }
        return new WP_Error('rabatt', 'Rabatt bitte als „10 %“ oder als Festpreis „= 40“ eintragen.');
    }

    /**
     * 1.8.1: Rabatt aus zwei Feldern – Betrag und Art (prozent | gesamt | stueck). Leerer Betrag = kein Rabatt.
     * Betrag wie „150“, „150 €“, „29,50“ oder „10 %“ – Zeichen drumherum stören nicht.
     */
    public static function rabatt_aus_feldern($wert, $art) {
        $t = trim(str_replace(['€', '%', ' ', "\xc2\xa0", '='], '', (string) $wert));
        if ($t === '') { return null; }
        if (!preg_match('/^\d+(?:[.,]\d{1,2})?$/', $t)) {
            return new WP_Error('rabatt', 'Rabatt: bitte nur eine Zahl eintragen, z. B. 150 oder 10.');
        }
        $w = (float) str_replace(',', '.', $t);
        if ($art === 'prozent') {
            return ($w > 0 && $w <= 100) ? ['prozent', $w] : new WP_Error('rabatt', 'Rabatt bitte zwischen 0 und 100 % angeben.');
        }
        if (in_array($art, ['gesamt', 'stueck'], true)) { return [$art, $w]; }
        return new WP_Error('rabatt', 'Rabatt: bitte auswählen, ob die Zahl Prozent, ein Festpreis oder ein Stückpreis ist.');
    }

    /**
     * 1.7.0: Zusatzbestellung zu einem bestehenden Vorgang – eigener Vorgang mit eigener Rechnung,
     * gleichen Kontaktdaten und gleichem Abholtermin, ohne Mindestbestellwert. Geht bei jedem Stand,
     * solange der Vorgang nicht storniert oder schon abgeholt ist. Gibt die neue Nummer zurück.
     */
    /**
     * 1.15.0: Artikel in DENSELBEN Vorgang aufnehmen (gleiche Bestellung, gleiche Rechnung) – solange er offen oder
     * bestellt und nicht abgeholt ist. Ist schon eine Rechnungsnummer eingetragen, wird der Vorgang markiert:
     * „Rechnung in DATEV korrigieren“, bis eine neue Nummer eingetragen ist. Gibt ['korrektur' => bool] zurück.
     */
    public static function positionen_hinzufuegen($id, array $wunsch, $rabatt = null) {
        global $wpdb;
        if (is_wp_error($rabatt)) { return $rabatt; }
        if ($rabatt && $rabatt[0] === 'stueck' && count($wunsch) !== 1) {
            return new WP_Error('rabatt', 'Ein Stückpreis geht nur bei genau einem Artikel – bei mehreren „Festpreis gesamt“ wählen.');
        }
        $v = self::vorgang($id);
        if (!$v) { return new WP_Error('fehlt', 'Vorgang nicht gefunden.'); }
        if (!in_array($v['status'], ['offen', 'bestellt'], true) || trim((string) ($v['abgeholt_am'] ?? '')) !== '') {
            return new WP_Error('separat', 'Der Vorgang ist schon bezahlt oder abgeholt.');
        }
        $wpdb->query('START TRANSACTION');
        $neu = [];
        foreach ($wunsch as $artnr => $menge) {
            $menge = (int) $menge;
            if ($menge <= 0) { continue; }
            $a = $wpdb->get_row($wpdb->prepare('SELECT artnr, menge, preis_netto FROM ' . self::t_artikel()
                . ' WHERE artnr = %s AND aktiv = 1 AND im_katalog = 1 FOR UPDATE', $artnr), ARRAY_A);
            if (!$a) { $wpdb->query('ROLLBACK'); return new WP_Error('unbekannt', sprintf('Artikel %s ist nicht im Katalog.', $artnr)); }
            $frei = self::frei($a['artnr']);
            if ($menge > $frei) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('zu_wenig', sprintf('Von %s sind nur noch %d Stück frei.', $a['artnr'], max(0, $frei)));
            }
            $wpdb->insert(self::t_position(), ['vorgang_id' => (int) $id, 'artnr' => $a['artnr'], 'menge' => $menge,
                'preis_netto' => (float) $a['preis_netto'], 'status' => 'reserviert']);
            $neu[] = ['id' => (int) $wpdb->insert_id, 'artnr' => $a['artnr'], 'menge' => $menge];
        }
        if (!$neu) { $wpdb->query('ROLLBACK'); return new WP_Error('leer', 'Es wurden keine Artikel angegeben.'); }
        $wpdb->query('COMMIT');
        if ($rabatt) { self::rabatt_anwenden($id, array_column($neu, 'id'), $rabatt); }
        $korrektur = trim((string) $v['rechnungsnr']) !== '';
        $text = gmdate('d.m.', current_time('timestamp')) . ': hinzugefügt ' . implode(', ', array_map(function ($p) {
            return $p['artnr'] . ($p['menge'] > 1 ? ' × ' . $p['menge'] : ''); }, $neu)) . ($korrektur ? ' – Rechnung korrigieren' : '');
        $notiz = trim((string) (self::vorgang($id)['notiz'] ?? ''));
        $felder = ['notiz' => ltrim($notiz . ' · ' . $text, ' ·')];
        if ($korrektur) { $felder['rg_korrektur'] = 1; }
        $wpdb->update(self::t_vorgang(), $felder, ['id' => (int) $id]);
        return ['korrektur' => $korrektur, 'anzahl' => count($neu)];
    }

    /** 1.15.0: Rabatt auf bestimmte Positionen eines Vorgangs (aus zusatz_anlegen herausgelöst). */
    private static function rabatt_anwenden($vorgang_id, array $pos_ids, $rabatt) {
        $pos = array_values(array_filter(self::vorgang($vorgang_id)['positionen'], function ($p) use ($pos_ids) {
            return in_array((int) $p['id'], array_map('intval', $pos_ids), true); }));
        if (!$pos) { return; }
        if ($rabatt[0] === 'gesamt') {
            $wert = array_sum(array_map([__CLASS__, 'pos_betrag'], $pos));
            $rest = round($rabatt[1], 2);
            foreach ($pos as $i => $p) {
                $teil = $i === count($pos) - 1 ? $rest
                    : ($wert > 0 ? round($rabatt[1] * self::pos_betrag($p) / $wert, 2) : round($rabatt[1] / count($pos), 2));
                $rest = round($rest - $teil, 2);
                self::preis_setzen($vorgang_id, $p['id'], $teil, 'gesamt');
            }
        } else {
            foreach ($pos as $p) {
                self::preis_setzen($vorgang_id, $p['id'], $rabatt[0] === 'stueck' ? $rabatt[1]
                    : round((float) $p['preis_netto'] * (1 - $rabatt[1] / 100), 2), 'stueck');
            }
        }
    }

    public static function zusatz_anlegen($basis_id, array $wunsch, $rabatt = null) {
        global $wpdb;
        if (is_wp_error($rabatt)) { return $rabatt; }
        if ($rabatt && $rabatt[0] === 'stueck' && count($wunsch) !== 1) {
            return new WP_Error('rabatt', 'Ein Stückpreis geht nur bei genau einem Artikel – bei mehreren „Festpreis gesamt“ wählen.');
        }
        $v = self::vorgang($basis_id);
        if (!$v) { return new WP_Error('fehlt', 'Vorgang nicht gefunden.'); }
        if ($v['status'] === 'storniert') { return new WP_Error('storniert', 'Der Vorgang ist storniert.'); }
        if (trim((string) ($v['abgeholt_am'] ?? '')) !== '') {
            return new WP_Error('abgeholt', 'Der Vorgang ist schon abgeholt – bitte eine neue Reservierung anlegen.');
        }
        if ((int) $v['kontakt_weg'] === 1 || trim((string) $v['name']) === '') {
            return new WP_Error('kontakt', 'Zu diesem Vorgang sind keine Kontaktdaten mehr gespeichert.');
        }
        $kontakt = ['name' => $v['name'], 'email' => $v['email'], 'telefon' => $v['telefon'], 'nachricht' => '',
                    'firma' => $v['firma'] ?? '', 'strasse' => $v['strasse'] ?? '', 'plz' => $v['plz'] ?? '',
                    'ort' => $v['ort'] ?? '', 'abholwunsch' => $v['abholwunsch'] ?? '', 'demontage' => $v['demontage'] ?? 0];
        $neu = self::reservieren($kontakt, $wunsch);
        if (is_wp_error($neu)) { return $neu; }
        self::vorgang_status($neu, 'bestellt');                  // eigene Rechnung folgt, läuft nicht ab
        $wpdb->update(self::t_vorgang(), [
            'abholung'    => (string) ($v['abholung'] ?? ''),
            'abholtermin' => (string) ($v['abholtermin'] ?? ''),
            'du'          => (int) ($v['du'] ?? 0),
            'zahlart'     => (string) ($v['zahlart'] ?? ''),
            'testdaten'   => (int) ($v['testdaten'] ?? 0),
            'notiz'       => sprintf('Zusatz zu #%d – eigene Rechnung', (int) $basis_id),
        ], ['id' => (int) $neu]);
        $alt = trim((string) ($v['notiz'] ?? ''));
        $wpdb->update(self::t_vorgang(), ['notiz' => ltrim($alt . ' · Zusatz: #' . (int) $neu, ' ·')], ['id' => (int) $basis_id]);
        if ($rabatt) {                                            // 1.8.0: Rabatt gleich beim Anlegen
            $pos = self::vorgang($neu)['positionen'];
            if ($rabatt[0] === 'gesamt') {
                // Festpreis für den ganzen Zusatz: nach Katalogwert verteilt, der letzte bekommt den Rest
                // (so ergibt die Summe auf den Cent genau den Festpreis).
                $wert = array_sum(array_map([__CLASS__, 'pos_betrag'], $pos));
                $rest = round($rabatt[1], 2);
                foreach (array_values($pos) as $i => $p) {
                    $teil = $i === count($pos) - 1 ? $rest
                        : ($wert > 0 ? round($rabatt[1] * self::pos_betrag($p) / $wert, 2) : round($rabatt[1] / count($pos), 2));
                    $rest = round($rest - $teil, 2);
                    self::preis_setzen($neu, $p['id'], $teil, 'gesamt');
                }
            } else {
                foreach ($pos as $p) {
                    self::preis_setzen($neu, $p['id'], $rabatt[0] === 'stueck' ? $rabatt[1]
                        : round((float) $p['preis_netto'] * (1 - $rabatt[1] / 100), 2), 'stueck');
                }
            }
        }
        return (int) $neu;
    }

    /** „BU01-10 x 3, NE04-19“ -> ['BU01-10' => 3, 'NE04-19' => 1]. Leere oder unlesbare Teile fallen weg. */
    public static function wunsch_aus_text($text) {
        $out = [];
        foreach (preg_split('/[,;\n]+/', (string) $text) as $teil) {
            if (!preg_match('/^\s*([A-Za-z]{1,4}\d{0,3}-[A-Za-z]?\d{1,3})\s*(?:[x×*]\s*(\d+))?\s*$/u', $teil, $m)) { continue; }
            $nr = strtoupper($m[1]);
            $out[$nr] = ($out[$nr] ?? 0) + max(1, (int) ($m[2] ?? 1));
        }
        return $out;
    }

    /**
     * Abgeholt vermerken (Datum) oder zurücknehmen (leer). Wer abholt, hat bezahlt –
     * ein noch „bestellter“ Vorgang wird dabei auf bezahlt gesetzt (z. B. Barzahlung vor Ort).
     */
    public static function abgeholt_setzen($id, $datum) {
        global $wpdb;
        $v = self::vorgang($id);
        if (!$v || $v['status'] === 'storniert') { return false; }
        if ($datum !== '' && $v['status'] !== 'bezahlt') { self::vorgang_status($id, 'bezahlt'); }
        return $wpdb->update(self::t_vorgang(), ['abgeholt_am' => (string) $datum], ['id' => (int) $id]) !== false;
    }

    /** Vereinbarten Abholtermin am Vorgang vermerken (freier Text, z. B. „Di 13.10., 9 Uhr“). */
    public static function abholtermin_setzen($id, $termin) {
        global $wpdb;
        return $wpdb->update(self::t_vorgang(), ['abholtermin' => (string) $termin], ['id' => (int) $id]);
    }

    public static function frist_werktage() {
        return max(1, (int) get_option('kikripp_frist_werktage', 3));
    }

    /**
     * Ende der Reservierung: n Werktage (Montag bis Freitag) nach dem Eingang, jeweils
     * bis zum Ende des letzten Tages. Eingang Freitag 15 Uhr, drei Werktage → Mittwoch 23:59.
     * Feiertage zählen mit; das sind im Verkaufszeitraum Oktober bis Dezember in
     * Baden-Württemberg nur Allerheiligen, und der fällt 2026 auf einen Sonntag.
     */
    public static function ablauf_nach_werktagen($start, $werktage) {
        $t = strtotime(substr((string) $start, 0, 10) . ' 12:00:00 UTC');
        $gezaehlt = 0;
        while ($gezaehlt < max(1, (int) $werktage)) {
            $t += DAY_IN_SECONDS;
            if ((int) gmdate('N', $t) <= 5) { $gezaehlt++; }
        }
        return gmdate('Y-m-d', $t) . ' 23:59:59';
    }

    /**
     * 1.9.0: „Warte auf Rückinfo“ – der Vorgang ruht, bis die Rückmeldung da ist oder die Wiedervorlage
     * erreicht ist. Eine offene Reservierung läuft solange nicht ab (die Frist steht).
     */
    public static function warten_setzen($id, $notiz, $bis = '') {
        global $wpdb;
        $v = self::vorgang($id);
        if (!$v || in_array($v['status'], ['storniert'], true)) { return false; }
        $bis = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $bis) ? $bis : '';
        return $wpdb->update(self::t_vorgang(), [
            'warte_seit'  => trim((string) ($v['warte_seit'] ?? '')) !== '' ? $v['warte_seit'] : current_time('mysql'),
            'warte_notiz' => substr(trim((string) $notiz), 0, 255),
            'warte_bis'   => $bis,
        ], ['id' => (int) $id]) !== false;
    }

    /** Rückinfo ist da: Warten beenden. Bei offener Reservierung wird die Frist um die Wartezeit verlängert. */
    public static function warten_beenden($id) {
        global $wpdb;
        $v = self::vorgang($id);
        if (!$v || trim((string) ($v['warte_seit'] ?? '')) === '') { return false; }
        $felder = ['warte_seit' => '', 'warte_notiz' => '', 'warte_bis' => ''];
        if ($v['status'] === 'offen') {
            $pause = max(0, strtotime(current_time('mysql')) - strtotime($v['warte_seit']));
            $felder['ablauf'] = gmdate('Y-m-d H:i:s', strtotime($v['ablauf']) + $pause);
        }
        return $wpdb->update(self::t_vorgang(), $felder, ['id' => (int) $id]) !== false;
    }

    /**
     * 1.10.0: Kommissionieren – eine Position (oder mit $position_id = 0 alle laufenden Positionen)
     * als bereitgestellt abhaken bzw. den Haken wieder wegnehmen. Stornierte Positionen werden hier
     * nicht angefasst; für sie gibt es zurueckgeraeumt().
     */
    public static function kommissionieren($vorgang_id, $position_id, $an) {
        global $wpdb;
        $v = self::vorgang($vorgang_id);
        if (!$v || $v['status'] === 'storniert') { return false; }
        $wert = $an ? current_time('mysql') : '';
        $sql = 'UPDATE ' . self::t_position() . " SET kommissioniert = %s WHERE vorgang_id = %d AND status <> 'storniert'";
        $args = [$wert, (int) $vorgang_id];
        if ((int) $position_id > 0) { $sql .= ' AND id = %d'; $args[] = (int) $position_id; }
        if ($an) { $sql .= " AND kommissioniert = ''"; }     // erster Haken bleibt mit seiner Zeit stehen
        return $wpdb->query($wpdb->prepare($sql, $args)) !== false;
    }

    /** 1.10.0: Ware einer Stornierung ist zurückgeräumt – Haken an allem entfernen, was zurück muss. */
    public static function zurueckgeraeumt($vorgang_id) {
        global $wpdb;
        $v = self::vorgang($vorgang_id);
        if (!$v) { return 0; }
        $n = 0;
        foreach (Kikripp_Ablauf::zurueckraeumen($v) as $p) {
            $n += (int) $wpdb->update(self::t_position(), ['kommissioniert' => ''], ['id' => (int) $p['id']]);
        }
        return $n;
    }

    public static function vorgang_verlaengern($id) {
        global $wpdb;
        $neu = self::ablauf_nach_werktagen(current_time('mysql'), self::frist_werktage());
        return (bool) $wpdb->update(self::t_vorgang(),
            ['ablauf' => $neu, 'status' => 'offen'], ['id' => (int) $id]);
    }

    public static function vorgang_loeschen($id) {
        global $wpdb;
        $wpdb->delete(self::t_position(), ['vorgang_id' => (int) $id]);
        return (bool) $wpdb->delete(self::t_vorgang(), ['id' => (int) $id]);
    }

    public static function testdaten_loeschen() {
        global $wpdb;
        $ids = $wpdb->get_col("SELECT id FROM " . self::t_vorgang() . " WHERE testdaten = 1");
        foreach ($ids as $id) { self::vorgang_loeschen($id); }
        return count($ids);
    }
}
