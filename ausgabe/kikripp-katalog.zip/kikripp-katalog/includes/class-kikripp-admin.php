<?php
if (!defined('ABSPATH')) { exit; }

/** Verwaltung im WordPress-Backend: Reservierungen, Import, Einstellungen. */
class Kikripp_Admin {

    public static function start() {
        add_action('admin_menu', [__CLASS__, 'menue']);
        add_action('admin_post_kikripp_aktion', [__CLASS__, 'aktion']);
        add_action('admin_post_kikripp_import', [__CLASS__, 'import']);
        add_action('admin_post_kikripp_einstellungen', [__CLASS__, 'einstellungen_speichern']);
        add_action('admin_post_kikripp_export', [__CLASS__, 'export']);
        add_action('admin_post_kikripp_termin', [__CLASS__, 'termin_speichern']);
        add_action('admin_post_kikripp_vorgang', [__CLASS__, 'vorgang_speichern']);
        add_action('admin_post_kikripp_zusatz', [__CLASS__, 'zusatz_speichern']);
        add_action('admin_post_kikripp_preis', [__CLASS__, 'preis_speichern']);
        add_action('admin_post_kikripp_tausch', [__CLASS__, 'tausch_speichern']);
        add_action('admin_post_kikripp_warten', [__CLASS__, 'warten_speichern']);
        add_action('admin_post_kikripp_bestellung', [__CLASS__, 'bestellung']);
        add_action('admin_notices', [__CLASS__, 'hinweis_passwort']);
    }

    /** Ohne Passwort bleibt der Katalog für alle zu – das muss auffallen. */
    public static function hinweis_passwort() {
        if (!current_user_can('manage_options')) { return; }
        if (!Kikripp_Zugang::passwortschutz()) { return; }
        if (get_option('kikripp_passwort_hash')) { return; }
        printf('<div class="notice notice-warning"><p><strong>Artikelkatalog:</strong> '
             . 'Es ist noch kein Passwort vergeben – der Katalog ist deshalb für alle gesperrt. '
             . '<a href="%s">Jetzt Passwort festlegen</a></p></div>',
             esc_url(admin_url('admin.php?page=kikripp-einstellungen')));
    }

    /**
     * Zahl der offenen Reservierungen als Blase am Menuepunkt - wie bei Plugin-Updates.
     *
     * Der Webserver dieser Website verschickt keine Mails. Ohne diese Blase muesste die
     * Nutzerin daran denken, jeden Tag in die Reservierungen zu schauen; mit ihr sieht
     * sie es beim Einloggen. Das ersetzt die Benachrichtigungsmail.
     */
    private static function offene_blase() {
        // Seit 1.3.0: Zahl der Aufgaben aus „Zu erledigen“, die etwas verlangen – nicht mehr nur
        // die neuen Reservierungen. Eine unbezahlte Abholung morgen muss genauso auffallen.
        $n = count(array_filter(Kikripp_Ablauf::aufgaben(Kikripp_DB::vorgaenge()),
            function ($a) { return $a['art'] === 'warn'; }));
        if ($n < 1) { return ''; }
        return sprintf(' <span class="update-plugins count-%d"><span class="plugin-count">%d'
                     . '</span></span>', $n, $n);
    }

    public static function menue() {
        $blase = self::offene_blase();
        add_menu_page('Artikelkatalog', 'Artikelkatalog' . $blase, 'manage_options',
            'kikripp-reservierungen', [__CLASS__, 'seite_reservierungen'], 'dashicons-cart', 26);
        add_submenu_page('kikripp-reservierungen', 'Reservierungen', 'Reservierungen' . $blase,
            'manage_options', 'kikripp-reservierungen', [__CLASS__, 'seite_reservierungen']);
        add_submenu_page('kikripp-reservierungen', 'Artikel importieren', 'Artikel importieren',
            'manage_options', 'kikripp-import', [__CLASS__, 'seite_import']);
        add_submenu_page('kikripp-reservierungen', 'Einstellungen', 'Einstellungen',
            'manage_options', 'kikripp-einstellungen', [__CLASS__, 'seite_einstellungen']);
    }

    private static function hinweis() {
        if (isset($_GET['kikripp_meldung'])) {
            $art = isset($_GET['kikripp_fehler']) ? 'error' : 'success';
            printf('<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
                esc_attr($art), esc_html(wp_unslash($_GET['kikripp_meldung'])));
        }
    }

    private static function zurueck($seite, $meldung, $fehler = false, $anker = '', $reiter_fest = null) {
        // Aus dem Abholplan heraus geklickt? Dann dorthin zurück, nicht in die Reservierungen.
        $herkunft = (string) wp_get_referer();
        if ($seite === 'kikripp-reservierungen' && strpos($herkunft, 'page=kikripp-abholplan') !== false) {
            $seite = 'kikripp-abholplan';
        }
        $reiter = null;
        if (preg_match('/[?&]reiter=([a-z_]+)/', $herkunft, $m)) { $reiter = $m[1]; }
        if ($reiter_fest !== null) { $reiter = $reiter_fest; }
        $url = add_query_arg(array_filter([
            'page' => $seite,
            'reiter' => $seite === 'kikripp-reservierungen' ? $reiter : null,
            'kikripp_meldung' => $meldung,
            'kikripp_fehler' => $fehler ? '1' : null,
            // 1.8.1: die Seite springt zum Vorgang – dort muss die Meldung auch stehen, sonst sieht man sie nicht
            'kikripp_vorgang' => preg_match('/^vorgang-(\d+)$/', $anker, $m2) ? $m2[1] : null,
        ]), admin_url('admin.php'));
        wp_safe_redirect($url . ($anker !== '' ? '#' . $anker : ''));
        exit;
    }

    // ---------------------------------------------------------------- Reservierungen

    /** Statusbezeichnung für die Liste. */
    private static function status_text($v, $jetzt) {
        if ($v['status'] === 'offen') {
            return strtotime($v['ablauf']) < $jetzt
                ? '<span style="color:#b32d2e">abgelaufen</span>' : 'reserviert';
        }
        if ($v['status'] === 'bestellt') { return '<strong>bestellt</strong>'; }
        return esc_html($v['status']);
    }

    public static function aktion_url($was, $id, $extra = []) {
        return wp_nonce_url(add_query_arg(array_merge(['action' => 'kikripp_aktion', 'was' => $was,
            'id' => (int) $id], $extra), admin_url('admin-post.php')), 'kikripp_aktion_' . (int) $id);
    }

    const REITER = ['zu_tun' => 'Zu tun', 'warten' => 'Warte auf Rückinfo', 'zahlung' => 'Wartet auf Zahlung', 'abholung' => 'Wartet auf Abholung',
                    'fertig' => 'Abgeschlossen', 'erledigt' => 'Storniert / abgelaufen', 'alle' => 'Alle'];

    /**
     * Reservierungen (1.4.0): Reiter nach „Wer ist dran?“, eine kompakte Zeile je Vorgang mit
     * „Nächster Schritt“ und einem Hauptknopf, Details aufklappbar, Suchfeld. Farben aus WordPress:
     * Blau = du bist dran, Rot = dringend, Grau = wartet, Hellgrau = erledigt.
     */
    public static function seite_reservierungen() {
        if (!current_user_can('manage_options')) { return; }
        $vorgaenge = Kikripp_DB::vorgaenge();
        $jetzt = current_time('timestamp');
        echo '<div class="wrap"><h1>Reservierungen</h1>';
        self::hinweis();

        $k = Kikripp_Ablauf::kennzahlen($vorgaenge, $jetzt);
        echo '<p style="font-size:14px;background:#fff;border:1px solid #c3c4c7;padding:8px 12px;display:inline-block;margin:6px 0">'
           . 'Umsatz bezahlt: <strong>' . esc_html(Kikripp_Mail::eur($k['bezahlt'])) . '</strong> &nbsp;·&nbsp; '
           . 'Rechnungen offen: <strong>' . esc_html(Kikripp_Mail::eur($k['rechnung_offen'])) . '</strong> &nbsp;·&nbsp; '
           . 'bestellt, ohne Rechnung: <strong>' . esc_html(Kikripp_Mail::eur($k['ohne_rechnung'])) . '</strong> &nbsp;·&nbsp; '
           . 'reserviert: <strong>' . esc_html(Kikripp_Mail::eur($k['reserviert'])) . '</strong></p>';

        $aufgaben = Kikripp_Ablauf::aufgaben($vorgaenge, $jetzt);
        $je_vorgang = [];
        foreach ($aufgaben as $a) { $je_vorgang[$a['id']][] = $a; }
        $stand = [];
        $zahl = array_fill_keys(array_keys(self::REITER), 0);
        foreach ($vorgaenge as $v) {
            $stand[$v['id']] = Kikripp_Ablauf::stand($v, $je_vorgang[$v['id']] ?? [], $jetzt);
            $zahl[$stand[$v['id']]['reiter']]++; $zahl['alle']++;
        }

        // Suche (1.10.0: filtert beim Tippen, auch nach Bezeichnung, Müller = Mueller) und Filter „kommissioniert“
        $suche = sanitize_text_field(wp_unslash($_GET['suche'] ?? ''));
        $filter = sanitize_key($_GET['kommi'] ?? '');
        if (!isset(Kikripp_Ablauf::KOMMI_FILTER[$filter])) { $filter = ''; }
        $optionen = '';
        foreach (Kikripp_Ablauf::KOMMI_FILTER as $schluessel => $name) {
            $optionen .= '<option value="' . esc_attr($schluessel) . '"' . ($filter === $schluessel ? ' selected' : '') . '>' . esc_html($name) . '</option>';
        }
        echo '<form method="get" style="float:right;margin:8px 0" onsubmit="kikFilter();return false"><input type="hidden" name="page" value="kikripp-reservierungen">'
           . '<input type="search" id="kik-suche" name="suche" value="' . esc_attr($suche) . '" placeholder="Name, Artikel, Rechnungsnr., Telefon …" style="width:280px" oninput="kikFilter()" autocomplete="off"> '
           . '<label style="margin-left:6px">📦 Kommissioniert: <select id="kik-kommi" name="kommi" onchange="kikFilter()">' . $optionen . '</select></label> '
           . '<a href="#" id="kik-zurueck" onclick="kikZuruecksetzen();return false"' . ($suche === '' && $filter === '' ? ' style="display:none"' : '') . '>zurücksetzen</a>'
           . '</form>';

        // Zu erledigen – auf dieser Seite zugeklappt, der Reiter „Zu tun“ zeigt dasselbe
        $warn = count(array_filter($aufgaben, function ($a) { return $a['art'] === 'warn'; }));
        echo '<details style="clear:left;background:#fff;border:1px solid #c3c4c7;border-left:4px solid #2271b1;padding:6px 12px;margin:8px 0;max-width:1100px">'
           . '<summary style="cursor:pointer"><strong>Zu erledigen:</strong> ' . $warn . ' Aufgabe' . ($warn === 1 ? '' : 'n')
           . (count($aufgaben) > $warn ? ' · ' . (count($aufgaben) - $warn) . ' Hinweis(e)' : '') . ' – anzeigen</summary>'
           . '<div style="margin-top:6px">' . Kikripp_Ablauf::aufgaben_html($aufgaben) . '</div></details>';

        $reiter = sanitize_key($_GET['reiter'] ?? 'zu_tun');
        if (!isset(self::REITER[$reiter])) { $reiter = 'zu_tun'; }
        echo '<nav class="nav-tab-wrapper" id="kik-reiter" style="clear:both;margin-bottom:10px">';
        foreach (self::REITER as $schluessel => $name) {
            $aktiv = $suche === '' && $schluessel === $reiter;
            echo '<a class="nav-tab' . ($aktiv ? ' nav-tab-active' : '') . '" data-reiter="' . esc_attr($schluessel) . '" href="'
               . esc_url(admin_url('admin.php?page=kikripp-reservierungen&reiter=' . $schluessel . ($filter !== '' ? '&kommi=' . $filter : ''))) . '">'
               . esc_html($name) . ' <span style="color:' . ($schluessel === 'zu_tun' && $zahl[$schluessel] ? '#2271b1;font-weight:600' : '#646970') . '">('
               . $zahl[$schluessel] . ')</span></a>';
        }
        echo '</nav>';

        // Alle Vorgänge stehen auf der Seite – zuerst die des Reiters in seiner Reihenfolge, dahinter (versteckt)
        // die übrigen, damit die Suche beim Tippen über alle Reiter findet, ohne neu zu laden.
        $im_reiter = function ($v) use ($reiter, $stand) { return $reiter === 'alle' || $stand[$v['id']]['reiter'] === $reiter; };
        $vorne = array_values(array_filter($vorgaenge, $im_reiter));
        $hinten = array_values(array_filter($vorgaenge, function ($v) use ($im_reiter) { return !$im_reiter($v); }));
        // Reihenfolge: Zu tun nach Dringlichkeit, Warten nach Abholtermin, Abgeschlossen neueste zuerst
        usort($vorne, function ($a, $b) use ($stand, $reiter) {
            $sa = $stand[$a['id']]; $sb = $stand[$b['id']];
            if (in_array($reiter, ['zahlung', 'abholung'], true)) {
                $ta = ($a['abholung'] ?? '') ?: '9999'; $tb = ($b['abholung'] ?? '') ?: '9999';
                return [$ta, $a['id']] <=> [$tb, $b['id']];
            }
            if ($reiter === 'fertig') { return [$b['abgeholt_am'] ?? '', $b['id']] <=> [$a['abgeholt_am'] ?? '', $a['id']]; }
            if ($reiter === 'zu_tun') { return [$sa['rang'], $a['id']] <=> [$sb['rang'], $b['id']]; }
            return $b['id'] <=> $a['id'];
        });
        usort($hinten, function ($a, $b) { return $b['id'] <=> $a['id']; });

        echo '<p style="margin:4px 0 8px"><a href="' . esc_url(admin_url('admin.php?page=kikripp-abholplan')) . '" class="button">Abholplan</a> '
           . '<a href="' . esc_url(admin_url('admin.php?page=kikripp-auswertung')) . '" class="button">Auswertung</a> '
           . '<a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=kikripp_export'), 'kikripp_export')) . '" class="button">Alle Reservierungen als CSV exportieren</a></p>';

        if (empty($vorgaenge)) {
            echo '<p>Es liegen noch keine Reservierungen vor.</p></div>';
            return;
        }

        // Was ist beim ersten Anzeigen sichtbar? Dieselbe Regel wie kikFilter() im Browser.
        $zeigen = function ($v) use ($im_reiter, $suche, $filter) {
            if ($filter !== '' && Kikripp_Ablauf::kommi($v)['stand'] !== $filter) { return false; }
            return $suche !== '' ? Kikripp_Ablauf::passt($v, $suche) : $im_reiter($v);
        };
        $treffer = count(array_filter($vorgaenge, $zeigen));
        echo '<p id="kik-treffer"' . ($suche === '' ? ' style="display:none"' : '') . '>'
           . ($suche !== '' ? 'Suchergebnis für „' . esc_html($suche) . '“ in allen Reitern: ' . $treffer . ' Vorgang/Vorgänge.' : '') . '</p>';
        echo '<p id="kik-leer"' . ($treffer ? ' style="display:none"' : '') . '>'
           . ($reiter === 'zu_tun' && $suche === '' && $filter === '' ? 'Nichts zu tun. 👍' : 'Hier ist nichts.') . '</p>';

        echo '<style>.kik-tab td{vertical-align:middle}.kik-tab tr.kik-zeile td{border-top:1px solid #dcdcde}'
           . '.kik-tab .kik-details td{background:#f6f7f7;border-top:0}.kik-tab .kik-auf{white-space:nowrap}'
           . '.kik-tab td.kik-balken{width:4px;padding:0}.kik-tab .kik-such{display:none;font-size:11px;color:#646970}'
           . '.kik-tab.kik-suchmodus .kik-such{display:block}.kik-kommi-badge{font-size:11px;color:#50575e}</style>';
        echo '<table class="widefat kik-tab' . ($suche !== '' ? ' kik-suchmodus' : '') . '" id="kik-tabelle"' . ($treffer ? '' : ' style="display:none"')
           . '><thead><tr><th class="kik-balken"></th><th>Nr.</th><th>Käufer</th><th>Artikel</th><th>Summe</th>'
           . '<th>Abholung</th><th>Rechnung</th><th>Nächster Schritt</th><th style="text-align:right">Aktion</th></tr></thead><tbody>';
        foreach (array_merge($vorne, $hinten) as $v) {
            echo self::zeile_html($v, $stand[$v['id']], $jetzt, $im_reiter($v), $zeigen($v));
        }
        echo '</tbody></table>';
        echo Kikripp_Ablauf::kommi_js();
        echo '<script>'
           . 'function kikAuf(id,zeigen){var d=document.getElementById("details-"+id),l=document.getElementById("auf-"+id);if(!d)return;'
           . 'var an=zeigen===undefined?d.hidden:zeigen;d.hidden=!an;if(l)l.textContent=an?"zuklappen ▴":"bearbeiten ▾";}'
           . 'function kikKopieren(id){var t=document.getElementById(id);if(!t)return;'
           . 'if(navigator.clipboard){navigator.clipboard.writeText(t.value);}else{t.style.display="block";t.select();document.execCommand("copy");t.style.display="none";}'
           . 'var m=document.getElementById(id+"-ok");if(m){m.style.display="inline";setTimeout(function(){m.style.display="none";},2000);}}'
           . 'var h=location.hash.match(/^#vorgang-(\d+)$/);if(h){var z=document.getElementById("vorgang-"+h[1]);'
           . 'if(z&&z.style.display==="none"){z.style.display="";document.getElementById("kik-tabelle").style.display="";'
           . 'document.getElementById("kik-leer").style.display="none";var d=document.getElementById("details-"+h[1]);if(d)d.style.display="";'
           . 'if(z.scrollIntoView)z.scrollIntoView();}kikAuf(h[1],true);}'
           // 1.10.0: Live-Suche und Filter „kommissioniert“ – dieselbe Regel wie Kikripp_Ablauf::passt()
           . 'function kikNorm(t){return (t||"").toLowerCase().replace(/ä/g,"ae").replace(/ö/g,"oe").replace(/ü/g,"ue").replace(/ß/g,"ss")'
           . '.replace(/[éè]/g,"e").replace(/\\s+/g," ").trim();}'
           . 'function kikPasst(z,q){if(q==="")return true;var id=z.getAttribute("data-id"),m=q.match(/^#(\\d+)$/);if(m)return m[1]===id;'
           . 'if(/^\\d+$/.test(q)&&String(parseInt(q,10))===id)return true;var heu=z.getAttribute("data-such");'
           . 'return q.split(" ").every(function(w){return heu.indexOf(w)>=0;});}'
           . 'function kikFilter(){var q=kikNorm(document.getElementById("kik-suche").value),k=document.getElementById("kik-kommi").value,n=0;'
           . 'document.querySelectorAll("#kik-tabelle tr.kik-zeile").forEach(function(z){'
           . 'var an=(k===""||z.getAttribute("data-kommi")===k)&&(q!==""?kikPasst(z,q):z.getAttribute("data-im-reiter")==="1");'
           . 'z.style.display=an?"":"none";var d=document.getElementById("details-"+z.getAttribute("data-id"));if(d)d.style.display=an?"":"none";if(an)n++;});'
           . 'document.getElementById("kik-tabelle").style.display=n?"":"none";document.getElementById("kik-tabelle").classList.toggle("kik-suchmodus",q!=="");'
           . 'var t=document.getElementById("kik-treffer");t.style.display=q!==""?"":"none";'
           . 't.textContent=q!==""?"Suchergebnis in allen Reitern: "+n+" Vorgang/Vorgänge.":"";'
           . 'var l=document.getElementById("kik-leer");l.style.display=n?"none":"";l.textContent="Hier ist nichts.";'
           . 'document.getElementById("kik-zurueck").style.display=(q!==""||k!=="")?"":"none";'
           . 'document.querySelectorAll("#kik-reiter .nav-tab").forEach(function(a){'
           . 'a.classList.toggle("nav-tab-active",q===""&&a.getAttribute("data-reiter")===' . wp_json_encode($reiter) . ');'
           . 'var u=new URL(a.href);if(k)u.searchParams.set("kommi",k);else u.searchParams.delete("kommi");a.href=u.toString();});'
           . 'try{var u=new URL(location.href);if(q)u.searchParams.set("suche",document.getElementById("kik-suche").value);else u.searchParams.delete("suche");'
           . 'if(k)u.searchParams.set("kommi",k);else u.searchParams.delete("kommi");'
           . 'u.searchParams.delete("kikripp_meldung");u.searchParams.delete("kikripp_fehler");u.searchParams.delete("kikripp_vorgang");'
           . 'history.replaceState(null,"",u.toString());}catch(e){}}'
           . 'function kikZuruecksetzen(){document.getElementById("kik-suche").value="";document.getElementById("kik-kommi").value="";kikFilter();'
           . 'document.getElementById("kik-suche").focus();}'
           . 'document.addEventListener("keydown",function(e){if(e.key==="Escape"&&document.activeElement&&document.activeElement.id==="kik-suche"){kikZuruecksetzen();}});'
           . '</script>';
        echo '</div>';
    }

    /** Eine kompakte Zeile plus aufklappbare Details. */
    private static function zeile_html($v, $st, $jetzt, $im_reiter = true, $zeigen = true) {
        $id = (int) $v['id'];
        $farbe = Kikripp_Ablauf::FARBE[$st['farbe']];
        $blass = $st['farbe'] === 'hell';
        $pos = Kikripp_Ablauf::positionen($v);
        $stueck = array_sum(array_column($pos, 'menge'));
        $wer = trim((string) $v['name']) !== '' || trim((string) ($v['firma'] ?? '')) !== ''
            ? '<strong>' . esc_html(trim((string) $v['name']) ?: $v['firma']) . '</strong>'
              . (trim((string) ($v['firma'] ?? '')) !== '' && trim((string) $v['name']) !== '' ? '<br><span style="font-size:12px;color:#646970">' . esc_html($v['firma']) . '</span>' : '')
            : '<span style="color:#8c8f94">Kontaktdaten gelöscht</span>';
        $titel = implode("\n", array_map(function ($p) { return $p['menge'] . ' × ' . $p['artnr'] . ' ' . $p['titel']; }, $pos));
        $abholung = trim((string) ($v['abholung'] ?? '')) !== ''
            ? esc_html(Kikripp_Ablauf::termin_text($v['abholung'], true))
            : (trim((string) ($v['abholwunsch'] ?? '')) !== '' ? '<span style="color:#8c8f94">Wunsch: ' . esc_html(Kikripp_Mail::abholung_text($v)) . '</span>' : '—');
        // 1.9.0: nichts klappt von selbst auf – offen ist nur der Vorgang, an dem gerade gearbeitet wurde (#vorgang-N)
        $offen = false;
        $kommi = Kikripp_Ablauf::kommi($v, $jetzt);       // 1.10.0
        $versteckt = $zeigen ? '' : 'display:none;';

        $knopf = '';
        if ($st['knopf']) {
            list($was, $text) = $st['knopf'];
            if ($was === 'aufklappen') {
                $knopf = '<a href="#" class="button button-primary" onclick="kikAuf(' . $id . ',true);return false">' . esc_html($text) . '</a>';
            } else {
                $frage = ['storniert' => 'Vorgang stornieren? Die Artikel sind dann wieder im Katalog.',
                          'kontakt' => 'Kontaktdaten zu diesem Vorgang endgültig löschen?',
                          'abgeholt' => ($v['status'] === 'bezahlt' || Kikripp_Ablauf::geschenk($v)) ? '' : 'Noch nicht als bezahlt vermerkt. Trotzdem abgeholt?'][$was] ?? '';
                $knopf = '<a class="button' . (in_array($was, ['kontakt', 'storniert'], true) ? '' : ' button-primary') . '" href="'
                    . esc_url(self::aktion_url($was, $id)) . '"' . ($frage !== '' ? ' onclick="return confirm(\'' . esc_js($frage) . '\')"' : '') . '>'
                    . ($was === 'abgeholt' ? '✓ ' : '') . esc_html($text) . '</a>';
            }
        }

        $stil = $versteckt . ($blass ? 'color:#8c8f94' : '');
        $h = '<tr id="vorgang-' . $id . '" class="kik-zeile" data-id="' . $id . '" data-im-reiter="' . ($im_reiter ? '1' : '0') . '"'
           . ' data-kommi="' . esc_attr($kommi['stand']) . '" data-such="' . esc_attr(Kikripp_Ablauf::such_text($v)) . '"'
           . ($stil !== '' ? ' style="' . $stil . '"' : '') . '>'
           . '<td class="kik-balken" style="background:' . $farbe . '"></td>'
           . '<td><strong>#' . $id . '</strong>' . (!empty($v['testdaten']) ? '<br><em style="font-size:11px">Test</em>' : '')
           . '<span class="kik-such">' . esc_html(self::REITER[$st['reiter']] ?? '') . '</span></td>'
           . '<td>' . $wer . (trim((string) $v['telefon']) !== '' ? '<span class="kik-such">☎ ' . esc_html($v['telefon']) . '</span>' : '') . '</td>'
           . '<td title="' . esc_attr($titel) . '">' . count($pos) . ' Pos. · ' . $stueck . ' Stück'
           . '<br><span class="kik-kommi-badge" id="kommi-badge-' . $id . '">' . esc_html(Kikripp_Ablauf::kommi_text($kommi)) . '</span></td>'
           . '<td style="white-space:nowrap">' . esc_html(Kikripp_Mail::eur(Kikripp_Ablauf::summe($v))) . '</td>'
           . '<td>' . $abholung . (!empty($v['demontage']) ? '<br><span style="font-size:11px">nach Vereinbarung</span>' : '') . '</td>'
           . '<td>' . (trim((string) ($v['rechnungsnr'] ?? '')) !== '' ? esc_html($v['rechnungsnr']) : '—') . '</td>'
           . '<td style="color:' . $farbe . ';font-weight:' . ($blass ? '400' : '600') . '">' . esc_html($st['schritt']) . '</td>'
           . '<td class="kik-auf" style="text-align:right">' . $knopf
           . ' <a href="#" id="auf-' . $id . '" onclick="kikAuf(' . $id . ');return false" style="margin-left:6px">'
           . ($offen ? 'zuklappen ▴' : 'bearbeiten ▾') . '</a></td></tr>';

        // Details
        $d = '<div style="display:flex;flex-wrap:wrap;gap:24px;margin-bottom:8px">';
        $d .= '<div style="min-width:220px">';
        if ($v['name'] !== '' || $v['email'] !== '' || $v['telefon'] !== '') {
            $d .= '<strong>' . esc_html($v['name']) . '</strong><br>';
            if (trim((string) ($v['firma'] ?? '')) !== '') { $d .= esc_html($v['firma']) . '<br>'; }
            if (trim((string) ($v['strasse'] ?? '')) !== '') { $d .= esc_html($v['strasse']) . ', ' . esc_html(trim($v['plz'] . ' ' . $v['ort'])) . '<br>'; }
            if ($v['email'] !== '') { $d .= '<a href="mailto:' . esc_attr($v['email']) . '">' . esc_html($v['email']) . '</a><br>'; }
            if ($v['telefon'] !== '') { $d .= '<a href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $v['telefon'])) . '">' . esc_html($v['telefon']) . '</a><br>'; }
            $d .= '<a href="' . esc_url(self::aktion_url('kontakt', $id)) . '" style="font-size:11px" onclick="return confirm(\'Kontaktdaten zu diesem Vorgang endgültig löschen?\')">erledigt – Kontaktdaten löschen</a>';
        } elseif ((int) $v['kontakt_weg']) {
            $d .= '<span style="color:#646970">Kontaktdaten gelöscht.</span>';
        }
        $d .= '<div style="font-size:11px;color:#646970;margin-top:4px">eingegangen ' . esc_html(mysql2date('d.m.Y H:i', $v['erstellt']))
            . ($v['status'] === 'offen' ? ' · reserviert bis ' . esc_html(mysql2date('d.m.Y', $v['ablauf'])) : '') . '</div></div>';
        $d .= '<div style="min-width:240px">';
        $offen_oder_bestellt = in_array($v['status'], ['offen', 'bestellt'], true);
        // 1.10.0: Häkchen „kommissioniert“, solange die Ware noch abgeholt wird
        $kommi_moeglich = $v['status'] !== 'storniert' && trim((string) ($v['abgeholt_am'] ?? '')) === '';
        if ($kommi_moeglich && count(Kikripp_Ablauf::positionen($v)) > 1) {
            $d .= '<div style="font-size:12px;margin-bottom:2px">' . Kikripp_Ablauf::kommi_feld($v, 0, $kommi['stand'] === 'ja', 'alle kommissioniert') . '</div>';
        }
        foreach ($v['positionen'] as $p) {
            $daten = json_decode((string) ($p['daten'] ?? ''), true);
            $t = esc_html((int) $p['menge'] . ' × ' . $p['artnr'] . ' ' . (is_array($daten) ? ($daten['titel'] ?? '') : ''))
               . ' · ' . esc_html(Kikripp_Mail::eur(Kikripp_DB::pos_betrag($p)));
            $haken = trim((string) ($p['kommissioniert'] ?? '')) !== '';
            if ($p['status'] === 'storniert') {
                $d .= '<s style="color:#8c8f94">' . $t . '</s>'
                    . ($haken ? ' <span style="color:#d63638;font-size:11px">📦 war kommissioniert – zurückräumen</span>' : '') . '<br>';
                continue;
            }
            if ($kommi_moeglich) { $d .= Kikripp_Ablauf::kommi_feld($v, (int) $p['id'], $haken) . ' '; }
            $d .= $t;
            if (($p['preis_original'] ?? null) !== null && $p['preis_original'] !== '') {
                $d .= ' <span style="font-size:11px;color:#646970">(Katalog <s>' . esc_html(Kikripp_Mail::eur((float) $p['preis_original'] * (int) $p['menge'])) . '</s>'
                    . (($p['festpreis'] ?? null) !== null && $p['festpreis'] !== '' ? ', Festpreis' : '') . ')</span>';
            }
            if ($offen_oder_bestellt) {                       // 1.8.0: Preis ändern (Stückpreis oder Festpreis)
                $d .= ' <details style="display:inline-block;font-size:11px"><summary style="cursor:pointer;color:#2271b1">Preis ändern</summary>'
                    . '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:4px 0">'
                    . wp_nonce_field('kikripp_preis_' . $id, '_wpnonce', true, false)
                    . '<input type="hidden" name="action" value="kikripp_preis"><input type="hidden" name="id" value="' . $id . '">'
                    . '<input type="hidden" name="pid" value="' . (int) $p['id'] . '">'
                    . '<input type="text" name="preis" inputmode="decimal" placeholder="z. B. 30" style="width:70px"> € '
                    . '<select name="art"><option value="stueck">je Stück</option><option value="gesamt">Festpreis für ' . (int) $p['menge'] . ' Stück</option></select> '
                    . '<button class="button button-small">ändern</button></form></details>';
            }
            // 1.11.1: Artikel tauschen – in jedem Status, auch nach Bezahlung und Abholung
            $d .= ' <details style="display:inline-block;font-size:11px"><summary style="cursor:pointer;color:#2271b1">Artikel tauschen</summary>'
                . '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:4px 0">'
                . wp_nonce_field('kikripp_tausch_' . $id, '_wpnonce', true, false)
                . '<input type="hidden" name="action" value="kikripp_tausch"><input type="hidden" name="id" value="' . $id . '">'
                . '<input type="hidden" name="pid" value="' . (int) $p['id'] . '">'
                . 'statt ' . esc_html($p['artnr']) . ': <input type="text" name="artnr" placeholder="z. B. BA07-03" style="width:90px"> '
                . '<button class="button button-small" onclick="return confirm(\'Artikel tauschen? Preis und Menge bleiben gleich.\')">tauschen</button></form></details>';
            if ($offen_oder_bestellt && count($v['positionen']) > 1) {
                $d .= ' <a href="' . esc_url(self::aktion_url('pos', $id, ['pid' => (int) $p['id']])) . '" style="font-size:11px" onclick="return confirm(\'Nur diese Position stornieren?\')">stornieren</a>';
            }
            $d .= '<br>';
        }
        $d .= '<div style="font-size:12px;color:#646970;margin-top:4px">Besichtigung: ' . esc_html(Kikripp_Mail::besichtigung_text($v))
            . '<br>Abholwunsch: ' . esc_html(Kikripp_Mail::abholung_text($v)) . '</div>';
        if (trim((string) $v['nachricht']) !== '') { $d .= '<div style="margin-top:4px">Nachricht: <em>' . esc_html($v['nachricht']) . '</em></div>'; }
        $d .= '</div><div style="min-width:180px">';
        $aktionen = [];
        if ($v['status'] === 'offen') { $aktionen['bestellt'] = 'bestellt'; $aktionen['verlaengern'] = 'Frist verlängern'; }
        if ($offen_oder_bestellt) { $aktionen['bezahlt'] = 'bezahlt'; $aktionen['storniert'] = 'stornieren'; }
        $aktionen['loeschen'] = 'löschen';
        foreach ($aktionen as $was => $text) {
            $frage = ['loeschen' => 'Diesen Vorgang wirklich löschen?', 'storniert' => 'Vorgang stornieren? Die Artikel sind dann wieder im Katalog.'][$was] ?? '';
            $d .= '<a href="' . esc_url(self::aktion_url($was, $id)) . '"' . ($was === 'loeschen' ? ' style="color:#d63638"' : '')
                . ($frage !== '' ? ' onclick="return confirm(\'' . esc_js($frage) . '\')"' : '') . '>' . esc_html($text) . '</a><br>';
        }
        if ($v['status'] !== 'storniert') {
            $b = wp_nonce_url(admin_url('admin-post.php?action=kikripp_bestellung&id=' . $id), 'kikripp_bestellung_' . $id);
            $privat = Kikripp_Ablauf::privat($v);
            $d .= '<span style="font-size:11px;color:#646970">Bestellung erstellen:</span><br>'
                . '<a href="' . esc_url($b . '&art=unternehmen') . '" target="_blank"' . ($privat ? '' : ' style="font-weight:600"') . '>Unternehmen</a> · '
                . '<a href="' . esc_url($b . '&art=privat') . '" target="_blank"' . ($privat ? ' style="font-weight:600"' : '') . '>Privatperson</a>';
        }
        $d .= '</div></div>';
        if (isset($_GET['kikripp_meldung'], $_GET['kikripp_vorgang']) && (int) $_GET['kikripp_vorgang'] === $id) {
            $fehler = isset($_GET['kikripp_fehler']);
            $d = '<div style="margin:0 0 10px;padding:8px 12px;border-left:4px solid ' . ($fehler ? '#d63638' : '#00a32a')
               . ';background:#fff;font-weight:600">' . esc_html(wp_unslash($_GET['kikripp_meldung'])) . '</div>' . $d;
        }
        if ($v['status'] !== 'storniert') { $d .= self::bearbeiten_html($v); }

        $h .= '<tr id="details-' . $id . '" class="kik-details"' . ($offen ? '' : ' hidden') . ($versteckt !== '' ? ' style="' . $versteckt . '"' : '') . '><td class="kik-balken" style="background:' . $farbe
            . '"></td><td colspan="8">' . $d . '</td></tr>';
        return $h;
    }

    /**
     * B + D + A: Bearbeitungszeile eines Vorgangs – Abholtermin, Rechnung, Notiz, Du/Sie –
     * und die Knöpfe für Mail, Zahlungserinnerung, Outlook und „abgeholt“.
     */
    private static function bearbeiten_html($v) {
        $id = (int) $v['id'];
        $abholung = (string) ($v['abholung'] ?? '');
        $vorschlag = false;
        if ($abholung === '' && trim((string) ($v['abholwunsch'] ?? '')) !== '') {
            $abholung = strlen($v['abholwunsch']) > 10 ? $v['abholwunsch'] : $v['abholwunsch'] . ' 09:00';
            $vorschlag = true;
        }
        $tag = substr($abholung, 0, 10);
        $zeit = substr($abholung, 11, 5);
        $h = '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:flex;flex-wrap:wrap;gap:10px 16px;align-items:flex-end">'
           . wp_nonce_field('kikripp_vorgang_' . $id, '_wpnonce', true, false)
           . '<input type="hidden" name="action" value="kikripp_vorgang"><input type="hidden" name="id" value="' . $id . '">'
           . '<label style="font-size:12px">Abholtermin' . ($vorschlag ? ' <span style="color:#b26200">(Wunsch – bitte bestätigen)</span>' : '') . '<br>'
           . '<input type="date" name="abhol_tag" value="' . esc_attr($tag) . '"> '
           . '<input type="time" name="abhol_zeit" step="900" value="' . esc_attr($zeit) . '" style="width:100px"></label>'
           . '<label style="font-size:12px">Rechnungsnr.<br><input type="text" name="rechnungsnr" value="' . esc_attr((string) ($v['rechnungsnr'] ?? '')) . '" style="width:110px"></label>'
           . '<label style="font-size:12px">Rechnung vom<br><input type="date" name="rechnung_am" value="' . esc_attr((string) ($v['rechnung_am'] ?? '')) . '"></label>'
           . '<label style="font-size:12px;flex:1;min-width:200px">Notiz (intern)<br><input type="text" name="notiz" value="' . esc_attr((string) ($v['notiz'] ?? '')) . '" style="width:100%"></label>'
           . '<label style="font-size:12px"><input type="checkbox" name="du" value="1"' . checked(1, (int) ($v['du'] ?? 0), false) . '> per Du</label>'
           . '<button class="button button-primary">Speichern</button></form>';
        // 1.9.0: Warte auf Rückinfo
        if (trim((string) ($v['abgeholt_am'] ?? '')) === '') {
            if (Kikripp_Ablauf::wartet($v)) {
                $h .= '<div style="margin-top:8px;font-size:12px;padding:6px 10px;background:#fff;border-left:4px solid #50575e">'
                    . '<b>Wartet auf Rückinfo</b> seit ' . esc_html(Kikripp_Ablauf::datum_text($v['warte_seit']))
                    . (trim((string) $v['warte_notiz']) !== '' ? ': ' . esc_html($v['warte_notiz']) : '')
                    . (!empty($v['warte_bis']) ? ' · Wiedervorlage ' . esc_html(Kikripp_Ablauf::datum_text($v['warte_bis'])) : '')
                    . ($v['status'] === 'offen' ? ' · Reservierungsfrist angehalten' : '')
                    . ' <a class="button button-small" href="' . esc_url(self::aktion_url('rueckinfo', $id)) . '">Rückinfo da</a></div>';
            } else {
                $h .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:8px;font-size:12px">'
                    . wp_nonce_field('kikripp_warten_' . $id, '_wpnonce', true, false)
                    . '<input type="hidden" name="action" value="kikripp_warten"><input type="hidden" name="id" value="' . $id . '">'
                    . 'Warte auf Rückinfo: <input type="text" name="warte_notiz" placeholder="worauf? z. B. Kunde klärt Transporter" style="width:240px"> '
                    . 'Wiedervorlage <input type="date" name="warte_bis"> '
                    . '<button class="button">warte auf Rückinfo</button></form>';
            }
        }
        if (trim((string) ($v['abgeholt_am'] ?? '')) === '' && (int) $v['kontakt_weg'] === 0 && trim((string) $v['name']) !== '') {
            $h .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:8px;font-size:12px">'
                . wp_nonce_field('kikripp_zusatz_' . $id, '_wpnonce', true, false)
                . '<input type="hidden" name="action" value="kikripp_zusatz"><input type="hidden" name="id" value="' . $id . '">'
                . 'Zusatzbestellung (eigene Rechnung, gleicher Abholtermin, ohne Mindestbestellwert): '
                . '<input type="text" name="artikel" placeholder="z. B. BU01-10 x 3, NE04-19" style="width:240px"> '
                . 'Preis <input type="text" name="rabatt_wert" inputmode="decimal" placeholder="leer = Katalog" style="width:100px"> '
                . '<select name="rabatt_art"><option value="">– bitte wählen –</option><option value="gesamt">€ Festpreis gesamt</option>'
                . '<option value="stueck">€ je Stück</option><option value="prozent">% Rabatt</option></select> '
                . '<button class="button">Zusatz anlegen</button></form>';
        }
        if (trim((string) ($v['abholtermin'] ?? '')) !== '') {
            $h .= '<div style="font-size:11px;color:#777;margin-top:4px">Früher eingetragen: ' . esc_html($v['abholtermin']) . '</div>';
        }

        $knoepfe = [];
        if (trim((string) $v['email']) !== '') {
            $knoepfe[] = '<a class="button" href="' . esc_attr(Kikripp_Ablauf::mailto($v)) . '">✉ Mail schreiben</a>'
                . ' <a href="#" onclick="kikKopieren(\'kik-text-' . $id . '\');return false" style="font-size:11px">Text kopieren</a>'
                . '<span id="kik-text-' . $id . '-ok" style="display:none;color:#00a32a;font-size:11px"> kopiert</span>'
                . '<textarea id="kik-text-' . $id . '" style="display:none">' . esc_textarea(implode("\n\n", Kikripp_Ablauf::mail_text($v))) . '</textarea>';
            if ($v['status'] === 'bestellt' && trim((string) $v['rechnungsnr']) !== '') {
                $knoepfe[] = '<a class="button" href="' . esc_attr(Kikripp_Ablauf::mailto($v, 'erinnerung')) . '">✉ Zahlungserinnerung</a>';
            }
        }
        if (trim((string) ($v['abholung'] ?? '')) !== '') {
            $knoepfe[] = '<a class="button" href="' . esc_url(Kikripp_Ablauf::ics_url($id)) . '">📅 In Outlook eintragen</a>';
        }
        if (in_array($v['status'], ['bestellt', 'bezahlt'], true)) {
            if (trim((string) ($v['abgeholt_am'] ?? '')) === '') {
                $knoepfe[] = '<a class="button" href="' . esc_url(self::aktion_url('abgeholt', $id)) . '"'
                    . (($v['status'] === 'bezahlt' || Kikripp_Ablauf::geschenk($v)) ? '' : ' onclick="return confirm(\'Noch nicht als bezahlt vermerkt. Trotzdem abgeholt (wird dabei als bezahlt vermerkt)?\')"')
                    . '>✓ abgeholt</a>';
            } else {
                $knoepfe[] = '<a href="' . esc_url(self::aktion_url('nicht_abgeholt', $id)) . '" style="font-size:11px">„abgeholt“ zurücknehmen</a>';
            }
        }
        if ($knoepfe) { $h .= '<div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:8px;align-items:center">' . implode(' ', $knoepfe) . '</div>'; }
        return $h;
    }

    public static function vorgang_speichern() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $id = (int) ($_POST['id'] ?? 0);
        check_admin_referer('kikripp_vorgang_' . $id);
        $tag = sanitize_text_field(wp_unslash($_POST['abhol_tag'] ?? ''));
        $zeit = sanitize_text_field(wp_unslash($_POST['abhol_zeit'] ?? ''));
        $abholung = ($tag !== '' && preg_match('/^\d{2}:\d{2}$/', $zeit)) ? "$tag $zeit"
                  : ($tag !== '' ? "$tag 09:00" : '');
        Kikripp_DB::vorgang_bearbeiten($id, [
            'abholung'    => $abholung,
            'rechnungsnr' => sanitize_text_field(wp_unslash($_POST['rechnungsnr'] ?? '')),
            'rechnung_am' => sanitize_text_field(wp_unslash($_POST['rechnung_am'] ?? '')),
            'notiz'       => sanitize_text_field(wp_unslash($_POST['notiz'] ?? '')),
            'du'          => !empty($_POST['du']),
        ]);
        self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d gespeichert.', $id) .
            ($abholung !== '' ? ' Abholung: ' . Kikripp_Ablauf::termin_text($abholung) . ' – jetzt „In Outlook eintragen“.' : ''),
            false, 'vorgang-' . $id);
    }

    public static function warten_speichern() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $id = (int) ($_POST['id'] ?? 0);
        check_admin_referer('kikripp_warten_' . $id);
        $bis = sanitize_text_field(wp_unslash($_POST['warte_bis'] ?? ''));
        Kikripp_DB::warten_setzen($id, sanitize_text_field(wp_unslash($_POST['warte_notiz'] ?? '')), $bis);
        self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d wartet auf Rückinfo%s.', $id,
            preg_match('/^\d{4}-\d{2}-\d{2}$/', $bis) ? ' – Wiedervorlage am ' . Kikripp_Ablauf::datum_text($bis) : ''),
            false, 'vorgang-' . $id, 'warten');
    }

    public static function preis_speichern() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $id = (int) ($_POST['id'] ?? 0);
        check_admin_referer('kikripp_preis_' . $id);
        $roh = str_replace(['€', ' '], '', sanitize_text_field(wp_unslash($_POST['preis'] ?? '')));
        if (!preg_match('/^\d+(?:[.,]\d{1,2})?$/', $roh)) {
            self::zurueck('kikripp-reservierungen', 'Bitte einen Betrag eintragen, z. B. „30“ oder „29,50“.', true, 'vorgang-' . $id);
        }
        $art = sanitize_key($_POST['art'] ?? 'stueck') === 'gesamt' ? 'gesamt' : 'stueck';
        $ok = Kikripp_DB::preis_setzen($id, (int) ($_POST['pid'] ?? 0), (float) str_replace(',', '.', $roh), $art);
        if (is_wp_error($ok)) {
            self::zurueck('kikripp-reservierungen', 'Preis nicht geändert: ' . $ok->get_error_message(), true, 'vorgang-' . $id);
        }
        self::zurueck('kikripp-reservierungen', sprintf('Preis in Vorgang #%d geändert. Neue Summe: %s.', $id,
            Kikripp_Mail::eur(Kikripp_Ablauf::summe(Kikripp_DB::vorgang($id)))), false, 'vorgang-' . $id);
    }

    public static function tausch_speichern() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $id = (int) ($_POST['id'] ?? 0);
        check_admin_referer('kikripp_tausch_' . $id);
        $nr = sanitize_text_field(wp_unslash($_POST['artnr'] ?? ''));
        $ok = Kikripp_DB::position_tauschen($id, (int) ($_POST['pid'] ?? 0), $nr);
        if (is_wp_error($ok)) {
            self::zurueck('kikripp-reservierungen', 'Nicht getauscht: ' . $ok->get_error_message(), true, 'vorgang-' . $id);
        }
        self::zurueck('kikripp-reservierungen', sprintf('Artikel in Vorgang #%d getauscht. Der alte Artikel ist im Katalog wieder frei.', $id),
            false, 'vorgang-' . $id);
    }

    public static function zusatz_speichern() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $id = (int) ($_POST['id'] ?? 0);
        check_admin_referer('kikripp_zusatz_' . $id);
        $wunsch = Kikripp_DB::wunsch_aus_text(sanitize_text_field(wp_unslash($_POST['artikel'] ?? '')));
        if (!$wunsch) {
            self::zurueck('kikripp-reservierungen', 'Bitte eine Artikelnummer eintragen, z. B. „BU01-10“ oder „BU01-10 x 3“.', true, 'vorgang-' . $id);
        }
        $neu = Kikripp_DB::zusatz_anlegen($id, $wunsch, Kikripp_DB::rabatt_aus_feldern(
            sanitize_text_field(wp_unslash($_POST['rabatt_wert'] ?? '')), sanitize_key($_POST['rabatt_art'] ?? '')));
        if (is_wp_error($neu)) {
            self::zurueck('kikripp-reservierungen', 'Zusatz nicht angelegt: ' . $neu->get_error_message(), true, 'vorgang-' . $id);
        }
        self::zurueck('kikripp-reservierungen', sprintf('Zusatzbestellung #%d zu Vorgang #%d angelegt (bestellt, gleicher Abholtermin). '
            . 'Jetzt eine eigene Rechnung schreiben und dort eintragen.', $neu, $id), false, 'vorgang-' . $neu, 'alle');
    }

    public static function termin_speichern() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $id = (int) ($_POST['id'] ?? 0);
        check_admin_referer('kikripp_termin_' . $id);
        Kikripp_DB::abholtermin_setzen($id, sanitize_text_field(wp_unslash($_POST['termin'] ?? '')));
        self::zurueck('kikripp-reservierungen', sprintf('Abholtermin für Vorgang #%d gespeichert.', $id));
    }

    public static function aktion() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        check_admin_referer('kikripp_aktion_' . $id);
        $was = isset($_GET['was']) ? sanitize_key($_GET['was']) : '';

        switch ($was) {
            case 'testdaten':
                $anzahl = Kikripp_DB::testdaten_loeschen();
                self::zurueck('kikripp-einstellungen', sprintf('%d Testreservierungen wurden gelöscht.', $anzahl));
            case 'bestellt':
                Kikripp_DB::vorgang_status($id, 'bestellt');
                self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d ist bestellt. Die Reservierung läuft nicht mehr ab.', $id));
            case 'pos':
                $rest = Kikripp_DB::position_stornieren($id, (int) ($_GET['pid'] ?? 0));
                self::zurueck('kikripp-reservierungen', $rest > 0
                    ? sprintf('Die Position wurde storniert und ist wieder im Katalog. Vorgang #%d läuft mit %d Position(en) weiter.', $id, $rest)
                    : sprintf('Die letzte Position wurde storniert – Vorgang #%d ist damit storniert.', $id));
            case 'bezahlt':
                Kikripp_DB::vorgang_status($id, 'bezahlt');
                self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d ist als bezahlt vermerkt. Die Artikel erscheinen nicht mehr im Katalog.', $id));
            case 'storniert':
                Kikripp_DB::vorgang_status($id, 'storniert');
                self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d wurde storniert, die Artikel sind wieder frei.', $id));
            case 'kontakt':
                Kikripp_DB::kontakt_loeschen($id);
                self::zurueck('kikripp-reservierungen', sprintf(
                    'Die Kontaktdaten zu Vorgang #%d wurden gelöscht.', $id));
            case 'verlaengern':
                Kikripp_DB::vorgang_verlaengern($id);
                self::zurueck('kikripp-reservierungen', sprintf('Die Frist für Vorgang #%d wurde verlängert.', $id));
            case 'abgeholt':
                Kikripp_DB::abgeholt_setzen($id, Kikripp_Ablauf::heute());
                self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d ist abgeholt.', $id), false, 'vorgang-' . $id);
            case 'rueckinfo':
                Kikripp_DB::warten_beenden($id);
                self::zurueck('kikripp-reservierungen', sprintf('Rückinfo zu Vorgang #%d ist da – er steht wieder im normalen Ablauf.', $id), false, 'vorgang-' . $id, 'alle');
            case 'kommi':                                  // 1.10.0: Häkchen kommissioniert (im Hintergrund)
                Kikripp_DB::kommissionieren($id, (int) ($_GET['pid'] ?? 0), !empty($_GET['an']));
                $v = Kikripp_DB::vorgang($id);
                $k = $v ? Kikripp_Ablauf::kommi($v) : ['stand' => '', 'x' => 0, 'y' => 0];
                if (!empty($_GET['ajax'])) {
                    wp_send_json(['ok' => (bool) $v, 'stand' => $k['stand'], 'x' => $k['x'], 'y' => $k['y'], 'text' => Kikripp_Ablauf::kommi_text($k)]);
                }
                self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d: %d von %d Positionen kommissioniert.', $id, $k['x'], $k['y']), false, 'vorgang-' . $id);
            case 'geraeumt':
                $n = Kikripp_DB::zurueckgeraeumt($id);
                self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d: Ware zurückgeräumt (%d Position(en)).', $id, $n), false, 'vorgang-' . $id);
            case 'nicht_abgeholt':
                Kikripp_DB::abgeholt_setzen($id, '');
                self::zurueck('kikripp-reservierungen', sprintf('„abgeholt“ bei Vorgang #%d zurückgenommen.', $id), false, 'vorgang-' . $id);
            case 'loeschen':
                Kikripp_DB::vorgang_loeschen($id);
                self::zurueck('kikripp-reservierungen', sprintf('Vorgang #%d wurde gelöscht.', $id));
        }
        self::zurueck('kikripp-reservierungen', 'Unbekannte Aktion.', true);
    }

    // ---------------------------------------------------------------- Bestellung

    /**
     * Druckfertige Bestellung (Kaufvertrag) zu einem Vorgang.
     *
     * Zwei Fassungen, weil das Recht es verlangt: Gegenüber Unternehmen ist die
     * Gewährleistung ausgeschlossen. Gegenüber Privatpersonen darf die Verjährung bei
     * gebrauchten Sachen nur auf ein Jahr verkürzt werden, wenn das gesondert vereinbart
     * wird – deshalb ein eigener Kasten mit eigener Unterschrift. Seit 07.10.2026 zahlen auch
     * Privatpersonen per Rechnung vor der Abholung; der Vertrag kann also ohne Treffen
     * zustande kommen (Fernabsatz). Die Fassung für Privatpersonen enthält deshalb die
     * Widerrufsbelehrung und das Muster-Widerrufsformular (Anlage 1 und 2 zu Art. 246a EGBGB).
     */
    public static function bestellung() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $id = (int) ($_GET['id'] ?? 0);
        check_admin_referer('kikripp_bestellung_' . $id);
        echo self::bestellung_html($id, sanitize_key($_GET['art'] ?? 'unternehmen'));
        exit;
    }

    public static function bestellung_html($id, $art) {
        $v = Kikripp_DB::vorgang($id);
        if (!$v) { return 'Vorgang nicht gefunden.'; }
        $privat = $art === 'privat';
        $e = function ($t) { return esc_html((string) $t); };
        $firma = (string) get_option('kikripp_firma', 'Kikripp GmbH');
        $ust = (float) get_option('kikripp_ust_prozent', 0) / 100;
        $schluss = (string) get_option('kikripp_abholschluss', '');
        $schluss_text = $schluss ? gmdate('d.m.Y', strtotime($schluss . ' 12:00:00 UTC')) : '';

        $zeilen = ''; $summe = 0.0; $zugaben = 0;
        $nur_geschenke = Kikripp_Ablauf::geschenk($v);
        foreach ($v['positionen'] as $p) {
            if ($p['status'] === 'storniert') { continue; }
            $d = json_decode((string) $p['daten'], true);
            $titel = is_array($d) && !empty($d['titel']) ? $d['titel'] : $p['artnr'];
            $einheit = is_array($d) && !empty($d['einheit']) ? $d['einheit'] : 'Stück';
            $wert = Kikripp_DB::pos_betrag($p);
            $summe += $wert;
            $fest = ($p['festpreis'] ?? null) !== null && $p['festpreis'] !== '';
            $orig = ($p['preis_original'] ?? null) !== null && $p['preis_original'] !== '' && (float) $p['preis_original'] * (int) $p['menge'] > $wert + 0.004;
            // 1.8.0: vereinbarter Preis – der Katalogpreis steht durchgestrichen darüber
            $einzel = $fest ? 'Festpreis' : $e(Kikripp_Mail::eur($p['preis_netto']));
            $zugabe = $wert <= 0.0 && !$nur_geschenke;          // 1.12.0
            if ($zugabe) { $zugaben++; }
            if ($orig) { $einzel = '<s style="color:#777">' . $e(Kikripp_Mail::eur($p['preis_original'])) . '</s><br>' . $einzel; }
            if ($zugabe) { $einzel = '–'; }
            $zeilen .= '<tr><td>' . $e($p['artnr']) . '</td><td>' . $e($titel) . '</td><td class="r">'
                . (int) $p['menge'] . ' ' . $e($einheit) . '</td><td class="r">' . $einzel
                . '</td><td class="r">' . ($orig ? '<s style="color:#777">' . $e(Kikripp_Mail::eur((float) $p['preis_original'] * (int) $p['menge'])) . '</s><br>' : '')
                . ($zugabe ? 'kostenlos zu Ihrem Einkauf' : $e(Kikripp_Mail::eur($wert))) . '</td></tr>';
        }
        $summenzeile = $ust > 0
            ? '<tr class="s"><td colspan="4">Summe netto</td><td class="r">' . $e(Kikripp_Mail::eur($summe)) . '</td></tr>'
              . '<tr class="s"><td colspan="4">zzgl. Umsatzsteuer</td><td class="r">' . $e(Kikripp_Mail::eur($summe * $ust)) . '</td></tr>'
              . '<tr class="s"><td colspan="4"><b>Gesamtbetrag</b></td><td class="r"><b>' . $e(Kikripp_Mail::eur($summe * (1 + $ust))) . '</b></td></tr>'
            : '<tr class="s"><td colspan="4"><b>Gesamtbetrag</b> (umsatzsteuerfrei)</td><td class="r"><b>'
              . $e(Kikripp_Mail::eur($summe)) . '</b></td></tr>';

        $anschrift = array_filter([
            trim((string) ($v['firma'] ?? '')), trim((string) $v['name']),
            trim((string) ($v['strasse'] ?? '')), trim(($v['plz'] ?? '') . ' ' . ($v['ort'] ?? '')),
        ]);
        $kontakt = array_filter([trim((string) $v['email']), trim((string) $v['telefon'])]);
        $bedingungen = '';
        foreach (preg_split('/\n\s*\n/', trim((string) get_option('kikripp_rechtstext', ''))) as $absatz) {
            if (trim($absatz) !== '') { $bedingungen .= '<p>' . $e(trim($absatz)) . '</p>'; }
        }
        $zahlung = 'Die Rechnung wird per E-Mail versandt. Der Betrag ist vorab auf das in der Rechnung angegebene Konto '
              . 'zu überweisen; abgeholt wird erst nach Zahlungseingang.';
        $gewaehr = $privat
            ? '<div class="kasten"><b>Gesonderte Vereinbarung zur Verjährung</b>'
              . '<p>Der Käufer ist Verbraucher. Es handelt sich um gebrauchte Sachen. Die Verjährungsfrist für '
              . 'Mängelansprüche wird abweichend von der gesetzlichen Frist auf <b>ein Jahr ab Übergabe</b> verkürzt. '
              . 'Der Käufer wurde vor Abgabe seiner Vertragserklärung gesondert auf diese Verkürzung hingewiesen.</p>'
              . '<p>☐ Ich bin mit der Verkürzung der Verjährungsfrist auf ein Jahr einverstanden.</p>'
              . '<div class="unterschrift"><span>Ort, Datum</span><span>Unterschrift Käufer</span></div></div>'
            : '<div class="kasten"><b>Gewährleistung</b><p>Der Käufer ist Unternehmer. Die Gewährleistung für '
              . 'Sach- und Rechtsmängel ist ausgeschlossen.</p></div>';

        $termine = [];
        if (trim((string) ($v['abholung'] ?? '')) !== '') { $termine[] = 'Vereinbarter Abholtermin: ' . Kikripp_Ablauf::termin_text($v['abholung']); }
        elseif (trim((string) ($v['abholtermin'] ?? '')) !== '') { $termine[] = 'Vereinbarter Abholtermin: ' . $v['abholtermin']; }
        elseif (Kikripp_Mail::abholung_text($v) !== '—') { $termine[] = 'Abholwunsch: ' . Kikripp_Mail::abholung_text($v); }
        if (Kikripp_Mail::besichtigung_text($v) !== 'nein') { $termine[] = 'Besichtigung: ' . Kikripp_Mail::besichtigung_text($v); }

        return '<!doctype html><html lang="de"><head><meta charset="utf-8"><title>Bestellung ' . (int) $id . '</title>'
            . '<style>body{font:13px/1.45 Arial,Helvetica,sans-serif;color:#1a1a1a;max-width:780px;margin:24px auto;padding:0 20px}'
            . 'h1{font-size:20px;margin:18px 0 2px}.kopf{display:flex;justify-content:space-between;border-bottom:3px solid #C8102E;padding-bottom:10px}'
            . '.klein{color:#555;font-size:12px}table{width:100%;border-collapse:collapse;margin:14px 0}th,td{padding:5px 6px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}'
            . 'th{background:#F7F5F2;font-size:12px}.r{text-align:right;white-space:nowrap}tr.s td{border-bottom:0}'
            . '.kasten{border:1px solid #bbb;padding:10px 12px;margin:14px 0}.unterschrift{display:flex;gap:40px;margin-top:34px}'
            . '.unterschrift span{flex:1;border-top:1px solid #1a1a1a;padding-top:4px;font-size:12px;color:#555}'
            . '.knopf{background:#C8102E;color:#fff;border:0;padding:9px 16px;font-size:14px;cursor:pointer;border-radius:3px}'
            . '@media print{.knopf,.nicht-drucken{display:none}body{margin:0}}</style></head><body>'
            . '<p class="nicht-drucken"><button class="knopf" onclick="window.print()">Drucken / als PDF speichern</button> '
            . '<span class="klein">Fassung: ' . ($privat ? 'Privatperson' : 'Unternehmen') . '</span></p>'
            . '<div class="kopf"><div><b>' . $e($firma) . '</b><br><span class="klein">' . $e(get_option('kikripp_abholadresse', ''))
            . '<br>Telefon ' . $e(get_option('kikripp_telefon', '')) . ' · ' . $e(Kikripp_REST::kontakt_email()) . '</span></div>'
            . '<div class="klein" style="text-align:right">Vorgang ' . (int) $id . '<br>' . $e(gmdate('d.m.Y', current_time('timestamp'))) . '</div></div>'
            . '<h1>Bestellung (Kaufvertrag) Nr. ' . (int) $id . '</h1>'
            . '<p class="klein">Gebrauchte Artikel aus Betriebsauflösung</p>'
            . '<table><tr><th style="width:50%">Käufer (' . ($privat ? 'Privatperson' : 'Unternehmen') . ')</th><th>Kontakt</th></tr>'
            . '<tr><td>' . implode('<br>', array_map($e, $anschrift)) . '</td><td>' . implode('<br>', array_map($e, $kontakt)) . '</td></tr></table>'
            . '<table><tr><th>Art.-Nr.</th><th>Bezeichnung</th><th class="r">Menge</th><th class="r">Einzelpreis</th><th class="r">Gesamt</th></tr>'
            . $zeilen . $summenzeile . '</table>'
            . ($zugaben ? '<p class="klein">Artikel „kostenlos zu Ihrem Einkauf“ erhalten Sie als Zugabe ohne Berechnung. '
              . 'Wird der Kauf storniert, entfallen auch die Zugaben.</p>' : '')
            . ($termine ? '<p>' . implode('<br>', array_map($e, $termine)) . '</p>' : '')
            . '<p><b>Zahlung:</b> ' . $e($zahlung) . '</p>'
            . '<p><b>Abholung:</b> durch den Käufer, montags bis mittwochs von 08:00 bis 12:00 Uhr, donnerstags von 08:00 bis '
            . '15:00 Uhr; weitere Termine und Demontage nach Vereinbarung. Werkzeug ist mitzubringen.'
            . ($schluss_text ? ' Die Ware ist bis spätestens <b>' . $e($schluss_text) . '</b> abzuholen. Nicht abgeholte Ware geht '
              . 'ohne Erstattung in das Eigentum der ' . $e($firma) . ' zurück.' : '') . '</p>'
            . $gewaehr
            . '<div class="klein"><b>Kaufbedingungen</b>' . $bedingungen . '</div>'
            . '<div class="unterschrift"><span>Ort, Datum</span><span>Unterschrift Käufer</span><span>' . $e($firma) . '</span></div>'
            . ($privat ? self::widerruf_html($firma, $e) : '')
            . '</body></html>';
    }

    /**
     * Widerrufsbelehrung und Muster-Widerrufsformular für Verbraucher, nach den gesetzlichen
     * Mustern. Angepasst an die Abholung: Die Ware wird an der Abholadresse zurückgegeben.
     */
    private static function widerruf_html($firma, $e) {
        $adresse = (string) get_option('kikripp_abholadresse', '');
        $mail = Kikripp_REST::kontakt_email();
        $tel = (string) get_option('kikripp_telefon', '');
        $wir = $e($firma) . ($adresse !== '' ? ', ' . $e($adresse) : '')
            . ($tel !== '' ? ', Telefon ' . $e($tel) : '') . ($mail !== '' ? ', E-Mail ' . $e($mail) : '');
        return '<div class="kasten" style="page-break-before:always"><b>Widerrufsbelehrung</b>'
            . '<p><b>Widerrufsrecht</b><br>Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag '
            . 'zu widerrufen. Die Widerrufsfrist beträgt vierzehn Tage ab dem Tag, an dem Sie oder ein von Ihnen benannter '
            . 'Dritter, der nicht der Beförderer ist, die Waren in Besitz genommen haben bzw. hat.</p>'
            . '<p>Um Ihr Widerrufsrecht auszuüben, müssen Sie uns (' . $wir . ') mittels einer eindeutigen Erklärung '
            . '(z. B. ein mit der Post versandter Brief oder eine E-Mail) über Ihren Entschluss, diesen Vertrag zu widerrufen, '
            . 'informieren. Sie können dafür das beigefügte Muster-Widerrufsformular verwenden, das jedoch nicht vorgeschrieben '
            . 'ist. Zur Wahrung der Widerrufsfrist reicht es aus, dass Sie die Mitteilung über die Ausübung des '
            . 'Widerrufsrechts vor Ablauf der Widerrufsfrist absenden.</p>'
            . '<p><b>Folgen des Widerrufs</b><br>Wenn Sie diesen Vertrag widerrufen, haben wir Ihnen alle Zahlungen, die wir '
            . 'von Ihnen erhalten haben, unverzüglich und spätestens binnen vierzehn Tagen ab dem Tag zurückzuzahlen, an dem '
            . 'die Mitteilung über Ihren Widerruf dieses Vertrags bei uns eingegangen ist. Für diese Rückzahlung verwenden wir '
            . 'dasselbe Zahlungsmittel, das Sie bei der ursprünglichen Transaktion eingesetzt haben, es sei denn, mit Ihnen '
            . 'wurde ausdrücklich etwas anderes vereinbart; in keinem Fall werden Ihnen wegen dieser Rückzahlung Entgelte '
            . 'berechnet. Wir können die Rückzahlung verweigern, bis wir die Waren wieder zurückerhalten haben oder bis Sie '
            . 'den Nachweis erbracht haben, dass Sie die Waren zurückgesandt haben, je nachdem, welches der frühere Zeitpunkt ist.</p>'
            . '<p>Sie haben die Waren unverzüglich und in jedem Fall spätestens binnen vierzehn Tagen ab dem Tag, an dem Sie uns '
            . 'über den Widerruf dieses Vertrags unterrichten, an uns zurückzugeben' . ($adresse !== '' ? ' (' . $e($adresse) . ')' : '')
            . '. Die Frist ist gewahrt, wenn Sie die Waren vor Ablauf der Frist von vierzehn Tagen zurückbringen oder absenden. '
            . 'Sie tragen die unmittelbaren Kosten der Rückgabe der Waren. Sie müssen für einen etwaigen Wertverlust der Waren '
            . 'nur aufkommen, wenn dieser Wertverlust auf einen zur Prüfung der Beschaffenheit, Eigenschaften und '
            . 'Funktionsweise der Waren nicht notwendigen Umgang mit ihnen zurückzuführen ist.</p></div>'
            . '<div class="kasten"><b>Muster-Widerrufsformular</b>'
            . '<p class="klein">(Wenn Sie den Vertrag widerrufen wollen, dann füllen Sie bitte dieses Formular aus und senden Sie es zurück.)</p>'
            . '<p>An ' . $wir . ':</p>'
            . '<p>Hiermit widerrufe(n) ich/wir (*) den von mir/uns (*) abgeschlossenen Vertrag über den Kauf der folgenden Waren (*):</p>'
            . '<p>_______________________________________________________________</p>'
            . '<p>Bestellt am (*) / erhalten am (*): ____________________</p>'
            . '<p>Name des/der Verbraucher(s): ____________________</p>'
            . '<p>Anschrift des/der Verbraucher(s): ____________________</p>'
            . '<div class="unterschrift"><span>Datum</span><span>Unterschrift des/der Verbraucher(s) (nur bei Mitteilung auf Papier)</span></div>'
            . '<p class="klein">(*) Unzutreffendes streichen.</p></div>';
    }

    public static function export() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('kikripp_export');
        $vorgaenge = Kikripp_DB::vorgaenge();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=kikripp-reservierungen-' . gmdate('Ymd-His') . '.csv');
        $aus = fopen('php://output', 'w');
        fwrite($aus, "\xEF\xBB\xBF");   // BOM, damit Excel die Umlaute erkennt
        fputcsv($aus, ['Vorgang', 'Eingegangen', 'Ablauf', 'Status', 'Name', 'Email', 'Telefon',
                       'Mailsuche', 'Nachricht', 'ArtNr', 'Menge', 'Preis_netto', 'Positionsstatus',
                       'Bezahlt_am', 'Firma', 'Strasse', 'PLZ', 'Ort', 'Besichtigung', 'Abholwunsch',
                       'Abholtermin', 'Abholung', 'Rechnungsnr', 'Rechnung_am', 'Abgeholt_am', 'Notiz'], ';');
        $firma = get_option('kikripp_firma', 'Kikripp GmbH');
        foreach ($vorgaenge as $v) {
            foreach ($v['positionen'] as $p) {
                fputcsv($aus, [
                    $v['id'], $v['erstellt'], $v['ablauf'], $v['status'], $v['name'], $v['email'],
                    $v['telefon'], sprintf('[%s] Neue Reservierung #%d', $firma, (int) $v['id']),
                    str_replace(["\r", "\n"], ' ', (string) $v['nachricht']),
                    $p['artnr'], $p['menge'],
                    // Stückpreis; beim Festpreis mit 4 Nachkommastellen, damit Menge × Preis den Betrag ergibt
                    number_format(Kikripp_DB::pos_stueck($p), ($p['festpreis'] ?? null) !== null && $p['festpreis'] !== '' ? 4 : 2, ',', ''), $p['status'],
                    $p['bezahlt_am'] ?? '',
                    $v['firma'] ?? '', $v['strasse'] ?? '', $v['plz'] ?? '', $v['ort'] ?? '',
                    Kikripp_Mail::besichtigung_text($v), Kikripp_Mail::abholung_text($v),
                    $v['abholtermin'] ?? '',
                    $v['abholung'] ?? '', $v['rechnungsnr'] ?? '', $v['rechnung_am'] ?? '', $v['abgeholt_am'] ?? '',
                    str_replace(["\r", "\n"], ' ', (string) ($v['notiz'] ?? '')),
                ], ';');
            }
        }
        fclose($aus);
        exit;
    }

    // ---------------------------------------------------------------- Import

    public static function seite_import() {
        if (!current_user_can('manage_options')) { return; }
        global $wpdb;
        $anzahl = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . Kikripp_DB::t_artikel());
        $ohne_bild = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . Kikripp_DB::t_artikel() . "
                                           WHERE daten LIKE '%\"bild\":\"\"%'");
        echo '<div class="wrap"><h1>Artikel importieren</h1>';
        self::hinweis();
        echo '<p>Im Katalog stehen derzeit <strong>' . $anzahl . '</strong> Artikel';
        if ($anzahl > 0) { echo ', davon <strong>' . $ohne_bild . '</strong> ohne gefundenes Foto'; }
        echo '.</p>';
        echo '<p>Die Importdatei erhalten Sie aus der Artikelstamm-Tabelle. Der Import <strong>aktualisiert</strong> '
           . 'vorhandene Artikel und ergänzt neue. Reservierungen bleiben dabei erhalten.</p>';
        echo '<p>Die Fotos gehören in die <a href="' . esc_url(admin_url('upload.php')) . '">Mediathek</a>; '
           . 'der Katalog sucht sie anhand des Dateinamens (F-001.jpg und so weiter).</p>';
        echo '<form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('kikripp_import');
        echo '<input type="hidden" name="action" value="kikripp_import">';
        echo '<p><input type="file" name="datei" accept=".json,application/json" required></p>';
        submit_button('Importieren');
        echo '</form></div>';
    }

    public static function import() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('kikripp_import');
        if (empty($_FILES['datei']['tmp_name']) || !is_uploaded_file($_FILES['datei']['tmp_name'])) {
            self::zurueck('kikripp-import', 'Es wurde keine Datei hochgeladen.', true);
        }
        $roh = file_get_contents($_FILES['datei']['tmp_name']);
        $liste = json_decode((string) $roh, true);
        if (!is_array($liste)) {
            self::zurueck('kikripp-import', 'Die Datei konnte nicht gelesen werden. Erwartet wird eine JSON-Datei.', true);
        }
        $bericht = self::einspielen($liste);
        self::zurueck('kikripp-import', self::import_meldung($bericht));
    }

    /**
     * Spielt die Artikelliste ein. Der ganze Import steckt hier – ohne Formular,
     * ohne Weiterleitung, ohne Ausgabe. Nur so kann der Kettentest genau den Code
     * prüfen, der später auch in WordPress läuft.
     *
     * Gibt einen Bericht zurück: neu, geaendert, ohne_bild, fehlende_fotos,
     * verschwunden, reserviert_entfernt.
     */
    public static function einspielen(array $liste) {
        // Eine alte Bildkarte aus einem abgebrochenen Lauf wäre eine Stunde lang gültig
        // und würde frisch hochgeladene Fotos übersehen. Deshalb hier neu aufbauen.
        delete_transient('kikripp_bilder');

        global $wpdb;
        $neu = $geaendert = $ohne_bild = $ohne_bild_versteckt = $neu_markiert = 0;
        $fehlende_fotos = [];
        $reserviert_entfernt = [];
        $belegung = Kikripp_DB::belegung();
        $gesehen = [];

        foreach ($liste as $i => $a) {
            if (empty($a['nr'])) { continue; }
            $artnr = sanitize_text_field((string) $a['nr']);
            $gesehen[] = $artnr;

            $bild = self::bild_url(isset($a['foto']) ? (string) $a['foto'] : '');
            // Gemeldet wird nur, was im Katalog auch zu sehen ist. Gestrichene Positionen
            // und die der zweiten Welle brauchen kein Foto in der Mediathek - sie als
            // "fehlend" zu melden, schickt die Nutzerin auf eine Suche ohne Anlass.
            $im_katalog = !empty($a['aktiv']) && !empty($a['im_katalog']);
            if ($bild === '') {
                if ($im_katalog) {
                    $ohne_bild++;
                    if (!empty($a['foto'])) { $fehlende_fotos[] = (string) $a['foto']; }
                } else {
                    $ohne_bild_versteckt++;
                }
            }

            $daten = [
                'nr'      => $artnr,
                'titel'   => (string) ($a['titel'] ?? ''),
                'beschr'  => (string) ($a['beschr'] ?? ''),
                'kat'     => (string) ($a['kat'] ?? ''),
                'raum'    => (string) ($a['raum'] ?? ''),
                'zustand' => (string) ($a['zustand'] ?? ''),
                'masse'   => (string) ($a['masse'] ?? ''),
                'einheit' => (string) ($a['einheit'] ?? 'Stück'),
                'basis'   => (string) ($a['basis'] ?? ''),
                'versand' => (string) ($a['versand'] ?? ''),
                'marke'   => (string) ($a['marke'] ?? ''),
                'buendel' => (string) ($a['buendel'] ?? ''),
                'mengenhinweis' => (string) ($a['mengenhinweis'] ?? ''),
                'foto'    => (string) ($a['foto'] ?? ''),
                'bild'    => $bild,
            ];
            // 1.6.0: „neu“ ab dem Import, mit dem ein Artikel zum ersten Mal sichtbar wird – neu
            // angelegt oder von „nicht im Katalog“ auf sichtbar gestellt. Sonst bleibt der alte Stempel.
            $alt = $wpdb->get_row($wpdb->prepare(
                'SELECT aktiv, im_katalog, daten FROM ' . Kikripp_DB::t_artikel() . ' WHERE artnr = %s', $artnr), ARRAY_A);
            $alt_daten = $alt ? json_decode((string) $alt['daten'], true) : null;
            $war_sichtbar = $alt && (int) $alt['aktiv'] === 1 && (int) $alt['im_katalog'] === 1;
            $daten['neu_seit'] = ($im_katalog && !$war_sichtbar) ? current_time('mysql')
                : (is_array($alt_daten) ? (string) ($alt_daten['neu_seit'] ?? '') : '');
            if ($im_katalog && !$war_sichtbar) { $neu_markiert++; }

            $zeile = [
                'sortierung'   => (int) ($a['sortierung'] ?? $i),
                'menge'        => max(0, (int) ($a['menge'] ?? 0)),
                'preis_netto'  => (float) ($a['preis'] ?? 0),
                'aktiv'        => !empty($a['aktiv']) ? 1 : 0,
                'im_katalog'   => !empty($a['im_katalog']) ? 1 : 0,
                'daten'        => wp_json_encode($daten),
                'aktualisiert' => current_time('mysql'),
            ];

            $vorhanden = $wpdb->get_var($wpdb->prepare(
                'SELECT artnr FROM ' . Kikripp_DB::t_artikel() . ' WHERE artnr = %s', $artnr));
            if ($vorhanden) {
                $wpdb->update(Kikripp_DB::t_artikel(), $zeile, ['artnr' => $artnr]);
                $geaendert++;
            } else {
                $zeile['artnr'] = $artnr;
                $wpdb->insert(Kikripp_DB::t_artikel(), $zeile);
                $neu++;
            }
            // Artikel mit Reservierung, der stillgelegt werden soll -> melden statt still verschwinden
            $b = $belegung[$artnr] ?? null;
            if ($b && ($b['reserviert'] > 0 || $b['bezahlt'] > 0)
                && (empty($a['aktiv']) || empty($a['im_katalog']))) {
                $reserviert_entfernt[] = $artnr;
            }
        }

        // Artikel, die in der Importdatei gar nicht mehr vorkommen, werden aus dem Katalog
        // genommen – aber nicht gelöscht, denn an ihnen können Reservierungen und
        // Verkäufe hängen. Sonst bliebe eine gestrichene Position für immer sichtbar.
        $verschwunden = Kikripp_DB::fehlende_stilllegen($gesehen);
        // Wer eine Position streicht, auf der noch eine Reservierung liegt, muss das erfahren.
        foreach ($verschwunden as $weg) {
            $b = $belegung[$weg] ?? null;
            if ($b && ($b['reserviert'] > 0 || $b['bezahlt'] > 0)) { $reserviert_entfernt[] = $weg; }
        }

        $fehlende_fotos = array_values(array_unique($fehlende_fotos));
        sort($fehlende_fotos);
        delete_transient('kikripp_bilder');

        return [
            'neu'                 => $neu,
            'geaendert'           => $geaendert,
            'neu_markiert'        => $neu_markiert,
            'ohne_bild'           => $ohne_bild,
            'ohne_bild_versteckt' => $ohne_bild_versteckt,
            'fehlende_fotos'      => $fehlende_fotos,
            'verschwunden'        => $verschwunden,
            'reserviert_entfernt' => array_values(array_unique($reserviert_entfernt)),
        ];
    }

    /** Aus dem Bericht den Satz bauen, der nach dem Import oben auf der Seite steht. */
    public static function import_meldung(array $b) {
        $meldung = sprintf('Import abgeschlossen: %d neu, %d aktualisiert.', $b['neu'], $b['geaendert']);
        if (!empty($b['neu_markiert'])) {
            $meldung .= sprintf(' %d Artikel sind ab heute %d Tage als NEU markiert.', $b['neu_markiert'], Kikripp_DB::NEU_TAGE);
        }
        if (!empty($b['verschwunden'])) {
            $meldung .= sprintf(' %d Artikel standen nicht mehr in der Datei und wurden aus dem '
                              . 'Katalog genommen (%s).', count($b['verschwunden']),
                              implode(', ', array_slice($b['verschwunden'], 0, 15)));
        }
        if ($b['ohne_bild'] > 0) {
            $meldung .= sprintf(' ACHTUNG: %d im Katalog sichtbare Artikel ohne gefundenes Foto. '
                . 'Diese Bilder fehlen in der Mediathek: %s%s', $b['ohne_bild'],
                implode(', ', array_slice($b['fehlende_fotos'], 0, 25)),
                count($b['fehlende_fotos']) > 25 ? ' … und weitere' : '.');
        } else {
            $meldung .= ' Jeder im Katalog sichtbare Artikel hat sein Foto gefunden.';
        }
        if (!empty($b['ohne_bild_versteckt'])) {
            $meldung .= sprintf(' (%d Positionen stehen nicht im Katalog und haben deshalb '
                . 'kein Foto in der Mediathek – das ist so gewollt.)',
                $b['ohne_bild_versteckt']);
        }
        if (!empty($b['reserviert_entfernt'])) {
            $meldung .= ' ACHTUNG: Diese Artikel wurden stillgelegt, haben aber noch Reservierungen: '
                      . implode(', ', array_slice($b['reserviert_entfernt'], 0, 15)) . '.';
        }
        return $meldung;
    }

    /** Foto in der Mediathek anhand des Dateinamens finden (F-001 -> Anhang). */
    /**
     * Schlüssel, unter dem ein Bild aus der Mediathek gefunden wird.
     *
     * Aus "F-001.jpg" wird "F-001". Lädt jemand dasselbe Bild ein zweites Mal hoch,
     * legt WordPress es als "F-001-1.jpg" ab - dieser Zusatz wird abgeschnitten,
     * damit das Foto trotzdem gefunden wird. Die Nummer des Fotos selbst darf dabei
     * nicht verlorengehen: "F-540" ist der Name, nicht "F" mit dem Zusatz "-540".
     *
     * Zweiter Rückgabewert: ob der Dateiname der genaue ist (ohne WordPress-Zusatz).
     * Bei Namensgleichheit gewinnt die genaue Datei.
     */
    public static function bild_schluessel($dateiname) {
        $datei = basename(trim((string) $dateiname));
        $name  = strtoupper(preg_replace('/\.[a-zA-Z0-9]+$/', '', $datei));
        if ($name === '') { return ['', false]; }
        if (preg_match('/^(F-\d{3,})-\d+$/', $name, $t)) { return [$t[1], false]; }
        return [$name, true];
    }

    private static function bild_url($fotoname) {
        $fotoname = trim($fotoname);
        if ($fotoname === '') { return ''; }
        $karte = get_transient('kikripp_bilder');
        if (!is_array($karte)) {
            $karte = [];
            // Ohne 'fields' => 'ids' legt WordPress die Beitraege und ihre Zusatzfelder
            // in zwei Abfragen in den Zwischenspeicher. Mit 'ids' waeren es stattdessen
            // zwei Abfragen je Bild - bei tausend Bildern in der Mediathek der
            // Unterschied zwischen einer Sekunde und einem Zeitueberschreitungsfehler.
            $anhaenge = get_posts([
                'post_type'      => 'attachment',
                'post_mime_type' => 'image',
                'posts_per_page' => -1,
                'post_status'    => 'inherit',
                'no_found_rows'  => true,
            ]);
            foreach ($anhaenge as $anhang) {
                $id = $anhang->ID;
                list($basis, $genau) = self::bild_schluessel(
                    (string) get_post_meta($id, '_wp_attached_file', true));
                if ($basis === '') { continue; }
                if ($genau || !isset($karte[$basis])) {
                    $karte[$basis] = wp_get_attachment_url($id);
                }
            }
            set_transient('kikripp_bilder', $karte, HOUR_IN_SECONDS);
        }
        $schluessel = strtoupper($fotoname);
        return isset($karte[$schluessel]) ? (string) $karte[$schluessel] : '';
    }

    // ---------------------------------------------------------------- Einstellungen

    public static function seite_einstellungen() {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap"><h1>Einstellungen</h1>';
        self::hinweis();
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('kikripp_einstellungen');
        echo '<input type="hidden" name="action" value="kikripp_einstellungen">';
        echo '<table class="form-table"><tbody>';

        printf('<tr><th scope="row">Passwortschutz</th><td>'
             . '<label><input type="checkbox" name="passwortschutz" value="1" %s> '
             . 'Katalog nur mit Passwort öffnen</label>'
             . '<p class="description">Seit Oktober 2026 ausgeschaltet: der Katalog ist frei zugänglich, '
             . 'erscheint aber nicht bei Google.</p></td></tr>',
             checked(1, (int) get_option('kikripp_passwortschutz', 1), false));

        printf('<tr><th scope="row"><label for="k_pw">Katalog-Passwort</label></th><td>'
             . '<input type="text" id="k_pw" name="passwort" class="regular-text" placeholder="leer lassen = unverändert">'
             . '<p class="description">Gilt nur bei eingeschaltetem Passwortschutz. Wird das Passwort geändert, müssen sich alle erneut anmelden.</p></td></tr>');

        printf('<tr><th scope="row"><label for="k_mail">Reservierungen melden an</label></th><td>'
             . '<input type="email" id="k_mail" name="mail_an" class="regular-text" value="%s" required>'
             . '<p class="description">Interne Benachrichtigung. Sie erreicht Interessenten '
             . 'nicht — dafür ist das Feld darunter da. Die Reservierungen stehen ohnehin '
             . 'vollständig auf dieser Seite.</p></td></tr>',
             esc_attr(get_option('kikripp_mail_an', '')));

        printf('<tr><th scope="row"><label for="k_kontakt">Kontaktadresse für Interessenten</label></th><td>'
             . '<input type="email" id="k_kontakt" name="kontakt_email" class="regular-text" value="%s">'
             . '<p class="description">Steht im Katalog unter dem Anbieter-Block und in der '
             . 'Bestätigung nach der Reservierung. Bleibt das Feld leer, gilt die Adresse '
             . 'von oben.</p></td></tr>',
             esc_attr(get_option('kikripp_kontakt_email', '')));
        printf('<tr><th scope="row"><label for="k_band">Hinweisband</label></th><td>'
             . '<input type="text" id="k_band" name="hinweisband" class="large-text" value="%s">'
             . '<p class="description">Erscheint als Band über dem Katalog. Zum Livegang das Feld leeren.</p></td></tr>',
             esc_attr(get_option('kikripp_hinweisband', '')));

        printf('<tr><th scope="row"><label for="k_band_bis">Hinweisband anzeigen bis</label></th><td>'
             . '<input type="date" id="k_band_bis" name="hinweis_bis" value="%s">'
             . '<p class="description">Nach diesem Tag verschwindet das Band von selbst. Leer = bis Sie es löschen.</p></td></tr>',
             esc_attr(get_option('kikripp_hinweis_bis', '')));

        printf('<tr><th scope="row"><label for="k_rueck">Rückmeldung erst ab</label></th><td>'
             . '<input type="date" id="k_rueck" name="rueckmeldung_ab" value="%s">'
             . '<p class="description">Bei Abwesenheit: Bis zu diesem Tag steht im Formular und in der Bestätigung '
             . '„Wir sind bis … nicht im Haus und melden uns ab dem … bei Ihnen.“ Ab dem Tag wieder der normale Satz. Leer = aus.</p></td></tr>',
             esc_attr(get_option('kikripp_rueckmeldung_ab', '')));

        printf('<tr><th scope="row"><label for="k_frist">Reservierung gilt</label></th><td>'
             . '<input type="number" id="k_frist" name="frist_werktage" min="1" max="30" value="%d" class="small-text"> Werktage (Mo–Fr)'
             . '<p class="description">Danach wird der Artikel automatisch wieder frei – außer der Vorgang steht auf '
             . '„bestellt“ oder „bezahlt“.</p></td></tr>',
             Kikripp_DB::frist_werktage());

        printf('<tr><th scope="row"><label for="k_mindest">Mindestbestellwert</label></th><td>'
             . '<input type="number" id="k_mindest" name="mindestwert" min="0" step="1" value="%s" class="small-text"> €'
             . '<p class="description">Darunter lässt sich die Reservierung nicht abschicken. 0 = kein Mindestwert.</p></td></tr>',
             esc_attr(get_option('kikripp_mindestwert', 0)));

        printf('<tr><th scope="row"><label for="k_geschenke">Höchstzahl Geschenke je Reservierung</label></th><td>'
             . '<input type="number" id="k_geschenke" name="geschenke_max" min="1" max="999" step="1" value="%d" class="small-text"> Artikel'
             . '<p class="description">So viele verschiedene Artikel „zu verschenken“ darf eine Reservierung enthalten. '
             . 'Gezählt werden Positionen, nicht Stück. Für die Verwaltung gilt die Grenze nicht.</p></td></tr>',
             Kikripp_REST::geschenke_max());

        printf('<tr><th scope="row"><label for="k_besicht">Besichtigung ab</label></th><td>'
             . '<input type="number" id="k_besicht" name="besichtigung_ab" min="0" step="1" value="%s" class="small-text"> € Stückpreis'
             . '<p class="description">Artikel ab diesem Preis tragen im Katalog „Besichtigung möglich“, und das '
             . 'Formular fragt nach einem Besichtigungstermin (Mo–Mi 8–12 Uhr, Do 8–15 Uhr).</p></td></tr>',
             esc_attr(get_option('kikripp_besichtigung_ab', 0)));

        printf('<tr><th scope="row"><label for="k_termine_ab">Termine frühestens ab</label></th><td>'
             . '<input type="date" id="k_termine_ab" name="termine_ab" value="%s">'
             . '<p class="description">Erster Tag, den das Formular für Besichtigung und Abholung anbietet (Mo–Mi 8–12, Do 8–15 Uhr). Leer = ab morgen.</p></td></tr>',
             esc_attr(get_option('kikripp_termine_ab', '')));

        printf('<tr><th scope="row"><label for="k_schluss">Abholung bis</label></th><td>'
             . '<input type="date" id="k_schluss" name="abholschluss" value="%s">'
             . '<p class="description">Letzter Abholtag. Das Formular bietet bis dahin Mo–Mi 8–12 Uhr und Do 8–15 Uhr an.</p></td></tr>',
             esc_attr(get_option('kikripp_abholschluss', '')));

        printf('<tr><th scope="row"><label for="k_ablauf">So läuft es ab</label></th><td>'
             . '<textarea id="k_ablauf" name="ablauftext" class="large-text" rows="7">%s</textarea>'
             . '<p class="description">Erscheint als Kasten über den Artikeln. Jede Zeile wird ein Punkt.</p></td></tr>',
             esc_textarea(get_option('kikripp_ablauftext', '')));

        printf('<tr><th scope="row"><label for="k_ust">Umsatzsteuer</label></th><td>'
             . '<input type="number" id="k_ust" name="ust" min="0" max="30" step="0.1" value="%s" class="small-text"> %%'
             . '<p class="description">0 = steuerfreie Lieferung (§ 4 Nr. 28 UStG): der Katalog zeigt dann nur einen Preis.</p></td></tr>',
             esc_attr(get_option('kikripp_ust_prozent', 19)));

        printf('<tr><th scope="row"><label for="k_steuer">Steuerhinweis</label></th><td>'
             . '<input type="text" id="k_steuer" name="steuerhinweis" class="large-text" value="%s">'
             . '<p class="description">Steht unter jedem Preis, wenn die Umsatzsteuer auf 0 steht.</p></td></tr>',
             esc_attr(get_option('kikripp_steuerhinweis', '')));

        printf('<tr><th scope="row"><label for="k_firma">Verkäuferin (Firma)</label></th><td>'
             . '<input type="text" id="k_firma" name="firma" class="regular-text" value="%s" required>'
             . '<p class="description">Erscheint im Katalog, im Mailbetreff, im Anbieter-Block und auf der '
             . 'Bestellung. Bewusst hier und nicht der Name der Website.</p></td></tr>',
             esc_attr(get_option('kikripp_firma', '')));

        printf('<tr><th scope="row"><label for="k_tel">Telefon</label></th><td>'
             . '<input type="text" id="k_tel" name="telefon" class="regular-text" value="%s">'
             . '</td></tr>',
             esc_attr(get_option('kikripp_telefon', '')));

        printf('<tr><th scope="row"><label for="k_imp">Impressum</label></th><td>'
             . '<input type="url" id="k_imp" name="impressum_url" class="large-text" value="%s">'
             . '<p class="description">Vollständige Adresse der Impressumsseite der Verkäuferin. '
             . '<strong>Bitte prüfen</strong> – die Vorgabe ist geraten.</p></td></tr>',
             esc_attr(get_option('kikripp_impressum_url', '')));

        printf('<tr><th scope="row"><label for="k_ds">Datenschutzerklärung</label></th><td>'
             . '<input type="url" id="k_ds" name="datenschutz_url" class="large-text" value="%s">'
             . '<p class="description">Ebenfalls veröffentlicht und erreichbar.</p></td></tr>',
             esc_attr(get_option('kikripp_datenschutz_url', '')));

        printf('<tr><th scope="row"><label for="k_abhol">Abholadresse</label></th><td>'
             . '<input type="text" id="k_abhol" name="abholadresse" class="large-text" value="%s">'
             . '<p class="description">Steht in der Bestätigungsmail an den Interessenten und unter dem Katalog.</p></td></tr>',
             esc_attr(get_option('kikripp_abholadresse', '')));

        printf('<tr><th scope="row"><label for="k_zufahrt">Zufahrt</label></th><td>'
             . '<input type="text" id="k_zufahrt" name="zufahrt" class="large-text" value="%s">'
             . '<p class="description">Wegbeschreibung für die Mail an den Käufer („Mail schreiben“).</p></td></tr>',
             esc_attr(get_option('kikripp_zufahrt', '')));

        printf('<tr><th scope="row"><label for="k_mailname">Name in Mailvorlagen</label></th><td>'
             . '<input type="text" id="k_mailname" name="mail_name" class="regular-text" value="%s">'
             . '<p class="description">Steht unter den Mails an Käufer und unter der Zahlungserinnerung.</p></td></tr>',
             esc_attr(get_option('kikripp_mail_name', 'Jenny Preisigke')));

        printf('<tr><th scope="row"><label for="k_erinn">Erinnerung am Vortag um</label></th><td>'
             . '<input type="time" id="k_erinn" name="erinnerung_zeit" step="900" value="%s">'
             . '<p class="description">Uhrzeit des Outlook-Termins „Vorbereiten“ am Werktag vor der Abholung. '
             . 'Die Abholung selbst erinnert 15 Minuten vorher.</p></td></tr>',
             esc_attr(get_option('kikripp_erinnerung_zeit', '11:00')));

        printf('<tr><th scope="row"><label for="k_zusatz">Zusatz im Terminbetreff</label></th><td>'
             . '<input type="text" id="k_zusatz" name="termin_zusatz" class="regular-text" value="%s">'
             . '<p class="description">Steht vorn im Betreff jedes Outlook-Termins (für die Auswertung). Leer lassen = kein Zusatz.</p></td></tr>',
             esc_attr(get_option('kikripp_termin_zusatz', 'Barrierefrei')));

        printf('<tr><th scope="row"><label for="k_zahl">Zahlungserinnerung nach</label></th><td>'
             . '<input type="number" id="k_zahl" name="zahlung_tage" min="1" max="60" value="%d" style="width:70px"> Tagen'
             . '<p class="description">Ab dann steht ein unbezahlter Vorgang unter „Zu erledigen“ (gezählt ab Rechnungsdatum).</p></td></tr>',
             (int) get_option('kikripp_zahlung_tage', 5));

        printf('<tr><th scope="row"><label for="k_recht">Rechtliche Hinweise</label></th><td>'
             . '<textarea id="k_recht" name="rechtstext" class="large-text" rows="5">%s</textarea>'
             . '<p class="description">Erscheint unter dem Katalog als „Kaufbedingungen“ und auf jeder Bestellung. '
             . 'Leerzeilen trennen Absätze. Leer lassen blendet den Block aus.</p></td></tr>',
             esc_textarea(get_option('kikripp_rechtstext', '')));

        printf('<tr><th scope="row">Fußzeile ausblenden</th><td>'
             . '<label><input type="checkbox" name="fusszeile_aus" value="1" %s> '
             . 'Fußzeile der Website auf der Katalogseite nicht anzeigen</label>'
             . '<p class="description">Impressum und Datenschutz stehen dann nur im Anbieter-Block unter dem Katalog. '
             . 'Bleibt die Fußzeile trotzdem sichtbar, nutzt das Theme eine ungewöhnliche Auszeichnung – bitte melden.</p></td></tr>',
             checked(1, (int) get_option('kikripp_fusszeile_aus', 1), false));

        printf('<tr><th scope="row">Menü ausblenden</th><td>'
             . '<label><input type="checkbox" name="kopf_aus" value="1" %s> '
             . 'Menü und Social-Media-Symbole im Kopf der Website auf der Katalogseite nicht anzeigen</label>'
             . '<p class="description">Das Logo bleibt stehen. Auf den übrigen Seiten der Website ändern Sie das Menü unter '
             . 'Design → Editor → Header.</p></td></tr>',
             checked(1, (int) get_option('kikripp_kopf_aus', 1), false));

        printf('<tr><th scope="row">Vorschaubetrieb</th><td>'
             . '<label><input type="checkbox" name="vorschau" value="1" %s> '
             . 'Eingehende Reservierungen als Testdaten kennzeichnen</label>'
             . '<p class="description">In der Vorschauphase eingeschaltet lassen – Testreservierungen lassen sich dann '
             . 'mit einem Klick entfernen. Zum Livegang ausschalten.</p></td></tr>',
             checked(1, (int) get_option('kikripp_vorschau', 1), false));

        echo '</tbody></table>';
        submit_button('Einstellungen speichern');
        echo '</form>';

        $url = wp_nonce_url(admin_url('admin-post.php?action=kikripp_aktion&was=testdaten&id=0'), 'kikripp_aktion_0');
        echo '<hr><h2>Testdaten</h2><p>Entfernt alle Reservierungen, die im Vorschaubetrieb entstanden sind.</p>';
        echo '<p><a href="' . esc_url($url) . '" class="button" onclick="return confirm(\'Alle Testreservierungen löschen?\')">Testreservierungen löschen</a></p>';
        echo '</div>';
    }

    public static function einstellungen_speichern() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('kikripp_einstellungen');
        $pw = isset($_POST['passwort']) ? trim(wp_unslash($_POST['passwort'])) : '';
        if ($pw !== '') { Kikripp_Zugang::passwort_setzen($pw); }
        update_option('kikripp_mail_an', sanitize_email(wp_unslash($_POST['mail_an'] ?? '')));
        update_option('kikripp_kontakt_email',
            sanitize_email(wp_unslash($_POST['kontakt_email'] ?? '')));
        update_option('kikripp_hinweisband', sanitize_text_field(wp_unslash($_POST['hinweisband'] ?? '')));
        update_option('kikripp_passwortschutz', isset($_POST['passwortschutz']) ? 1 : 0);
        update_option('kikripp_frist_werktage', max(1, (int) ($_POST['frist_werktage'] ?? 3)));
        update_option('kikripp_mindestwert', max(0, (float) ($_POST['mindestwert'] ?? 0)));
        update_option('kikripp_geschenke_max', min(999, max(1, (int) ($_POST['geschenke_max'] ?? 5))));
        update_option('kikripp_besichtigung_ab', max(0, (float) ($_POST['besichtigung_ab'] ?? 0)));
        foreach (['hinweis_bis', 'rueckmeldung_ab', 'termine_ab'] as $feld) {      // 1.12.0
            $wert = sanitize_text_field(wp_unslash($_POST[$feld] ?? ''));
            update_option('kikripp_' . $feld, preg_match('/^\d{4}-\d{2}-\d{2}$/', $wert) ? $wert : '');
        }
        $schluss = sanitize_text_field(wp_unslash($_POST['abholschluss'] ?? ''));
        update_option('kikripp_abholschluss', preg_match('/^\d{4}-\d{2}-\d{2}$/', $schluss) ? $schluss : '');
        update_option('kikripp_ablauftext', sanitize_textarea_field(wp_unslash($_POST['ablauftext'] ?? '')));
        update_option('kikripp_ust_prozent', (float) ($_POST['ust'] ?? 0));
        update_option('kikripp_steuerhinweis', sanitize_text_field(wp_unslash($_POST['steuerhinweis'] ?? '')));
        update_option('kikripp_vorschau', isset($_POST['vorschau']) ? 1 : 0);
        update_option('kikripp_fusszeile_aus', isset($_POST['fusszeile_aus']) ? 1 : 0);
        update_option('kikripp_kopf_aus', isset($_POST['kopf_aus']) ? 1 : 0);
        update_option('kikripp_abholadresse', sanitize_text_field(wp_unslash($_POST['abholadresse'] ?? '')));
        update_option('kikripp_zufahrt', sanitize_text_field(wp_unslash($_POST['zufahrt'] ?? '')));
        update_option('kikripp_mail_name', sanitize_text_field(wp_unslash($_POST['mail_name'] ?? '')));
        $erinn = sanitize_text_field(wp_unslash($_POST['erinnerung_zeit'] ?? ''));
        update_option('kikripp_erinnerung_zeit', preg_match('/^\d{2}:\d{2}$/', $erinn) ? $erinn : '11:00');
        update_option('kikripp_termin_zusatz', sanitize_text_field(wp_unslash($_POST['termin_zusatz'] ?? '')));
        update_option('kikripp_zahlung_tage', max(1, min(60, (int) ($_POST['zahlung_tage'] ?? 5))));
        update_option('kikripp_rechtstext', sanitize_textarea_field(wp_unslash($_POST['rechtstext'] ?? '')));
        update_option('kikripp_firma', sanitize_text_field(wp_unslash($_POST['firma'] ?? '')));
        update_option('kikripp_telefon', sanitize_text_field(wp_unslash($_POST['telefon'] ?? '')));
        update_option('kikripp_impressum_url', esc_url_raw(wp_unslash($_POST['impressum_url'] ?? '')));
        update_option('kikripp_datenschutz_url', esc_url_raw(wp_unslash($_POST['datenschutz_url'] ?? '')));
        self::zurueck('kikripp-einstellungen', 'Einstellungen gespeichert.'
            . ($pw !== '' ? ' Das Passwort wurde geändert – alle Besucher müssen sich neu anmelden.' : ''));
    }
}
