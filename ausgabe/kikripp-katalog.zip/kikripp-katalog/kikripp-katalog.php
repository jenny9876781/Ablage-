<?php
/**
 * Plugin Name: Kikripp Artikelkatalog
 * Description: Artikelkatalog mit Reservierung für die Betriebsauflösung der Kikripp GmbH. Artikel werden importiert, Reservierungen im Backend verwaltet.
 * Version:     1.16.0
 * Author:      Kikripp GmbH
 * Text Domain: kikripp-katalog
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('KIKRIPP_VERSION', '1.16.0');
define('KIKRIPP_PFAD', plugin_dir_path(__FILE__));
define('KIKRIPP_URL', plugin_dir_url(__FILE__));

require_once KIKRIPP_PFAD . 'includes/kikripp-vorgaben.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-db.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-zugang.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-mail.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-rest.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-admin.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-ablauf.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-auswertung.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-frontend.php';
require_once KIKRIPP_PFAD . 'includes/class-kikripp-umzug.php';

register_activation_hook(__FILE__, ['Kikripp_DB', 'tabellen_anlegen']);

add_action('plugins_loaded', function () {
    Kikripp_DB::pruefe_version();
    kikripp_umstellen();
    Kikripp_DB::sale_umschalten();      // 1.16.0: tut nur am ersten und am Tag nach dem letzten Sale-Tag etwas
    Kikripp_REST::start();
    Kikripp_Admin::start();
    Kikripp_Ablauf::start();
    Kikripp_Auswertung::start();
    Kikripp_Umzug::start();
    Kikripp_Frontend::start();
});

/** Standardwerte beim ersten Aktivieren. */
register_activation_hook(__FILE__, function () {
    // Bewusst kein voreingestelltes Passwort: solange keins vergeben ist, lässt
    // Kikripp_Zugang::passwort_pruefen() niemanden durch. Das Passwort wird einmal
    // unter „Artikelkatalog → Einstellungen" gesetzt und steht in keiner Datei.
    add_option('kikripp_zugang_version', 1);
    // Zwei verschiedene Adressen, bewusst getrennt: die interne Meldung geht an ein
    // Postfach auf kikripp.de (dorthin stellt der Webserver ueberhaupt zu), die Adresse
    // fuer Interessenten ist die des Verkaufs.
    add_option('kikripp_mail_an', 'jennyp@kikripp.de');
    add_option('kikripp_kontakt_email', 'saldi4kids@outlook.com');
    // Kein Vorschau-Hinweis: der Katalog geht als fertiger Stand online. Das Band bleibt
    // leer, bis es einen echten Hinweis zu geben gibt (Wunsch der Nutzerin, 29.09.2026).
    add_option('kikripp_hinweisband', '');
    add_option('kikripp_vorschau', 1);
    add_option('kikripp_abholadresse', 'Kikripp GmbH, Hermann-Schwer-Str. 1, 78048 Villingen-Schwenningen');
    add_option('kikripp_firma', 'Kikripp GmbH');
    add_option('kikripp_telefon', '07725 5179702');
    // Der Katalog laeuft auf kikripp.de, die beiden Seiten liegen dort. Beim Aktivieren
    // muessen sie veroeffentlicht sein – als Entwurf sind sie oeffentlich nicht erreichbar
    // und der Anbieter-Block unter dem Katalog zeigt ins Leere.
    add_option('kikripp_impressum_url', 'https://www.kikripp.de/impressum/');
    add_option('kikripp_datenschutz_url', 'https://www.kikripp.de/datenschutz/');
    foreach (kikripp_vorgaben_120() as $name => $wert) { add_option($name, $wert); }
    foreach (kikripp_vorgaben_130() as $name => $wert) { add_option($name, $wert); }
    add_option('kikripp_plugin_version', KIKRIPP_VERSION);
});

/**
 * Einmalige Umstellung einer bestehenden Einrichtung auf die Fassung 1.2.0.
 *
 * Beim Ersetzen des Plugins läuft der Aktivierungshaken nicht – die neuen Vorgaben
 * kämen sonst nie an, und der Katalog zeigte weiter Preise mit 19 % USt und den alten
 * Rechtstext. Was die Nutzerin danach in den Einstellungen ändert, bleibt: die
 * Umstellung läuft genau einmal. Das Hinweisband wird nur gefüllt, wenn es leer ist.
 */
function kikripp_umstellen() {
    $stand = (string) get_option('kikripp_plugin_version', '1.0.0');
    if (version_compare($stand, '1.2.0', '>=')) {
        kikripp_umstellen_122($stand);
        return;
    }
    foreach (kikripp_vorgaben_120() as $name => $wert) { update_option($name, $wert); }
    if (trim((string) get_option('kikripp_hinweisband', '')) === '') {
        update_option('kikripp_hinweisband', 'Ein Großteil unseres Spielzeugs kommt im November dazu – '
            . 'schauen Sie gern wieder vorbei. Der Katalog wird wöchentlich aktualisiert.');
    }
    if (get_option('kikripp_kopf_aus', null) === null) { update_option('kikripp_kopf_aus', 1); }
    update_option('kikripp_plugin_version', '1.2.3');
    kikripp_umstellen_130('1.2.3');
}

/**
 * 1.2.2: kürzerer Ablauftext als Fließtext. Ersetzt wird nur, wenn noch der Text von 1.2.0
 * drinsteht – was die Nutzerin selbst geändert hat, bleibt.
 */
function kikripp_umstellen_122($stand) {
    if (version_compare($stand, '1.2.2', '>=')) { kikripp_umstellen_123($stand); return; }
    $jetzt = str_replace("\r", '', (string) get_option('kikripp_ablauftext', ''));
    if (trim($jetzt) === trim(kikripp_ablauf_120())) {
        update_option('kikripp_ablauftext', kikripp_ablauf_122());
    }
    update_option('kikripp_plugin_version', '1.2.2');
    kikripp_umstellen_123('1.2.2');
}

/**
 * 1.2.3: Ablauftext mit „Bezahlung generell gegen Rechnung“ und Hinweis auf das Widerrufsrecht
 * in den Kaufbedingungen. Ersetzt wird nur, was noch unverändert aus 1.2.2 stammt.
 */
function kikripp_umstellen_123($stand) {
    if (version_compare($stand, '1.2.3', '>=')) { kikripp_umstellen_130($stand); return; }
    $ablauf = trim(str_replace("\r", '', (string) get_option('kikripp_ablauftext', '')));
    if ($ablauf === trim(kikripp_ablauf_122())) { update_option('kikripp_ablauftext', kikripp_ablauf_123()); }
    $recht = trim(str_replace("\r", '', (string) get_option('kikripp_rechtstext', '')));
    if ($recht === trim(kikripp_rechtstext_120())) { update_option('kikripp_rechtstext', kikripp_rechtstext_123()); }
    if (get_option('kikripp_kopf_aus', null) === null) { update_option('kikripp_kopf_aus', 1); }
    update_option('kikripp_plugin_version', '1.2.3');
    kikripp_umstellen_130('1.2.3');
}

/** 1.3.0: Vorgaben für die Abwicklung ergänzen (Zufahrt, Name, Erinnerung, Zahlungsfrist). */
function kikripp_umstellen_130($stand) {
    if (version_compare($stand, '1.3.0', '>=')) { kikripp_umstellen_131($stand); return; }
    foreach (kikripp_vorgaben_130() as $name => $wert) { add_option($name, $wert); }
    update_option('kikripp_plugin_version', '1.3.0');
    kikripp_umstellen_131('1.3.0');
}

/** 1.3.1: Vortagserinnerung 11:00 statt 14:00 (nur wenn noch die alte Vorgabe steht), Zusatz „Barrierefrei“. */
function kikripp_umstellen_131($stand) {
    if (version_compare($stand, '1.3.1', '>=')) { kikripp_umstellen_1120($stand); return; }
    if (get_option('kikripp_erinnerung_zeit', '') === '14:00') { update_option('kikripp_erinnerung_zeit', '11:00'); }
    add_option('kikripp_termin_zusatz', 'Barrierefrei');
    update_option('kikripp_plugin_version', '1.3.1');
    kikripp_umstellen_1120('1.3.1');
}

/**
 * 1.12.0: Ablauftext auf Mo–Do 8–12 Uhr und „kostenlos zu Ihrem Einkauf“ – nur wenn noch der
 * unveränderte Text von 1.2.3 drinsteht. Selbst geänderte Texte bleiben; die Nutzerin bekommt den Wortlaut.
 */
function kikripp_umstellen_1120($stand) {
    if (version_compare($stand, '1.12.0', '>=')) { kikripp_umstellen_1140($stand); return; }
    $ablauf = trim(str_replace("\r", '', (string) get_option('kikripp_ablauftext', '')));
    if ($ablauf === trim(kikripp_ablauf_123())) { update_option('kikripp_ablauftext', kikripp_ablauf_1120()); }
    update_option('kikripp_plugin_version', '1.12.0');
    kikripp_umstellen_1140('1.12.0');
}

/** 1.14.0: Ablauftext mit „donnerstags 8 bis 15 Uhr“ – nur wenn der Text von 1.12.0 noch unverändert ist. */
function kikripp_umstellen_1140($stand) {
    if (version_compare($stand, '1.14.0', '>=')) { kikripp_umstellen_1150($stand); return; }
    $ablauf = trim(str_replace("\r", '', (string) get_option('kikripp_ablauftext', '')));
    if ($ablauf === trim(kikripp_ablauf_1120())) { update_option('kikripp_ablauftext', kikripp_ablauf_1140()); }
    update_option('kikripp_plugin_version', '1.14.0');
    kikripp_umstellen_1150('1.14.0');
}

/** 1.15.0: Ablauftext mit „Überweisung vorab oder bar bei Abholung“ – nur wenn der Text von 1.14.0 unverändert ist. */
function kikripp_umstellen_1150($stand) {
    if (version_compare($stand, '1.15.0', '>=')) { kikripp_umstellen_1160($stand); return; }
    $ablauf = trim(str_replace("\r", '', (string) get_option('kikripp_ablauftext', '')));
    if ($ablauf === trim(kikripp_ablauf_1140())) { update_option('kikripp_ablauftext', kikripp_ablauf_1150()); }
    update_option('kikripp_plugin_version', '1.15.0');
    kikripp_umstellen_1160('1.15.0');
}

/**
 * 1.16.0 (16.11.2026): Abholung bis 31.01.2027 mit Weihnachtspause, gesperrte Tage, Sale 07.–11.12.2026.
 * Abholschluss und Texte werden nur umgestellt, wenn noch der alte Stand (10.12.2026) drinsteht.
 */
function kikripp_umstellen_1160($stand) {
    if (version_compare($stand, '1.16.0', '>=')) { return; }
    add_option('kikripp_keine_termine', "23.11.2026\n07.12.2026\n17.12.2026 - 12.01.2027");
    add_option('kikripp_sale_von', '2026-12-07');
    add_option('kikripp_sale_bis', '2026-12-11');
    add_option('kikripp_hinweis_ab', '');
    if ((string) get_option('kikripp_abholschluss', '') === '2026-12-10') { update_option('kikripp_abholschluss', '2027-01-31'); }
    foreach (kikripp_texte_1160() as $name => $paar) {
        $text = (string) get_option($name, '');
        if (strpos($text, $paar[0]) !== false) { update_option($name, str_replace($paar[0], $paar[1], $text)); }
    }
    update_option('kikripp_plugin_version', '1.16.0');
    Kikripp_DB::sale_umschalten(true);
}

/** 1.16.0: was in Ablauftext und Kaufbedingungen ersetzt wird (alt => neu). */
function kikripp_texte_1160() {
    return [
        'kikripp_ablauftext' => ['Abholung spätestens bis 10.12.2026',
            'Abholung spätestens bis 31.01.2027 (keine Abholung vom 17.12.2026 bis 12.01.2027)'],
        'kikripp_rechtstext' => ['10.12.2026', '31.01.2027'],
    ];
}
