/* Artikelkatalog Kikripp – Anzeige und Reservierung. Daten kommen live über die
   Schnittstelle, damit ein Seiten-Cache nichts veralten lässt. */
(function () {
  'use strict';

  var W = window.KIKRIPP || {};
  var wurzel = document.getElementById('kikripp-katalog');
  if (!wurzel) { return; }

  var ARTIKEL = [], UST = 0.19, HINWEIS = '', FRIST = 3, IST_ADMIN = false;
  var RECHT = '', ABHOLUNG = '', ANBIETER = {}, STEUER = '', ABLAUF = '';
  var MINDEST = 0, GESCHENKE_MAX = 5, BES_AB = 0, SCHLUSS = '', HEUTE = '', TERMINE_AB = '', RUECK = '';
  var BES_ZEITEN = ['08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30'];   // 1.12.0: Mo–Mi bis 12 Uhr
  var ZEITEN_DO = BES_ZEITEN.concat(['12:00', '12:30', '13:00', '13:30', '14:00', '14:30']);  // 1.14.0: Do bis 15 Uhr
  /** 1.14.0: Uhrzeiten zum gewählten Tag (Donnerstag länger). */
  function zeitenAm(iso) { return iso && tag(iso).getUTCDay() === 4 ? ZEITEN_DO : BES_ZEITEN; }
  function zeitOptionen(iso, leer) {
    return '<option value="">' + leer + '</option>' + zeitenAm(iso).map(function (z) {
      return '<option value="' + z + '">' + z + ' Uhr</option>'; }).join('');
  }
  var TERMIN_TAGE = [1, 2, 3, 4];                                                               // Mo–Do
  var formularSeit = 0;
  var merk = {};                       // ArtNr -> gewünschte Stückzahl
  var katWahl = '';                    // 1.15.1: gewählter Kategorie-Knopf ('' = alle, SALE, GUENSTIG oder Kategoriename)
  var SALE = '\u0001sale', GUENSTIG = '\u0001bis15', GUENSTIG_BIS = 15;

  /* 1.15.1: Merkliste bleibt beim Neuladen erhalten. Speicher kann fehlen oder gesperrt sein
     (privates Fenster) – dann läuft alles wie vorher, nur ohne Erinnern. */
  var MERK_SCHLUESSEL = 'kikripp_merkliste';
  function merkSichern() {
    try { window.localStorage.setItem(MERK_SCHLUESSEL, JSON.stringify(merk)); } catch (e) { /* egal */ }
  }
  function merkLaden() {
    var alt = {};
    try { alt = JSON.parse(window.localStorage.getItem(MERK_SCHLUESSEL) || '{}') || {}; } catch (e) { alt = {}; }
    merk = {};
    Object.keys(alt).forEach(function (nr) {
      var a = ARTIKEL.filter(function (x) { return x.nr === nr; })[0];
      var n = parseInt(alt[nr], 10);
      if (a && a.frei > 0 && n > 0) { merk[nr] = Math.min(n, a.frei); }   // Verkauftes fällt still heraus
    });
  }
  function istSale(a) { return a.vorher > 0 && a.preis > 0 && a.preis < a.vorher; }
  function istGuenstig(a) { return a.preis > 0 && brutto(a.preis) <= GUENSTIG_BIS + 0.004; }

  function eur(v) {
    return (v || 0).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' });
  }
  function sicher(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (z) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[z];
    });
  }
  // Zeilenumbrueche aus der Arbeitsmappe (Alt+Enter in Excel) sollen im Katalog
  // auch als Umbruch ankommen. Erst maskieren, dann umwandeln - nie umgekehrt.
  function absatz(s) { return sicher(s).replace(/\r?\n/g, '<br>'); }
  function el(id) { return document.getElementById(id); }
  function brutto(p) { return p * (1 + UST); }
  /** Betrag einer Zeile – Geschenke (Preis 0) heißen „kostenlos“ statt „0,00 €“. */
  function betrag(netto) { return netto > 0 ? eur(brutto(netto)) : 'kostenlos'; }
  function geschenk(a) { return !(a.preis > 0); }

  // Datumsrechnung immer in UTC und ab dem Serverdatum - die Uhr des Besuchers kann falsch gehen.
  function tag(iso) { return new Date(iso + 'T12:00:00Z'); }
  function iso(d) { return d.toISOString().slice(0, 10); }
  var WOCHENTAG = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
  function datumText(isoDatum) {
    var d = tag(isoDatum);
    return WOCHENTAG[d.getUTCDay()] + ', ' + ('0' + d.getUTCDate()).slice(-2) + '.' +
           ('0' + (d.getUTCMonth() + 1)).slice(-2) + '.' + d.getUTCFullYear();
  }
  /** Alle Tage mit den gewünschten Wochentagen ab morgen bis zum Abholschluss. */
  function tage(wochentage) {
    var aus = [];
    if (!HEUTE) { return aus; }
    var d = tag(HEUTE), ende = SCHLUSS ? tag(SCHLUSS) : new Date(d.getTime() + 70 * 864e5);
    // 1.12.0: frühestens ab „Termine ab“ (Einstellung), sonst ab morgen
    if (TERMINE_AB && TERMINE_AB > HEUTE) { d = new Date(tag(TERMINE_AB).getTime() - 864e5); }
    for (d = new Date(d.getTime() + 864e5); d <= ende && aus.length < 60; d = new Date(d.getTime() + 864e5)) {
      if (wochentage.indexOf(d.getUTCDay()) >= 0) { aus.push(iso(d)); }
    }
    return aus;
  }

  /** 1.12.0: „Wir melden uns …“ – während der Abwesenheit mit Datum, sonst wie bisher. */
  function rueckmeldung(standard) {
    if (!RUECK) { return standard; }
    var d = new Date(tag(RUECK).getTime() - 864e5);
    while (d.getUTCDay() === 0 || d.getUTCDay() === 6) { d = new Date(d.getTime() - 864e5); }
    return 'Wir sind bis ' + datumText(iso(d)).slice(4) + ' nicht im Haus und melden uns ab dem ' +
      datumText(RUECK).slice(4) + ' bei Ihnen.';
  }

  function hole(pfad, optionen) {
    return fetch(W.basis + pfad, Object.assign({
      credentials: 'same-origin',
      headers: W.nonce ? { 'Content-Type': 'application/json', 'X-WP-Nonce': W.nonce } : { 'Content-Type': 'application/json' },
      cache: 'no-store'
    }, optionen || {})).then(function (a) {
      return a.json().then(function (d) { return { status: a.status, daten: d }; });
    });
  }

  // ------------------------------------------------------------------ Sperre

  function zeigeSperre(meldung) {
    wurzel.innerHTML =
      '<div class="sperre"><div class="box">' +
      '<img src="' + sicher(W.signet) + '" alt="">' +
      '<div class="wort">KIKRIPP</div>' +
      '<h2>Artikelkatalog Betriebsauflösung</h2>' +
      '<p>Dieser Bereich ist geschützt. Bitte geben Sie das Passwort ein, das Sie von uns erhalten haben.</p>' +
      '<form id="k-sperrform">' +
      '<input type="password" id="k-pw" placeholder="Passwort" autocomplete="current-password">' +
      '<button type="submit" id="k-auf">Katalog öffnen</button>' +
      '</form><p class="fehler" id="k-fehler" role="alert">' + sicher(meldung || '') + '</p>' +
      '</div></div>';
    el('k-sperrform').addEventListener('submit', function (e) {
      e.preventDefault();
      var pw = el('k-pw').value.trim();
      var knopf = el('k-auf'), fehler = el('k-fehler');
      if (!pw) { fehler.textContent = 'Bitte Passwort eingeben.'; return; }
      knopf.disabled = true; knopf.textContent = 'Wird geprüft …'; fehler.textContent = '';
      hole('/zugang', { method: 'POST', body: JSON.stringify({ passwort: pw }) })
        .then(function (a) {
          if (a.daten && a.daten.ok) { laden(); return; }
          fehler.textContent = (a.daten && a.daten.meldung) || 'Passwort falsch.';
          knopf.disabled = false; knopf.textContent = 'Katalog öffnen';
          el('k-pw').select();
        })
        .catch(function () {
          fehler.textContent = 'Der Katalog ist gerade nicht erreichbar. Bitte später erneut versuchen.';
          knopf.disabled = false; knopf.textContent = 'Katalog öffnen';
        });
    });
  }

  // ------------------------------------------------------------------ Laden

  function laden() {
    wurzel.innerHTML = '<div class="laedt">Katalog wird geladen …</div>';
    hole('/artikel').then(function (a) {
      if (a.status === 401 || (a.daten && a.daten.gesperrt)) { zeigeSperre(''); return; }
      if (!a.daten || !a.daten.ok) { throw new Error('unerwartete Antwort'); }
      ARTIKEL = a.daten.artikel || [];
      UST = typeof a.daten.ust === 'number' ? a.daten.ust : 0.19;   // 0 = steuerfrei, nicht „fehlt“
      STEUER = a.daten.steuer || '';
      ABLAUF = a.daten.ablauf || '';
      MINDEST = a.daten.mindestwert || 0;
      GESCHENKE_MAX = a.daten.geschenke_max || 5;
      BES_AB = a.daten.besichtigung_ab || 0;
      SCHLUSS = a.daten.abholschluss || '';
      TERMINE_AB = a.daten.termine_ab || '';
      RUECK = a.daten.rueckmeldung_ab || '';
      HEUTE = a.daten.heute || iso(new Date());
      HINWEIS = a.daten.hinweis || '';
      FRIST = a.daten.frist || 3;
      IST_ADMIN = !!a.daten.admin;
      RECHT = a.daten.recht || '';
      ABHOLUNG = a.daten.abholung || '';
      ANBIETER = a.daten.anbieter || {};
      merkLaden();
      geruest();
      render();
    }).catch(function () {
      wurzel.innerHTML = '<div class="meldung schlecht">Der Katalog konnte nicht geladen werden. ' +
        'Bitte laden Sie die Seite neu. Besteht das Problem weiter, melden Sie sich bitte bei uns.</div>';
    });
  }

  // ------------------------------------------------------------------ Gerüst

  function geruest() {
    var kats = [], raeume = [];
    ARTIKEL.forEach(function (a) {
      if (a.kat && kats.indexOf(a.kat) < 0) { kats.push(a.kat); }
      if (a.raum && raeume.indexOf(a.raum) < 0) { raeume.push(a.raum); }
    });
    kats.sort();
    function optionen(liste) {
      return liste.map(function (v) { return '<option>' + sicher(v) + '</option>'; }).join('');
    }
    wurzel.innerHTML =
      (HINWEIS ? '<div class="band">' + sicher(HINWEIS) + '</div>' : '') +
      '<div class="kopf">' +
        '<h2>Artikelkatalog aus der Betriebsauflösung</h2>' +
        '<p>' + (ANBIETER.firma ? 'Ein Angebot der ' + sicher(ANBIETER.firma) + ' · ' : '') +
        'Abholung durch den Käufer · ' +
        (UST > 0 ? 'Preise inklusive ' + Math.round(UST * 100) + '&nbsp;% USt' : 'Endpreise, umsatzsteuerfrei') +
        (IST_ADMIN ? ' · <a href="' + sicher(W.verwaltung) + '">Reservierungen verwalten</a>' : '') + '</p>' +
      '</div>' +
      ablaufKasten() +
      '<div class="leiste"><div class="inner">' +
        '<div class="sum" id="k-merk"></div>' +
        '<button class="sek" id="k-leeren">Auswahl leeren</button>' +
        '<button id="k-anfragen">Reservierung abschicken</button>' +
      '</div><div class="merkliste" id="k-liste" hidden></div></div>' +
      '<div class="filter">' +
        '<div class="zeile">' +
          '<input type="search" id="k-q" placeholder="Suchen: Bezeichnung, Nummer, Beschreibung …">' +
          '<select id="k-raum"><option value="">Alle Räume</option>' + optionen(raeume) + '</select>' +
          '<select id="k-sort" aria-label="Sortierung"><option value="">Sortierung: Standard</option>' +
            '<option value="auf">Preis aufsteigend</option><option value="ab">Preis absteigend</option></select>' +
          '<label class="chk"><input type="checkbox" id="k-design"> nur Markenware</label>' +
          '<label class="chk"><input type="checkbox" id="k-neu"> nur Neuheiten</label>' +
          '<label class="chk"><input type="checkbox" id="k-frei" checked> nur verfügbare</label>' +
        '</div>' +
        // 1.15.1: Kategorien als Knöpfe statt Auswahlfeld – am Telefon eine Zeile zum Wischen
        '<div class="kats" id="k-kats" role="group" aria-label="Kategorien">' + katKnoepfe(kats) + '</div>' +
        '<div class="zaehler" id="k-zaehler"></div>' +
      '</div>' +
      '<div class="raster" id="k-raster"></div>' +
      // Formular und Bestätigung öffnen sich als Fenster über dem Katalog. Vorher stand das
      // Formular unter allen Artikeln, und die Seite sprang beim Öffnen ganz nach unten.
      '<div class="kik-fenster" id="k-fenster" hidden><div class="kik-fenster-box" role="dialog" aria-modal="true">' +
        '<button class="kik-zu" id="k-zu" aria-label="Schließen">×</button><div id="k-formular"></div></div></div>' +
      '<div class="kik-gross" id="k-gross" hidden><img alt=""><span></span>' +
        '<a class="teilen" href="#" target="_blank" rel="noopener">Per WhatsApp teilen</a></div>' +
      '<button class="nach-oben" id="k-oben" aria-label="Nach oben" hidden>↑</button>' +
      ((RECHT || ANBIETER.firma) ? '<div class="recht">' + anbieterBlock() +
        (RECHT ? '<h4>Kaufbedingungen</h4>' + RECHT.split(/\n\s*\n/).map(function (t) {
          return '<p>' + absatz(t.trim()) + '</p>'; }).join('') : '') +
        ((ABHOLUNG && ABHOLUNG !== ANBIETER.adresse)
          ? '<p>Abholung nach Terminvereinbarung: ' + sicher(ABHOLUNG) + '</p>' : '') +
        '</div>' : '');

    ['k-q', 'k-raum', 'k-sort', 'k-design', 'k-neu', 'k-frei'].forEach(function (id) {
      el(id).addEventListener('input', render);
    });
    el('k-kats').addEventListener('click', function (e) {
      var k = e.target.closest ? e.target.closest('button[data-kat]') : null;
      if (!k) { return; }
      waehleKat(k.getAttribute('data-kat'));
    });
    el('k-leeren').addEventListener('click', function () {
      merk = {}; listeOffen = false; leiste(); knoepfe();
    });
    el('k-anfragen').addEventListener('click', formular);
    el('k-merk').addEventListener('click', function (e) {
      if (!auswahl().length || (e.target.classList && e.target.classList.contains('geschenke-link'))) { return; }
      listeOffen = !listeOffen; leiste();
    });
    el('k-zu').addEventListener('click', schliessen);
    el('k-fenster').addEventListener('click', function (e) { if (e.target === this) { schliessen(); } });
    el('k-gross').addEventListener('click', function (e) {
      if (e.target.classList && e.target.classList.contains('teilen')) { return; }   // Link öffnen, Bild bleibt
      this.hidden = true;
    });
    el('k-oben').addEventListener('click', function () {
      wurzel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    window.addEventListener('scroll', function () {
      var k = el('k-oben'); if (k) { k.hidden = window.scrollY < 900; }
    }, { passive: true });
    leiste();
  }

  /** 1.15.1: Kategorie-Knöpfe mit Zahl der verfügbaren Artikel. „Sale“ erscheint nur, wenn es
      Sale-Artikel gibt; Sale- und Preis-Knopf sind Zusatzsichten – der Artikel bleibt auch in seiner Kategorie. */
  function katKnoepfe(kats) {
    var frei = ARTIKEL.filter(function (a) { return a.frei > 0; });
    function zahl(f) { return frei.filter(f).length; }
    function knopf(wert, text, n, extra) {
      return '<button type="button" data-kat="' + sicher(wert) + '" class="kat' + (extra || '') +
        (katWahl === wert ? ' an' : '') + '" aria-pressed="' + (katWahl === wert) + '">' +
        sicher(text) + ' <span>' + n + '</span></button>';
    }
    var aus = knopf('', 'Alle', frei.length);
    var nSale = zahl(istSale);
    if (nSale) { aus += knopf(SALE, 'Sale', nSale, ' sale'); }
    var nG = zahl(istGuenstig);
    if (nG) { aus += knopf(GUENSTIG, 'bis ' + GUENSTIG_BIS + ' €', nG, ' preiswert'); }
    kats.forEach(function (k) {
      aus += knopf(k, k, zahl(function (a) { return a.kat === k; }));
    });
    return aus;
  }
  function katListe() {
    var kats = [];
    ARTIKEL.forEach(function (a) { if (a.kat && kats.indexOf(a.kat) < 0) { kats.push(a.kat); } });
    return kats.sort();
  }
  function waehleKat(wert) {
    katWahl = wert || '';
    el('k-kats').innerHTML = katKnoepfe(katListe());
    render();
  }
  function passtKat(a) {
    if (!katWahl) { return true; }
    if (katWahl === SALE) { return istSale(a); }
    if (katWahl === GUENSTIG) { return istGuenstig(a); }
    return a.kat === katWahl;
  }

  var listeOffen = false;

  function schliessen() {
    el('k-fenster').hidden = true;
    document.documentElement.classList.remove('kik-offen');
    el('k-formular').innerHTML = '';
  }

  // Esc schließt Fenster und Großbild
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') { return; }
    if (el('k-gross') && !el('k-gross').hidden) { el('k-gross').hidden = true; return; }
    if (el('k-fenster') && !el('k-fenster').hidden) { schliessen(); }
  });

  /* „So läuft es ab“: jede Zeile aus den Einstellungen wird ein Absatz. Auf dem Telefon
     zugeklappt, damit die Artikel nicht erst nach einem Bildschirm Text beginnen. */
  function ablaufKasten() {
    var punkte = String(ABLAUF).split(/\r?\n/).map(function (t) { return t.trim(); }).filter(Boolean);
    if (!punkte.length) { return ''; }
    var offen = window.matchMedia && window.matchMedia('(min-width: 561px)').matches;
    return '<details class="ablauf"' + (offen ? ' open' : '') + '><summary>So läuft es ab</summary>' +
      punkte.map(function (t) { return '<p>' + sicher(t) + '</p>'; }).join('') + '</details>';
  }

  /* Anbieterkennzeichnung. Der Katalog liegt auf fremdem Speicherplatz — es muss
     deshalb unmissverständlich dranstehen, wer hier verkauft. */
  function anbieterBlock() {
    if (!ANBIETER.firma) { return ''; }
    var zeilen = [sicher(ANBIETER.firma)];
    if (ANBIETER.adresse) {
      // Die Abholadresse beginnt meist mit der Firma – dann nicht doppelt nennen.
      var a = String(ANBIETER.adresse);
      zeilen.push(sicher(a.indexOf(ANBIETER.firma) === 0
        ? a.slice(ANBIETER.firma.length).replace(/^[,\s]+/, '') : a));
    }
    var kontakt = [];
    if (ANBIETER.telefon) { kontakt.push('Telefon ' + sicher(ANBIETER.telefon)); }
    if (ANBIETER.email) {
      kontakt.push('<a href="mailto:' + sicher(ANBIETER.email) + '">' + sicher(ANBIETER.email) + '</a>');
    }
    if (ANBIETER.impressum) {
      kontakt.push('<a href="' + sicher(ANBIETER.impressum) + '" target="_blank" rel="noopener">Impressum</a>');
    }
    if (ANBIETER.datenschutz) {
      kontakt.push('<a href="' + sicher(ANBIETER.datenschutz) + '" target="_blank" rel="noopener">Datenschutz</a>');
    }
    return '<h4>Anbieter</h4><p>' + zeilen.join(' · ') + '</p>' +
           (kontakt.length ? '<p>' + kontakt.join(' · ') + '</p>' : '');
  }

  // ------------------------------------------------------------------ Karten

  function render() {
    var q = el('k-q').value.toLowerCase().trim();
    var raum = el('k-raum').value;
    var nurFrei = el('k-frei').checked, nurDesign = el('k-design').checked, nurNeu = el('k-neu').checked;
    var liste = ARTIKEL.filter(function (a) {
      return (!q || (a.nr + ' ' + a.titel + ' ' + a.beschr + ' ' + (a.buendel || '')).toLowerCase().indexOf(q) >= 0)
        && passtKat(a) && (!raum || a.raum === raum)
        && (!nurFrei || a.frei > 0) && (!nurDesign || !!a.marke) && (!nurNeu || !!a.neu);
    });
    var sort = el('k-sort') ? el('k-sort').value : '';
    if (sort) {
      liste = liste.slice().sort(function (x, y) { return sort === 'auf' ? x.preis - y.preis : y.preis - x.preis; });
    } else {
      // Standard (1.15.1): Neuheiten zuerst, die jüngsten oben (Tag des Imports), dann Sale,
      // dann die Reihenfolge der Importdatei (stabil über den Index)
      var rang = function (a) { return a.neu ? 0 : (istSale(a) ? 1 : 2); };
      liste = liste.map(function (a, i) { return [a, i]; })
        .sort(function (x, y) {
          return rang(x[0]) - rang(y[0]) ||
            (x[0].neu ? String(y[0].neu_tag || '').localeCompare(String(x[0].neu_tag || '')) : 0) ||
            x[1] - y[1];
        })
        .map(function (p) { return p[0]; });
    }
    el('k-zaehler').innerHTML = '<b>' + liste.length + '</b> von ' + ARTIKEL.length + ' Positionen';
    el('k-raster').innerHTML = liste.length
      ? liste.map(karte).join('')
      : '<div class="leer">Keine Artikel gefunden – bitte Filter anpassen.</div>';
  }

  function karte(a) {
    var frei = a.frei > 0;
    var bild = a.bild
      ? '<img src="' + sicher(a.bild) + '" alt="' + sicher(a.titel) + '" loading="lazy" data-gross="' + sicher(a.nr) + '" title="Zum Vergrößern klicken">'
      : '<div class="kein-bild">kein Foto</div>';
    var abzeichen = frei
      ? '<span class="badge frei">verfügbar</span>'
      : '<span class="badge res">reserviert</span>';
    // Teilreservierung sichtbar machen: „5 von 10 verfügbar“
    var mengeText = !frei
      ? 'vollständig reserviert (' + a.menge + ' ' + a.einheit + ')'
      : (a.reserviert > 0
          ? a.frei + ' von ' + a.menge + ' ' + a.einheit + ' verfügbar'
          : a.menge + ' ' + a.einheit + ' verfügbar');
    var knapp = (a.reserviert > 0 && a.frei > 0) ? ' class="knapp"' : '';
    var vhb = a.basis === 'VHB' ? '<span class="vhb">VHB</span>' : '';
    var auswahl = frei
      ? '<div class="mengen">' +
          '<input type="number" min="1" max="' + a.frei + '" step="1" value="' + (merk[a.nr] || 1) + '" ' +
          'id="m-' + sicher(a.nr) + '" data-menge="' + sicher(a.nr) + '" aria-label="Stückzahl ' + sicher(a.nr) + '">' +
          '<button data-res="' + sicher(a.nr) + '"' + (merk[a.nr] ? ' class="drin"' : '') + '>' + knopfText(a.nr) + '</button>' +
        '</div>'
      : interesse(a);
    return '<div class="karte' + (frei ? '' : ' weg') + '">' +
      '<div class="bild">' + bild + '<span class="nr">' + sicher(a.nr) + '</span>' + abzeichen +
        (a.marke ? '<span class="markenschild">' + sicher(a.marke) + '</span>' : '') +
        (a.neu ? '<span class="neuschild">neu</span>' : '') + '</div>' +
      '<div class="txt"><h3>' + sicher(a.titel) + '</h3>' +
      '<p class="b">' + absatz(a.beschr) + '</p>' +
      (a.mengenhinweis ? '<p class="hw">' + absatz(a.mengenhinweis) + '</p>' : '') +
      '<div class="meta">' +
        '<span>Zustand: ' + sicher(a.zustand) + '</span>' +
        '<span' + knapp + '>' + mengeText + '</span>' +
        (a.masse ? '<span>' + sicher(a.masse) + '</span>' : '') +
        '<span>' + sicher(a.raum) + '</span>' +
        (BES_AB > 0 && a.preis >= BES_AB ? '<span class="bes">Besichtigung möglich</span>' : '') +
        (a.buendel ? '<span class="bnd">Sammlung ' + sicher(a.buendel) + '</span>' : '') +
      '</div>' +
      (geschenk(a)
        ? '<div class="preis geschenk"><b>Kostenlos zu Ihrem Einkauf</b><small>' +
            (MINDEST > 0 ? 'ab einem Einkauf von ' + eur(MINDEST) + ' · ' : 'nur zusammen mit einem Kauf · ') +
            'nur Abholung · höchstens ' + GESCHENKE_MAX + ' Geschenke je Reservierung</small><small class="kita">' + KITA + '</small></div>'
        : '<div class="preis' + (istSale(a) ? ' im-sale' : '') + '">' +
          (istSale(a) ? '<span class="saleschild">Sale</span><s>' + eur(brutto(a.vorher)) + '</s>' : '') +
          '<b>' + eur(brutto(a.preis)) + vhb + '</b>' +
          '<small>' + (UST > 0 ? 'inkl. USt · netto ' + eur(a.preis) : sicher(STEUER || 'Endpreis')) +
          ' · je ' + sicher(a.einheit) + '</small></div>') +
      auswahl + '</div></div>';
  }

  /** 1.11.0: Reservierte Artikel – Interesse per Mail melden, damit sichtbar wird, ob es weitere Interessenten gibt. */
  function interesse(a) {
    if (!ANBIETER.email) { return ''; }
    var betreff = 'Interesse an ' + a.nr + ' ' + a.titel;
    var text = 'Guten Tag,\n\nich interessiere mich für den Artikel ' + a.nr + ' (' + a.titel + '), ' +
      'der im Katalog gerade reserviert ist. Bitte melden Sie sich, falls er wieder frei wird.\n\n' +
      'Name:\nTelefon:\n';
    return '<div class="interesse"><a href="mailto:' + sicher(ANBIETER.email) + '?subject=' +
      encodeURIComponent(betreff) + '&amp;body=' + encodeURIComponent(text) + '">Interesse? Melden Sie sich</a>' +
      '<small>Wir merken Sie vor, falls der Artikel wieder frei wird.</small></div>';
  }

  function knopfText(nr) {
    return merk[nr] ? '✓ vorgemerkt (' + merk[nr] + ')' : 'reservieren';
  }
  /** Knöpfe der Karten an die Merkliste angleichen, ohne die Liste neu aufzubauen. */
  function knoepfe() {
    Array.prototype.forEach.call(wurzel.querySelectorAll('button[data-res]'), function (k) {
      var nr = k.getAttribute('data-res');
      k.textContent = knopfText(nr);
      k.className = merk[nr] ? 'drin' : '';
    });
  }

  // Foto groß anzeigen
  document.addEventListener('click', function (e) {
    var nr = e.target && e.target.dataset && e.target.dataset.gross;
    if (!nr) { return; }
    var a = ARTIKEL.filter(function (x) { return x.nr === nr; })[0];
    if (!a || !a.bild) { return; }
    var g = el('k-gross');
    g.querySelector('img').src = a.bild;
    g.querySelector('span').textContent = a.nr + ' · ' + a.titel + ' – zum Schließen klicken';
    // 1.15.1: Teilen per WhatsApp – nur hier in der Großansicht, damit die Karten schlicht bleiben
    var t = g.querySelector('.teilen');
    if (t) { t.href = 'https://wa.me/?text=' + encodeURIComponent(teilText(a)); }
    g.hidden = false;
  });
  function teilText(a) {
    var adresse = location.origin + location.pathname;
    return 'Schau mal, im Kikripp-Artikelkatalog: ' + a.titel + ' (' + a.nr + ') – ' +
      (geschenk(a) ? 'kostenlos zum Einkauf' : eur(brutto(a.preis))) + '\n' + adresse;
  }

  // Eingabefeld: hart auf die verfügbare Menge begrenzen
  document.addEventListener('input', function (e) {
    var nr = e.target && e.target.dataset && e.target.dataset.menge;
    if (!nr) { return; }
    var a = ARTIKEL.filter(function (x) { return x.nr === nr; })[0];
    if (!a) { return; }
    var n = parseInt(e.target.value, 10);
    if (isNaN(n) || n < 1) { return; }        // leeres Feld beim Tippen zulassen
    if (n > a.frei) { e.target.value = a.frei; }
  });

  // „reservieren“ übernimmt die eingetragene Menge – ohne sie zu verändern
  document.addEventListener('click', function (e) {
    var nr = e.target && e.target.dataset && e.target.dataset.res;
    if (!nr) { return; }
    var a = ARTIKEL.filter(function (x) { return x.nr === nr; })[0];
    if (!a) { return; }
    var feld = el('m-' + nr);
    var n = feld ? parseInt(feld.value, 10) : 1;
    if (isNaN(n) || n < 1) { n = 1; }
    if (n > a.frei) { n = a.frei; if (feld) { feld.value = n; } }
    if (geschenk(a) && !IST_ADMIN && !merk[nr] && auswahl().filter(function (p) { return geschenk(p.a); }).length >= GESCHENKE_MAX) {
      window.alert('Je Reservierung können höchstens ' + GESCHENKE_MAX + ' Artikel „zu verschenken“ dabei sein.');
      return;
    }
    merk[nr] = n;
    leiste();
    knoepfe();
  });

  // ------------------------------------------------------------------ Leiste

  function auswahl() {
    return Object.keys(merk).map(function (nr) {
      var a = ARTIKEL.filter(function (x) { return x.nr === nr; })[0];
      return a ? { a: a, menge: merk[nr] } : null;
    }).filter(Boolean);
  }

  var KITA = 'Kitas, Schulen und Vereine: für größere Mengen bitte direkt melden.';

  /** 1.10.1: Hinweis in der Leiste, sobald etwas vorgemerkt ist und es Geschenke im Katalog gibt. */
  function geschenkHinweis(w) {
    if (IST_ADMIN || !ARTIKEL.some(geschenk)) { return ''; }
    var n = w.filter(function (p) { return geschenk(p.a); }).length;
    return '<br><span class="geschenke-info">Zu verschenken: ' + n + ' von ' + GESCHENKE_MAX + ' – kostenlos zu Ihrem Einkauf · ' +
      '<a href="#" class="geschenke-link">Geschenke ansehen</a> · ' + KITA + '</span>';
  }

  function leiste() {
    merkSichern();                       // jede Änderung der Merkliste läuft hier vorbei
    var w = auswahl();
    var stueck = 0, netto = 0;
    w.forEach(function (p) { stueck += p.menge; netto += p.menge * p.a.preis; });
    // Geschenke zählen nicht zum Mindestbestellwert. 1.12.0: Geschenke nur zusammen mit einem Kauf.
    var nurGeschenke = !IST_ADMIN && stueck > 0 && netto <= 0;
    // Die Verwaltung (angemeldet) reserviert im Namen von Kunden ohne Mindestbestellwert.
    var fehlt = MINDEST > 0 && netto > 0 && !IST_ADMIN ? MINDEST - brutto(netto) : 0;
    el('k-merk').innerHTML = stueck
      ? stueck + ' Stück vorgemerkt · <b>' + betrag(netto) + '</b>' +
        (UST > 0 ? ' <span style="opacity:.8">inkl. USt</span>' : '') +
        (fehlt > 0.004 ? '<br><span class="mindest">Mindestbestellwert ' + eur(MINDEST) +
          ' – es fehlen noch ' + eur(fehlt) + '</span>' : '') +
        (nurGeschenke ? '<br><span class="mindest">Geschenke gibt es nur kostenlos zu Ihrem Einkauf' +
          (MINDEST > 0 ? ' (ab ' + eur(MINDEST) + ')' : '') + ' – bitte wählen Sie noch Artikel zum Kauf dazu.</span>' : '') +
        geschenkHinweis(w)
      : 'Noch nichts vorgemerkt – Stückzahl eintragen und auf „reservieren“ klicken.' +
        (IST_ADMIN ? ' Sie sind als Verwaltung angemeldet: Mindestbestellwert und Geschenke-Grenze gelten für Sie nicht.'
          : (MINDEST > 0 ? ' Mindestbestellwert ' + eur(MINDEST) + ' (gilt nicht für Artikel „zu verschenken“).' : '') +
            (ARTIKEL.some(geschenk) ? ' ' + KITA : ''));
    el('k-anfragen').disabled = stueck === 0 || fehlt > 0.004 || nurGeschenke;
    // Ohne Auswahl braucht die Leiste auf dem Telefon keine Knoepfe (siehe katalog.css).
    var l = wurzel.querySelector('.leiste');
    if (l) { l.className = stueck ? 'leiste' : 'leiste leer'; }
    if (!stueck) { listeOffen = false; }
    if (stueck) {
      el('k-merk').innerHTML += ' <span class="liste-knopf">' + (listeOffen ? 'Liste schließen ▴' : 'Liste ansehen ▾') + '</span>';
    }
    var liste = el('k-liste');
    liste.hidden = !listeOffen;
    liste.innerHTML = listeOffen ? w.map(function (p) {
      return '<div class="zeile"><span>' + sicher(p.a.nr) + ' · ' + sicher(p.a.titel) + '</span>' +
        '<input type="number" min="1" max="' + p.a.frei + '" value="' + p.menge + '" data-liste="' + sicher(p.a.nr) + '" aria-label="Stückzahl">' +
        '<b>' + betrag(p.menge * p.a.preis) + '</b>' +
        '<button class="weg" data-weg="' + sicher(p.a.nr) + '" aria-label="Entfernen">×</button></div>';
    }).join('') : '';
  }

  // „Geschenke ansehen“: Katalog auf die Kategorie „zu verschenken“ filtern
  document.addEventListener('click', function (e) {
    if (!e.target || !e.target.classList || !e.target.classList.contains('geschenke-link')) { return; }
    e.preventDefault(); e.stopPropagation();
    var g = ARTIKEL.filter(geschenk)[0];
    if (!g) { return; }
    el('k-q').value = '';
    el('k-frei').checked = true;
    waehleKat(g.kat);
    el('k-raster').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  // Merkliste: Menge ändern oder Artikel entfernen
  document.addEventListener('change', function (e) {
    var nr = e.target && e.target.dataset && e.target.dataset.liste;
    if (!nr) { return; }
    var a = ARTIKEL.filter(function (x) { return x.nr === nr; })[0];
    var n = parseInt(e.target.value, 10);
    if (!a || isNaN(n) || n < 1) { n = 1; }
    merk[nr] = Math.min(n, a ? a.frei : n);
    leiste(); knoepfe();
  });
  document.addEventListener('click', function (e) {
    var nr = e.target && e.target.dataset && e.target.dataset.weg;
    if (!nr) { return; }
    delete merk[nr];
    leiste(); knoepfe();
  });

  // ------------------------------------------------------------------ Formular

  function auswahlFeld(id, liste, leer) {
    return '<select id="' + id + '"><option value="">' + sicher(leer) + '</option>' +
      liste.map(function (w) { return '<option value="' + sicher(w[0]) + '">' + sicher(w[1]) + '</option>'; }).join('') +
      '</select>';
  }

  function formular() {
    var w = auswahl();
    if (!w.length) { return; }
    var netto = 0, stueck = 0, teuerster = 0;
    var zeilen = w.map(function (p) {
      netto += p.menge * p.a.preis; stueck += p.menge; teuerster = Math.max(teuerster, p.a.preis);
      return '<div><span>' + p.menge + ' × ' + sicher(p.a.nr) + ' ' + sicher(p.a.titel) + '</span>' +
             '<span>' + (p.a.preis > 0 ? betrag(p.menge * p.a.preis) : 'kostenlos zu Ihrem Einkauf') + '</span></div>';
    }).join('');
    var mitBesichtigung = BES_AB > 0 && teuerster >= BES_AB;
    var bestage = tage(TERMIN_TAGE).map(function (d) { return [d, datumText(d)]; });
    var abholtage = bestage;

    el('k-formular').innerHTML =
      '<div class="dlg" id="k-dlg">' +
      '<h3>Reservierung abschicken</h3>' +
      '<p class="s">Die Artikel bleiben ' + FRIST + ' Werktage für Sie reserviert. ' +
      rueckmeldung('Nach Eingang Ihrer Reservierung melden wir uns bei Ihnen.') + ' Eine Reservierung ist noch kein Kaufvertrag – dieser kommt mit Ihrer unterschriebenen ' +
      'Bestellung zustande. Sie können die Reservierung jederzeit formlos zurücknehmen.</p>' +
      (IST_ADMIN ? '<div class="meldung">Sie sind als Verwaltung angemeldet: <b>Name und Telefon genügen</b>, ' +
        'alles andere darf leer bleiben.</div>' : '') +
      '<div class="pos">' + zeilen +
        '<div style="border-top:1px solid #dcdcdc;margin-top:8px;padding-top:8px">' +
        '<b>' + stueck + ' Stück gesamt</b><b>' + betrag(netto) + (UST > 0 && netto > 0 ? ' inkl. USt' : '') + '</b></div></div>' +
      '<div class="feld"><label for="k-name">Name *</label><input id="k-name" autocomplete="name" required></div>' +
      '<div class="feld"><label for="k-firma">Firma / Einrichtung</label><input id="k-firma" autocomplete="organization">' +
      '<small class="hint">Leer lassen, wenn Sie als Privatperson kaufen.</small></div>' +
      '<div class="feld"><label for="k-strasse">Straße und Hausnummer *</label><input id="k-strasse" autocomplete="street-address" required></div>' +
      '<div class="feld zwei"><div><label for="k-plz">PLZ *</label><input id="k-plz" inputmode="numeric" autocomplete="postal-code" maxlength="5" required></div>' +
      '<div><label for="k-ort">Ort *</label><input id="k-ort" autocomplete="address-level2" required></div></div>' +
      '<div class="feld"><label for="k-mail">E-Mail *</label><input id="k-mail" type="email" autocomplete="email" required></div>' +
      '<div class="feld"><label for="k-tel">Telefon *</label><input id="k-tel" type="tel" autocomplete="tel" required>' +
      '<small class="hint">Wir melden uns nach der Reservierung – bitte unbedingt angeben.</small></div>' +
      (mitBesichtigung
        ? '<div class="feld"><label class="chk2"><input type="checkbox" id="k-bes"> Ich möchte die Artikel vorab besichtigen ' +
          '(Mo–Mi 08:00–12:00 Uhr, Do 08:00–15:00 Uhr)</label>' +
          '<div class="zwei" id="k-bes-wahl" hidden><div>' + auswahlFeld('k-bes-tag', bestage, 'Tag wählen (Mo–Do)') + '</div>' +
          '<div>' + auswahlFeld('k-bes-zeit', BES_ZEITEN.map(function (z) { return [z, z + ' Uhr']; }), 'Uhrzeit wählen') + '</div></div></div>'
        : (BES_AB > 0 ? '<p class="hint-bes">Eine Besichtigung bieten wir für Artikel ab ' + eur(BES_AB) + ' an.</p>' : '')) +
      '<div class="feld"><label for="k-abhol">Gewünschter Abholtermin *</label>' +
        '<div class="zwei"><div>' + auswahlFeld('k-abhol', abholtage, 'Tag wählen (Mo–Do)') + '</div>' +
        '<div>' + auswahlFeld('k-abhol-zeit', BES_ZEITEN.map(function (z) { return [z, z + ' Uhr']; }), 'Uhrzeit (optional)') +
        '</div></div>' +
        '<small class="hint">Abholung Mo–Mi 08:00–12:00 Uhr, Do 08:00–15:00 Uhr' +
        (TERMINE_AB && TERMINE_AB > HEUTE ? ', frühestens ab ' + datumText(TERMINE_AB).slice(4) : '') +
        (SCHLUSS ? ', spätestens ' + datumText(SCHLUSS).slice(4) : '') + '. Bei Überweisung wird nach Zahlungseingang abgeholt.</small>' +
        '<label class="chk2"><input type="checkbox" id="k-demontage"> Termin am Nachmittag oder Demontage nötig – ' +
        'nach Vereinbarung</label></div>' +
      // 1.15.0: Bezahlung
      '<div class="feld"><label>Bezahlung' + (IST_ADMIN ? ' (freiwillig)' : ' *') + '</label>' +
        '<label class="chk2"><input type="radio" name="k-zahl" value="ueberweisung"> Überweisung vorab – die Rechnung kommt per E-Mail</label>' +
        '<label class="chk2"><input type="radio" name="k-zahl" value="bar"> Bar bei Abholung – die Rechnung erhalten Sie vor Ort</label></div>' +
      '<div class="feld"><label for="k-text">Nachricht (optional)</label><textarea id="k-text" rows="2"></textarea></div>' +
      // Unsichtbares Feld gegen Formular-Roboter. Menschen sehen es nicht und lassen es leer.
      '<div class="hp" aria-hidden="true"><label for="k-webseite">Webseite</label>' +
      '<input id="k-webseite" tabindex="-1" autocomplete="off"></div>' +
      '<p class="datenschutz">Ihre Angaben verwenden wir ausschließlich zur Abwicklung dieser Reservierung und für ' +
      'Bestellung und Rechnung. Sie werden auf dieser Website gespeichert und nach Abschluss des Verkaufs gelöscht; ' +
      'Rechnungsdaten bewahren wir so lange auf, wie es das Gesetz verlangt. ' +
      '<strong>Sie erhalten keine Bestätigungsmail</strong> – bitte machen Sie im nächsten Schritt ein Bildschirmfoto.</p>' +
      '<div id="k-meldung"></div>' +
      '<button id="k-senden">Reservierung verbindlich abschicken</button> ' +
      '<button class="sek" style="color:#1a1a1a;border-color:#dcdcdc" id="k-abbrechen">Abbrechen</button>' +
      '</div>';

    formularSeit = Date.now();
    el('k-fenster').hidden = false;
    document.documentElement.classList.add('kik-offen');
    el('k-fenster').scrollTop = 0;
    if (el('k-bes')) {
      el('k-bes').addEventListener('change', function () { el('k-bes-wahl').hidden = !this.checked; });
    }
    // 1.14.0: Uhrzeiten passen sich dem gewählten Tag an (donnerstags bis 15 Uhr)
    [['k-bes-tag', 'k-bes-zeit', 'Uhrzeit wählen'], ['k-abhol', 'k-abhol-zeit', 'Uhrzeit (optional)']].forEach(function (f) {
      var tagFeld = el(f[0]), zeitFeld = el(f[1]);
      if (!tagFeld || !zeitFeld) { return; }
      tagFeld.addEventListener('change', function () {
        var alt = zeitFeld.value;
        zeitFeld.innerHTML = zeitOptionen(tagFeld.value, f[2]);
        if (zeitenAm(tagFeld.value).indexOf(alt) >= 0) { zeitFeld.value = alt; }
      });
    });
    if (IST_ADMIN) {   // 1.11.2: Verwaltung – nur Name und Telefon sind Pflicht, die übrigen Sternchen fallen weg
      ['k-strasse', 'k-plz', 'k-ort', 'k-mail', 'k-abhol'].forEach(function (id) {
        var l = wurzel.querySelector('label[for="' + id + '"]');
        if (l) { l.textContent = l.textContent.replace(/\s*\*$/, '') + ' (freiwillig)'; }
      });
    }
    el('k-abbrechen').addEventListener('click', schliessen);
    el('k-senden').addEventListener('click', senden);
    var erstes = el('k-name'); if (erstes) { erstes.focus({ preventScroll: true }); }
  }

  var letzteAuswahl = [];


  function beleg_positionen() {
    var netto = 0, stueck = 0;
    var zeilen = letzteAuswahl.map(function (p) {
      netto += p.menge * p.preis; stueck += p.menge;
      return '<div class="zeile"><span>' + p.menge + ' × ' + sicher(p.nr) + ' ' +
             sicher(p.titel) + '</span><b>' + (p.preis > 0 ? betrag(p.menge * p.preis) : 'kostenlos zu Ihrem Einkauf') + '</b></div>';
    }).join('');
    return zeilen + '<div class="zeile summe"><span>' + stueck + ' Stück gesamt</span><b>' +
           betrag(netto) + (UST > 0 && netto > 0 ? ' inkl. USt' : '') + '</b></div>';
  }

  function senden() {
    var knopf = el('k-senden'), meldung = el('k-meldung');
    letzteAuswahl = auswahl().map(function (p) {
      return { nr: p.a.nr, titel: p.a.titel, preis: p.a.preis, menge: p.menge };
    });
    function wert(id) { return el(id) ? el(id).value.trim() : ''; }
    var besichtigung = !!(el('k-bes') && el('k-bes').checked);
    var nutzlast = {
      name: wert('k-name'), firma: wert('k-firma'), strasse: wert('k-strasse'),
      plz: wert('k-plz'), ort: wert('k-ort'),
      email: wert('k-mail'), telefon: wert('k-tel'), nachricht: wert('k-text'),
      besichtigung: besichtigung, besichtigung_tag: wert('k-bes-tag'), besichtigung_zeit: wert('k-bes-zeit'),
      zahlart: (wurzel.querySelector('input[name="k-zahl"]:checked') || {}).value || '',
      abholwunsch: wert('k-abhol'), abholwunsch_zeit: wert('k-abhol') ? wert('k-abhol-zeit') : '', demontage: !!(el('k-demontage') && el('k-demontage').checked),
      webseite: wert('k-webseite'), dauer: Date.now() - formularSeit,
      artikel: merk
    };
    function fehler(t) { meldung.innerHTML = '<div class="meldung schlecht">' + t + '</div>'; }
    if (!nutzlast.name) { fehler('Bitte geben Sie Ihren Namen an.'); return; }
    // 1.11.2: angemeldet (Verwaltung, Barverkauf vor Ort) genügen Name und Telefon
    var adminKurz = IST_ADMIN && !nutzlast.strasse && !nutzlast.ort && !nutzlast.plz;
    if (!adminKurz && (!nutzlast.strasse || !nutzlast.ort || !/^\d{4,5}$/.test(nutzlast.plz))) {
      fehler('Bitte geben Sie Ihre vollständige Anschrift an (Straße, Postleitzahl, Ort) – sie wird für die Rechnung gebraucht.');
      return;
    }
    if (!nutzlast.email && !IST_ADMIN) { fehler('Bitte geben Sie eine E-Mail-Adresse an.'); return; }
    if (nutzlast.telefon.replace(/\D/g, '').length < 6) {
      fehler('Bitte geben Sie eine Telefonnummer an, unter der wir Sie erreichen. Wir melden uns nach der ' +
        'Reservierung bei Ihnen.');
      return;
    }
    if (besichtigung && (!nutzlast.besichtigung_tag || !nutzlast.besichtigung_zeit)) {
      fehler('Bitte wählen Sie für die Besichtigung einen Tag (Montag bis Donnerstag) und eine Uhrzeit.'); return;
    }
    if (!nutzlast.zahlart && !IST_ADMIN) {
      fehler('Bitte wählen Sie, wie Sie bezahlen möchten: Überweisung vorab oder bar bei Abholung.'); return;
    }
    if (!nutzlast.abholwunsch && !nutzlast.demontage && !IST_ADMIN) {
      fehler('Bitte wählen Sie einen Wunschtermin für die Abholung oder kreuzen Sie „nach Vereinbarung“ an.');
      return;
    }

    knopf.disabled = true; knopf.textContent = 'Wird abgeschickt …'; meldung.innerHTML = '';
    hole('/reservierung', { method: 'POST', body: JSON.stringify(nutzlast) })
      .then(function (a) {
        if (a.daten && a.daten.ok) {
          // Die Bildschirmbestätigung ist der einzige Nachweis, den der Interessent
          // bekommt – es geht bewusst keine Mail an ihn. Deshalb steht hier alles,
          // was er später braucht, in einem Block zum Abfotografieren.
          var k = a.daten.kontakt || {};
          el('k-formular').innerHTML =
            '<div class="meldung gut"><strong>Vielen Dank – Ihre Reservierung ist eingegangen.</strong><br>' +
            rueckmeldung('Wir melden uns in den nächsten Tagen bei Ihnen.') +
            '<div class="beleg">' +
              '<div class="zeile"><span>Vorgangsnummer</span><b>' + a.daten.vorgang + '</b></div>' +
              (a.daten.bis ? '<div class="zeile"><span>Reserviert bis</span><b>' + datumText(a.daten.bis) + '</b></div>' : '') +
              beleg_positionen() +
              (nutzlast.besichtigung ? '<div class="zeile"><span>Besichtigung gewünscht</span><b>' +
                datumText(nutzlast.besichtigung_tag) + ', ' + sicher(nutzlast.besichtigung_zeit) + ' Uhr</b></div>' : '') +
              '<div class="zeile"><span>Abholung gewünscht</span><b>' +
                (nutzlast.abholwunsch ? datumText(nutzlast.abholwunsch) +
                  (nutzlast.abholwunsch_zeit ? ', ' + sicher(nutzlast.abholwunsch_zeit) + ' Uhr' : '') : '') +
                (nutzlast.demontage ? (nutzlast.abholwunsch ? ' · ' : '') + 'Termin nach Vereinbarung' : '') + '</b></div>' +
              (nutzlast.zahlart ? '<div class="zeile"><span>Bezahlung</span><b>' +
                (nutzlast.zahlart === 'bar' ? 'bar bei Abholung (Rechnung vor Ort)' : 'Überweisung vorab (Rechnung per E-Mail)') + '</b></div>' : '') +
              (k.email || k.telefon
                ? '<div class="zeile"><span>Wir erreichen Sie unter</span><b>' +
                  [k.email, k.telefon].filter(Boolean).map(sicher).join(' · ') + '</b></div>'
                : '') +
            '</div>' +
            '<p class="s" style="margin:10px 0 0">Bitte machen Sie ein <strong>Bildschirmfoto</strong> – ' +
            'Sie erhalten keine Bestätigungsmail. Stimmen Ihre Kontaktdaten nicht? Schreiben Sie uns ' +
            (ANBIETER.email ? 'an <a href="mailto:' + sicher(ANBIETER.email) + '">' +
              sicher(ANBIETER.email) + '</a>' : 'kurz') + '.</p>' +
            (a.daten.mail ? '' : '<p class="s" style="margin:8px 0 0"><em>Ihre Reservierung ist ' +
            'gespeichert. Sollten wir uns nicht innerhalb von zwei Werktagen melden, ' +
            'kontaktieren Sie uns bitte noch einmal.</em></p>') +
            '<p class="knoepfe-beleg"><button id="k-drucken">Bestätigung drucken / als PDF speichern</button> ' +
            '<button class="sek" style="color:#1a1a1a;border-color:#dcdcdc" id="k-fertig">Schließen</button></p>' +
            '</div>';
          el('k-drucken').addEventListener('click', function () { window.print(); });
          el('k-fertig').addEventListener('click', schliessen);
          ARTIKEL = a.daten.artikel || ARTIKEL;
          merk = {};
          listeOffen = false;
          render(); leiste();
          el('k-fenster').scrollTop = 0;
          return;
        }
        if (a.status === 401) { zeigeSperre('Bitte melden Sie sich erneut an.'); return; }
        meldung.innerHTML = '<div class="meldung schlecht">' +
          sicher((a.daten && a.daten.meldung) || 'Die Reservierung konnte nicht gespeichert werden.') + '</div>';
        knopf.disabled = false; knopf.textContent = 'Reservierung verbindlich abschicken';
        if (a.status === 409) { laden(); }     // Bestand hat sich geändert – neu einlesen
      })
      .catch(function () {
        meldung.innerHTML = '<div class="meldung schlecht">Die Verbindung ist abgebrochen. ' +
          'Bitte prüfen Sie Ihre Internetverbindung und versuchen Sie es erneut.</div>';
        knopf.disabled = false; knopf.textContent = 'Reservierung verbindlich abschicken';
      });
  }

  if (W.zugang) { laden(); } else { zeigeSperre(''); }
})();
