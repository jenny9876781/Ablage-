<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Datenhaltung: Artikel, Vorgänge (eine Reservierungsanfrage) und Positionen
 * (ein Artikel darin). Die Verfügbarkeit wird immer aus den Positionen
 * gerechnet, nie als Zähler geführt – ein Zähler läuft bei gleichzeitigen
 * Zugriffen auseinander.
 */
class Kikripp_DB {

    const SCHEMA_VERSION = 5;

    public static function t_artikel()  { global $wpdb; return $wpdb->prefix . 'kikripp_artikel'; }
    public static function t_vorgang()  { global $wpdb; return $wpdb->prefix . 'kikripp_vorgang'; }
    public static function t_position() { global $wpdb; return $wpdb->prefix . 'kikripp_position'; }

    public static function tabellen_anlegen() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $coll = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE " . self::t_artikel() . " (
            artnr VARCHAR(32) NOT NULL,
            sortierung INT NOT NULL DEFAULT 0,
            menge INT NOT NULL DEFAULT 0,
            preis_netto DECIMAL(10,2) NOT NULL DEFAULT 0,
            aktiv TINYINT(1) NOT NULL DEFAULT 1,
            im_katalog TINYINT(1) NOT NULL DEFAULT 1,
            daten LONGTEXT NOT NULL,
            aktualisiert DATETIME NOT NULL,
            PRIMARY KEY (artnr),
            KEY im_katalog (im_katalog, aktiv)
        ) ENGINE=InnoDB $coll;");

        dbDelta("CREATE TABLE " . self::t_vorgang() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL DEFAULT '',
            email VARCHAR(190) NOT NULL DEFAULT '',
            telefon VARCHAR(80) NOT NULL DEFAULT '',
            nachricht TEXT NULL,
            firma VARCHAR(190) NOT NULL DEFAULT '',
            strasse VARCHAR(190) NOT NULL DEFAULT '',
            plz VARCHAR(10) NOT NULL DEFAULT '',
            ort VARCHAR(120) NOT NULL DEFAULT '',
            besichtigung VARCHAR(40) NOT NULL DEFAULT '',
            abholwunsch VARCHAR(20) NOT NULL DEFAULT '',
            demontage TINYINT(1) NOT NULL DEFAULT 0,
            abholtermin VARCHAR(80) NOT NULL DEFAULT '',
            abholung VARCHAR(16) NOT NULL DEFAULT '',
            rechnungsnr VARCHAR(40) NOT NULL DEFAULT '',
            rechnung_am VARCHAR(10) NOT NULL DEFAULT '',
            notiz TEXT NULL,
            abgeholt_am VARCHAR(10) NOT NULL DEFAULT '',
            du TINYINT(1) NOT NULL DEFAULT 0,
            erstellt DATETIME NOT NULL,
            ablauf DATETIME NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'offen',
            mail_versandt TINYINT(1) NOT NULL DEFAULT 0,
            kontakt_weg TINYINT(1) NOT NULL DEFAULT 0,
            testdaten TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY status (status, ablauf)
        ) ENGINE=InnoDB $coll;");

        dbDelta("CREATE TABLE " . self::t_position() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            vorgang_id BIGINT(20) UNSIGNED NOT NULL,
            artnr VARCHAR(32) NOT NULL,
            menge INT NOT NULL DEFAULT 1,
            preis_netto DECIMAL(10,2) NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'reserviert',
            bezahlt_am DATETIME NULL,
            PRIMARY KEY (id),
            KEY vorgang_id (vorgang_id),
            KEY artnr (artnr, status)
        ) ENGINE=InnoDB $coll;");

        update_option('kikripp_schema_version', self::SCHEMA_VERSION);
    }

    public static function pruefe_version() {
        if ((int) get_option('kikripp_schema_version', 0) < self::SCHEMA_VERSION) {
            self::tabellen_anlegen();
        }
    }

    /** Belegung je Artikel: bezahlte Mengen und noch gültige Reservierungen. */
    public static function belegung($artnr = null) {
        global $wpdb;
        $p = self::t_position();
        $v = self::t_vorgang();
        $jetzt = current_time('mysql');
        $wo = '';
        $args = [$jetzt];
        if ($artnr !== null) {
            $wo = ' AND p.artnr = %s';
            $args[] = $artnr;
        }
        $sql = "SELECT p.artnr,
                       SUM(CASE WHEN p.status = 'bezahlt' THEN p.menge ELSE 0 END) AS bezahlt,
                       SUM(CASE WHEN p.status = 'reserviert'
                                     AND ((v.status = 'offen' AND v.ablauf > %s)
                                          OR v.status = 'bestellt')
                                THEN p.menge ELSE 0 END) AS reserviert
                FROM $p p INNER JOIN $v v ON v.id = p.vorgang_id
                WHERE 1=1 $wo
                GROUP BY p.artnr";
        $zeilen = $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);
        $out = [];
        foreach ((array) $zeilen as $z) {
            $out[$z['artnr']] = [
                'bezahlt'    => (int) $z['bezahlt'],
                'reserviert' => (int) $z['reserviert'],
            ];
        }
        return $out;
    }

    /**
     * Artikel für den Katalog, angereichert um die Verfügbarkeit.
     * Vollständig bezahlte Artikel fallen heraus – sie sind verkauft.
     */
    public static function katalog_artikel() {
        global $wpdb;
        $zeilen = $wpdb->get_results(
            "SELECT * FROM " . self::t_artikel() . "
             WHERE aktiv = 1 AND im_katalog = 1
             ORDER BY sortierung ASC, artnr ASC", ARRAY_A);
        $belegung = self::belegung();
        $out = [];
        foreach ((array) $zeilen as $z) {
            $daten = json_decode($z['daten'], true);
            if (!is_array($daten)) { $daten = []; }
            $b = $belegung[$z['artnr']] ?? ['bezahlt' => 0, 'reserviert' => 0];
            $menge = (int) $z['menge'];
            $rest  = max(0, $menge - $b['bezahlt']);          // noch nicht verkauft
            if ($rest <= 0) { continue; }                      // bezahlt = aus dem Katalog
            $frei = max(0, $rest - $b['reserviert']);
            $daten['nr']         = $z['artnr'];
            $daten['menge']      = $rest;
            $daten['frei']       = $frei;
            $daten['reserviert'] = min($b['reserviert'], $rest);
            $daten['preis']      = (float) $z['preis_netto'];
            $daten['status']     = $frei > 0 ? 'verfügbar' : 'reserviert';
            $out[] = $daten;
        }
        return $out;
    }

    /** Wie viele Stück sind von einem Artikel gerade frei? */
    public static function frei($artnr) {
        global $wpdb;
        $menge = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT menge FROM " . self::t_artikel() . "
             WHERE artnr = %s AND aktiv = 1 AND im_katalog = 1", $artnr));
        if ($menge <= 0) { return 0; }
        $b = self::belegung($artnr)[$artnr] ?? ['bezahlt' => 0, 'reserviert' => 0];
        return max(0, $menge - $b['bezahlt'] - $b['reserviert']);
    }

    /**
     * Reservierung anlegen. Läuft in einer Transaktion mit Zeilensperre,
     * damit zwei gleichzeitige Anfragen nicht dasselbe letzte Stück bekommen.
     * Gibt die Vorgangs-ID zurück oder ein WP_Error.
     */
    public static function reservieren($kontakt, $wunsch) {
        global $wpdb;
        if (empty($wunsch)) {
            return new WP_Error('leer', 'Es wurden keine Artikel ausgewählt.');
        }
        $jetzt = current_time('mysql');
        $ablauf = self::ablauf_nach_werktagen($jetzt, self::frist_werktage());

        $wpdb->query('START TRANSACTION');
        try {
            $positionen = [];
            foreach ($wunsch as $artnr => $menge) {
                $artnr = sanitize_text_field((string) $artnr);
                $menge = (int) $menge;
                if ($menge <= 0) { continue; }

                // Zeilensperre auf den Artikel – blockiert eine parallele Reservierung
                $artikel = $wpdb->get_row($wpdb->prepare(
                    "SELECT artnr, menge, preis_netto FROM " . self::t_artikel() . "
                     WHERE artnr = %s AND aktiv = 1 AND im_katalog = 1 FOR UPDATE", $artnr), ARRAY_A);
                if (!$artikel) {
                    $wpdb->query('ROLLBACK');
                    return new WP_Error('unbekannt', sprintf('Artikel %s ist nicht mehr im Katalog.', $artnr));
                }
                $b = self::belegung($artnr)[$artnr] ?? ['bezahlt' => 0, 'reserviert' => 0];
                $frei = (int) $artikel['menge'] - $b['bezahlt'] - $b['reserviert'];
                if ($menge > $frei) {
                    $wpdb->query('ROLLBACK');
                    return new WP_Error('zu_wenig', sprintf(
                        'Von %s sind nur noch %d Stück verfügbar. Bitte passen Sie die Menge an.',
                        $artnr, max(0, $frei)));
                }
                $positionen[] = [
                    'artnr' => $artnr,
                    'menge' => $menge,
                    'preis' => (float) $artikel['preis_netto'],   // Preis wird eingefroren
                ];
            }
            if (empty($positionen)) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('leer', 'Es wurden keine Artikel ausgewählt.');
            }

            $ok = $wpdb->insert(self::t_vorgang(), [
                'name'         => $kontakt['name'],
                'email'        => $kontakt['email'],
                'telefon'      => $kontakt['telefon'],
                'nachricht'    => $kontakt['nachricht'],
                'firma'        => (string) ($kontakt['firma'] ?? ''),
                'strasse'      => (string) ($kontakt['strasse'] ?? ''),
                'plz'          => (string) ($kontakt['plz'] ?? ''),
                'ort'          => (string) ($kontakt['ort'] ?? ''),
                'besichtigung' => (string) ($kontakt['besichtigung'] ?? ''),
                'abholwunsch'  => (string) ($kontakt['abholwunsch'] ?? ''),
                'demontage'    => !empty($kontakt['demontage']) ? 1 : 0,
                'erstellt'     => $jetzt,
                'ablauf'       => $ablauf,
                'status'       => 'offen',
                'testdaten'    => (int) get_option('kikripp_vorschau', 1),
            ]);
            // Die IP-Adresse wird bewusst nicht gespeichert: der Katalog liegt auf
            // fremdem Speicherplatz und soll dort keine personenbezogenen Daten ablegen.
            if ($ok === false) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('db', 'Die Reservierung konnte nicht gespeichert werden.');
            }
            $vorgang_id = (int) $wpdb->insert_id;
            foreach ($positionen as $pos) {
                $wpdb->insert(self::t_position(), [
                    'vorgang_id'  => $vorgang_id,
                    'artnr'       => $pos['artnr'],
                    'menge'       => $pos['menge'],
                    'preis_netto' => $pos['preis'],
                    'status'      => 'reserviert',
                ]);
            }
            $wpdb->query('COMMIT');
            return $vorgang_id;
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('fehler', $e->getMessage());
        }
    }

    public static function vorgang($id) {
        global $wpdb;
        $v = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::t_vorgang() . " WHERE id = %d", $id), ARRAY_A);
        if (!$v) { return null; }
        $v['positionen'] = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, a.daten FROM " . self::t_position() . " p
             LEFT JOIN " . self::t_artikel() . " a ON a.artnr = p.artnr
             WHERE p.vorgang_id = %d ORDER BY p.id", $id), ARRAY_A);
        return $v;
    }

    public static function vorgaenge($status = null) {
        global $wpdb;
        $sql = "SELECT * FROM " . self::t_vorgang();
        if ($status) {
            $sql = $wpdb->prepare($sql . " WHERE status = %s", $status);
        }
        $sql .= " ORDER BY erstellt DESC";
        $liste = $wpdb->get_results($sql, ARRAY_A);
        foreach ($liste as &$v) {
            $v['positionen'] = $wpdb->get_results($wpdb->prepare(
                "SELECT p.*, a.daten FROM " . self::t_position() . " p
                 LEFT JOIN " . self::t_artikel() . " a ON a.artnr = p.artnr
                 WHERE p.vorgang_id = %d ORDER BY p.id", $v['id']), ARRAY_A);
        }
        return $liste;
    }

    /**
     * Nimmt alle Artikel aus dem Katalog, die in der Importdatei nicht mehr vorkommen.
     * Gelöscht wird nichts – an den Zeilen können Reservierungen und Verkäufe hängen.
     * Gibt die Artikelnummern zurück, die dabei stillgelegt wurden.
     */
    public static function fehlende_stilllegen(array $gesehen) {
        global $wpdb;
        if (!$gesehen) { return []; }
        $platzhalter = implode(',', array_fill(0, count($gesehen), '%s'));
        $betroffen = $wpdb->get_col($wpdb->prepare(
            'SELECT artnr FROM ' . self::t_artikel() . "
              WHERE artnr NOT IN ($platzhalter) AND (im_katalog = 1 OR aktiv = 1)", $gesehen));
        if (!$betroffen) { return []; }
        $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::t_artikel() . " SET im_katalog = 0, aktiv = 0
              WHERE artnr NOT IN ($platzhalter) AND (im_katalog = 1 OR aktiv = 1)", $gesehen));
        return $betroffen;
    }

    /**
     * Löscht Name, E-Mail, Telefon und Nachricht eines Vorgangs.
     * Positionen, Mengen, Preise und Daten bleiben — die braucht die Buchhaltung.
     * Wird direkt nach erfolgreichem Mailversand aufgerufen: die Kontaktdaten
     * liegen dann nur für den Moment des Versands in der Datenbank.
     */
    public static function kontakt_loeschen($id) {
        global $wpdb;
        return (bool) $wpdb->update(self::t_vorgang(), [
            'name' => '', 'email' => '', 'telefon' => '', 'nachricht' => '',
            'firma' => '', 'strasse' => '', 'plz' => '', 'ort' => '',
            'kontakt_weg' => 1,
        ], ['id' => (int) $id]);
    }

    /** Vorgänge, an denen noch Kontaktdaten hängen (Mailversand war gescheitert). */
    public static function kontakte_offen() {
        global $wpdb;
        return $wpdb->get_col('SELECT id FROM ' . self::t_vorgang() . '
                                WHERE kontakt_weg = 0 AND name <> \'\'');
    }

    /**
     * Vorgang auf bestellt/bezahlt/storniert setzen.
     *
     * „bestellt“ heißt: der Käufer hat nach dem Anruf zugesagt, die Bestellung ist
     * unterwegs. Ab dann läuft die Reservierung nicht mehr ab – zwischen Anruf,
     * Unterschrift, Rechnung und Zahlungseingang vergehen oft mehr als drei Werktage.
     * Einzeln stornierte Positionen bleiben storniert, was auch immer mit dem Vorgang
     * danach geschieht.
     */
    public static function vorgang_status($id, $status) {
        global $wpdb;
        if (!in_array($status, ['offen', 'bestellt', 'bezahlt', 'storniert'], true)) { return false; }
        $wpdb->update(self::t_vorgang(), ['status' => $status], ['id' => (int) $id]);
        $pos_status = $status === 'bezahlt' ? 'bezahlt' : ($status === 'storniert' ? 'storniert' : 'reserviert');
        $felder = ['status' => $pos_status];
        // Das Zahldatum wird beim ersten Mal gesetzt und danach nicht mehr angefasst;
        // wird der Vorgang zurückgenommen, fällt es wieder weg.
        if ($status === 'bezahlt') {
            $felder['bezahlt_am'] = current_time('mysql');
        } else {
            $felder['bezahlt_am'] = null;
        }
        // Ohne NULL über prepare(): das würde zu '' und ist in MySQL kein gültiges Datum.
        if ($felder['bezahlt_am'] === null) {
            $wpdb->query($wpdb->prepare(
                'UPDATE ' . self::t_position() . " SET status = %s, bezahlt_am = NULL
                  WHERE vorgang_id = %d AND status <> 'storniert'", $felder['status'], (int) $id));
        } else {
            $wpdb->query($wpdb->prepare(
                'UPDATE ' . self::t_position() . " SET status = %s, bezahlt_am = %s
                  WHERE vorgang_id = %d AND status <> 'storniert'",
                $felder['status'], $felder['bezahlt_am'], (int) $id));
        }
        return true;
    }

    /**
     * Eine einzelne Position stornieren – für Teilabholungen. Wer von zehn reservierten
     * Stühlen nur sechs nimmt, bekommt die übrigen vier zurück in den Katalog.
     * Sind danach alle Positionen storniert, wird der ganze Vorgang storniert.
     */
    public static function position_stornieren($vorgang_id, $position_id) {
        global $wpdb;
        $wpdb->update(self::t_position(), ['status' => 'storniert', 'bezahlt_am' => null],
            ['id' => (int) $position_id, 'vorgang_id' => (int) $vorgang_id]);
        $rest = (int) $wpdb->get_var($wpdb->prepare(
            'SELECT COUNT(*) FROM ' . self::t_position() . " WHERE vorgang_id = %d AND status <> 'storniert'",
            (int) $vorgang_id));
        if ($rest === 0) {
            $wpdb->update(self::t_vorgang(), ['status' => 'storniert'], ['id' => (int) $vorgang_id]);
        }
        return $rest;
    }

    /**
     * Bearbeitungsfelder eines Vorgangs (1.3.0): fester Abholtermin „Y-m-d H:i“, Rechnungsnummer
     * und -datum aus DATEV, interne Notiz, Anrede Du/Sie für die Mailvorlage.
     * Ungültige Datumsangaben werden verworfen statt halb gespeichert.
     */
    public static function vorgang_bearbeiten($id, array $f) {
        global $wpdb;
        $neu = [];
        if (array_key_exists('abholung', $f)) {
            $a = trim((string) $f['abholung']);
            $neu['abholung'] = preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $a) ? $a : '';
        }
        if (array_key_exists('rechnungsnr', $f)) { $neu['rechnungsnr'] = substr(trim((string) $f['rechnungsnr']), 0, 40); }
        if (array_key_exists('rechnung_am', $f)) {
            $r = trim((string) $f['rechnung_am']);
            $neu['rechnung_am'] = preg_match('/^\d{4}-\d{2}-\d{2}$/', $r) ? $r : '';
        }
        if (array_key_exists('notiz', $f)) { $neu['notiz'] = (string) $f['notiz']; }
        if (array_key_exists('du', $f)) { $neu['du'] = $f['du'] ? 1 : 0; }
        if (!$neu) { return false; }
        return $wpdb->update(self::t_vorgang(), $neu, ['id' => (int) $id]) !== false;
    }

    /**
     * Abgeholt vermerken (Datum) oder zurücknehmen (leer). Wer abholt, hat bezahlt –
     * ein noch „bestellter“ Vorgang wird dabei auf bezahlt gesetzt (z. B. Barzahlung vor Ort).
     */
    public static function abgeholt_setzen($id, $datum) {
        global $wpdb;
        $v = self::vorgang($id);
        if (!$v || $v['status'] === 'storniert') { return false; }
        if ($datum !== '' && $v['status'] !== 'bezahlt') { self::vorgang_status($id, 'bezahlt'); }
        return $wpdb->update(self::t_vorgang(), ['abgeholt_am' => (string) $datum], ['id' => (int) $id]) !== false;
    }

    /** Vereinbarten Abholtermin am Vorgang vermerken (freier Text, z. B. „Di 13.10., 9 Uhr“). */
    public static function abholtermin_setzen($id, $termin) {
        global $wpdb;
        return $wpdb->update(self::t_vorgang(), ['abholtermin' => (string) $termin], ['id' => (int) $id]);
    }

    public static function frist_werktage() {
        return max(1, (int) get_option('kikripp_frist_werktage', 3));
    }

    /**
     * Ende der Reservierung: n Werktage (Montag bis Freitag) nach dem Eingang, jeweils
     * bis zum Ende des letzten Tages. Eingang Freitag 15 Uhr, drei Werktage → Mittwoch 23:59.
     * Feiertage zählen mit; das sind im Verkaufszeitraum Oktober bis Dezember in
     * Baden-Württemberg nur Allerheiligen, und der fällt 2026 auf einen Sonntag.
     */
    public static function ablauf_nach_werktagen($start, $werktage) {
        $t = strtotime(substr((string) $start, 0, 10) . ' 12:00:00 UTC');
        $gezaehlt = 0;
        while ($gezaehlt < max(1, (int) $werktage)) {
            $t += DAY_IN_SECONDS;
            if ((int) gmdate('N', $t) <= 5) { $gezaehlt++; }
        }
        return gmdate('Y-m-d', $t) . ' 23:59:59';
    }

    public static function vorgang_verlaengern($id) {
        global $wpdb;
        $neu = self::ablauf_nach_werktagen(current_time('mysql'), self::frist_werktage());
        return (bool) $wpdb->update(self::t_vorgang(),
            ['ablauf' => $neu, 'status' => 'offen'], ['id' => (int) $id]);
    }

    public static function vorgang_loeschen($id) {
        global $wpdb;
        $wpdb->delete(self::t_position(), ['vorgang_id' => (int) $id]);
        return (bool) $wpdb->delete(self::t_vorgang(), ['id' => (int) $id]);
    }

    public static function testdaten_loeschen() {
        global $wpdb;
        $ids = $wpdb->get_col("SELECT id FROM " . self::t_vorgang() . " WHERE testdaten = 1");
        foreach ($ids as $id) { self::vorgang_loeschen($id); }
        return count($ids);
    }
}
